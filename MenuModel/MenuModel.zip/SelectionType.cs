namespace MenuModel
{
    /// <MetaDataID>{72cb7d9b-60a7-48ab-94c6-15301e6d2241}</MetaDataID>
    public enum SelectionType
    {
        SimpleGroup =0,
        SingleSelection = 1,
        MultiSelection = 2,
        AtLeastOneSelected = 4
    };
}
