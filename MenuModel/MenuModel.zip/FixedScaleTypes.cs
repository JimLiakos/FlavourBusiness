namespace MenuModel
{
    /// <MetaDataID>{d2e3b2c4-8769-4be3-b94f-f856cb9f6a9b}</MetaDataID>
    public static class FixedScaleTypes
    {
        /// <MetaDataID>{31791025-03f6-4d22-8888-6dba528fc889}</MetaDataID>
       public const string CheckUncheck = "AF192387-1B53-4752-A38B-3545C2D882EF";
    }
}