﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuModel.JsonViewModel
{
    /// <MetaDataID>{5c63f66d-f7fc-4a4c-ab6d-29de1c0d3cf5}</MetaDataID>
    public class OptionGroup: TypedObject
    {
        /// <MetaDataID>{36b4e726-1744-4bab-9b5d-1c59f3509b3d}</MetaDataID>
        public string Name { get; set; }

        /// <MetaDataID>{28e78549-65a7-4839-b38c-7dc6125e3364}</MetaDataID>
        public List<Option> Options { get; set; }

        /// <MetaDataID>{4a7fe91d-f2ce-4868-9d12-63ebd27fc19c}</MetaDataID>
        public bool CheckUncheck { get; set; }

        /// <MetaDataID>{2822855a-62a9-468f-bc8e-fa4cafbf7be8}</MetaDataID>
        public bool ItemSelectorOptionsGroup { get; set; }
    }
}
