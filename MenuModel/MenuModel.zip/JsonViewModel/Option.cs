﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MenuModel;

namespace MenuModel.JsonViewModel
{
    /// <MetaDataID>{2cdd4709-a7f8-4189-82f1-8e5b23765be1}</MetaDataID>
    public class Option : TypedObject, MenuModel.IPricedSubject, IPreparationScaledOption
    {
        /// <MetaDataID>{faf6ccab-5bd4-4bfe-9399-d39b5a1ff2c0}</MetaDataID>
        public bool Quantitative { get; set; }
        /// <MetaDataID>{06636afc-de3b-4373-866c-79c2530762a7}</MetaDataID>
        public string Name { get; set; }
        /// <MetaDataID>{1490d197-9796-4f82-90fc-1b02a04b454d}</MetaDataID>
        public ScaleType LevelType { get; set; }
        /// <MetaDataID>{8e88e3b7-0e36-4d84-9452-5a3010a5554d}</MetaDataID>
        public int InitialLevelIndex { get; set; }

        /// <MetaDataID>{5285b47a-cd80-4fa3-9d96-c9663b1659c1}</MetaDataID>
        public decimal Price { get; set; }

        /// <MetaDataID>{1343ffa4-0a3f-4c7e-94be-692da1ed858d}</MetaDataID>
        public IList<ICustomizedPrice> PricingContexts
        {
            get; set;
        }

        public IList<IOptionMenuItemSpecific> MenuItemsOptionSpecific { get; set; }


        public IPreparationOptionsGroup OptionGroup { get; set; }


        IScaleType IPreparationScaledOption.LevelType { get; set; }


        public ILevel Initial { get; set; }


        public IMenuItemType Owner { get; set; }

        public IMenuItemType MenuItemType { get; set; }


#if MenuModel

        /// <MetaDataID>{95ceda69-6d7b-4335-9623-e3b58ecd6b46}</MetaDataID>
        internal static Option GetOption(MenuModel.IPreparationScaledOption orgOption, Dictionary<object, object> mappedObject)//, IMenuItem menuItem)
        {
            if (mappedObject.ContainsKey(orgOption))
            {
                //if (orgOption is MenuModel.ItemSelectorOption)
                //{
                //    JsonViewModel.ItemSelectorOption itemSelectorOption = mappedObject[orgOption] as JsonViewModel.ItemSelectorOption;
                //    foreach (var orgMenuItemPriceEntry in (orgOption as MenuModel.ItemSelectorOption).MenuItemPrices)
                //    {
                //        JsonViewModel.MenuItemPrice menuItemPrice = null;
                //        if (mappedObject.ContainsKey(orgMenuItemPriceEntry.Key) && mappedObject.ContainsKey(orgMenuItemPriceEntry.Value))
                //        {
                //            menuItemPrice = mappedObject[orgMenuItemPriceEntry.Value] as JsonViewModel.MenuItemPrice;
                //            itemSelectorOption.MenuItemPrices.Add(menuItemPrice);
                //        }
                //    }
                //    itemSelectorOption.InitialLevelIndex = orgOption.LevelType.Levels.IndexOf(orgOption.Initial);// (orgOption.GetInitialFor(menuItem));
                //    return itemSelectorOption;
                //}
                //else if (orgOption is MenuModel.IPreparationScaledOption)
                //{
                //    JsonViewModel.Option option = mappedObject[orgOption] as Option;
                //    option.InitialLevelIndex = orgOption.LevelType.Levels.IndexOf(orgOption.Initial);// orgOption.GetInitialFor(menuItem));
                //    foreach (var customPrice in orgOption.PricingContexts)
                //    {

                //    }
                //    return option;
                //}
                //else
                    return mappedObject[orgOption] as Option;
            }
            else
            {
                Option option = new Option();
                option.PricingContexts = new List<ICustomizedPrice>();
                option.Price = orgOption.Price;
                mappedObject[orgOption] = option;
                option.Name = orgOption.Name;
                option.Quantitative = orgOption.Quantitative;
                option.LevelType = ScaleType.GetScaleTypeFor(orgOption.LevelType, mappedObject);

                option.InitialLevelIndex = orgOption.LevelType.Levels.IndexOf(orgOption.Initial);// (orgOption.GetInitialFor(menuItem));
                foreach (var customPrice in orgOption.PricingContexts)
                {
                    IPricingContext jsonPricingContext = mappedObject[customPrice.PricingContext] as IPricingContext;
                    IPricedSubject jsonPricedSubject = option;
                    ICustomizedPrice customazedPrice = jsonPricingContext.GetCustomazedPrice(jsonPricedSubject);
                    customazedPrice.Price = customPrice.Price;
                }

                if (orgOption is MenuModel.ItemSelectorOption)
                {
                    ItemSelectorOption itemSelectorOption = mappedObject[orgOption] as JsonViewModel.ItemSelectorOption;
                    foreach (var orgMenuItemPriceEntry in (orgOption as MenuModel.ItemSelectorOption).MenuItemPrices)
                    {
                        JsonViewModel.MenuItemPrice menuItemPrice = null;
                        if (mappedObject.ContainsKey(orgMenuItemPriceEntry.Key) && mappedObject.ContainsKey(orgMenuItemPriceEntry.Value))
                        {
                            menuItemPrice = mappedObject[orgMenuItemPriceEntry.Value] as JsonViewModel.MenuItemPrice;
                            itemSelectorOption.MenuItemPrices.Add(menuItemPrice);
                        }
                    }
                }


                return option;
            }
        }

#endif
        /// <MetaDataID>{c90a6cc7-9444-4397-bb48-6edb777e6a4e}</MetaDataID>
        public decimal GetPrice(IPricingContext pricicingContext)
        {
            throw new NotImplementedException();
        }

        /// <MetaDataID>{572a252a-3086-413a-9780-c188d79e561e}</MetaDataID>
        public void SetPrice(IPricingContext pricicingContext, decimal price)
        {
            throw new NotImplementedException();
        }

        /// <MetaDataID>{0a5747c2-0826-4bf2-99ab-350aefca58ab}</MetaDataID>
        public void RemoveCustomazedPrice(ICustomizedPrice customazedPrice)
        {
            throw new NotImplementedException();
        }

        public IOptionMenuItemSpecific GetMenuItemSpecific(IMenuItem menuItem)
        {
            throw new NotImplementedException();
        }

        public ILevel GetInitialFor(IMenuItem menuItem)
        {
            throw new NotImplementedException();
        }

        public void SetInitialFor(IMenuItem menuItem, ILevel initialLevel)
        {
            throw new NotImplementedException();
        }

        public bool IsHiddenFor(IMenuItem menuItem)
        {
            throw new NotImplementedException();
        }

        public void SetHiddenFor(IMenuItem menuItem, bool value)
        {
            throw new NotImplementedException();
        }
    }


    /// <MetaDataID>{a84587dd-3413-410a-af29-73797fda7dd7}</MetaDataID>
    public class ScaleType
    {
        /// <MetaDataID>{276bfbdf-2b7d-4384-8e94-93a601b3a0db}</MetaDataID>
        public string Name { get; set; }

        /// <MetaDataID>{b20efda3-97e6-4d63-a9c3-e5910754738b}</MetaDataID>
        static Dictionary<MenuModel.IScaleType, JsonViewModel.ScaleType> jsonScaleTypeDictionary = new Dictionary<MenuModel.IScaleType, ScaleType>();


        /// <MetaDataID>{5ffef0da-8b59-4475-a47e-4c318f07a7e9}</MetaDataID>
        public ScaleType(MenuModel.IScaleType scaleType)
        {
            Levels = (from level in scaleType.Levels select new Level() { Name = level.Name, UncheckOption = level.UncheckOption }).ToList();
        }
        /// <MetaDataID>{35980699-9af5-4f30-be75-c3626799c741}</MetaDataID>
        public List<Level> Levels = new List<Level>();

        /// <MetaDataID>{dbb658eb-e0a2-4eb3-bc64-d4194db6d8c4}</MetaDataID>
        internal static ScaleType GetScaleTypeFor(MenuModel.IScaleType scaleType)
        {
            ScaleType jsonScaleType = null;
            if (!jsonScaleTypeDictionary.TryGetValue(scaleType, out jsonScaleType))
            {
                jsonScaleType = new ScaleType(scaleType);
                jsonScaleTypeDictionary[scaleType] = jsonScaleType;
            }
            return jsonScaleType;
        }

        /// <MetaDataID>{0c5f5dfd-a4fd-4f82-ad00-7b76f7471750}</MetaDataID>
        internal static ScaleType GetScaleTypeFor(MenuModel.IScaleType scaleType, Dictionary<object, object> mappedObject)
        {
            ScaleType jsonScaleType = null;

            if (!mappedObject.ContainsKey(scaleType))
            {
                jsonScaleType = new ScaleType(scaleType);
                mappedObject[scaleType] = jsonScaleType;
                return jsonScaleType;
            }
            else
                return mappedObject[scaleType] as ScaleType;

        }
    }

    /// <MetaDataID>{07988325-98d9-4392-9135-01a0aee1af00}</MetaDataID>
    public class Level
    {
        /// <MetaDataID>{37620c73-4bf5-4280-a40d-67fb7ef64614}</MetaDataID>
        public string Name { get; set; }

        /// <MetaDataID>{57632ed0-748c-4e96-b3f8-0f4d5e3cb607}</MetaDataID>
        public bool UncheckOption { get; set; }
    }
}
