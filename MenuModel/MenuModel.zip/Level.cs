using System;
using System.Collections.Generic;
using OOAdvantech.MetaDataRepository;
using OOAdvantech.Transactions;

namespace MenuModel
{
    /// <MetaDataID>{51666fd7-3e9a-47ef-8138-52753b6ad25f}</MetaDataID>
    [BackwardCompatibilityID("{51666fd7-3e9a-47ef-8138-52753b6ad25f}")]
    [Persistent()]
    public class Level : ILevel
    {
        /// <exclude>Excluded</exclude>
        OOAdvantech.ObjectStateManagerLink StateManagerLink;



        /// <MetaDataID>{0c0b2183-05a7-4795-87da-ea794413003e}</MetaDataID>
        public Level()
        {

        }
        /// <MetaDataID>{07413a7c-a0b5-41d2-b88b-4965fbfd57b7}</MetaDataID>
        public Level(string name)
        {

            _Name = name;
        }
        /// <exclude>Excluded</exclude>
        string _Name;

        /// <MetaDataID>{ace749f1-1658-4e4c-8df2-0c42c1d6688d}</MetaDataID>
        [PersistentMember("_Name")]
        public string Name
        {
            get
            {
                return _Name;
            }

            set
            {
                if (_Name != value && !(DeclaringType is MenuModel.FixedScaleType))
                {
                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _Name = value;
                        stateTransition.Consistent = true;
                    }
                }
            }
        }

        /// <exclude>Excluded</exclude>
        bool _UncheckOption;

        /// <MetaDataID>{7968f8ba-000b-41db-bf81-c6b710d42313}</MetaDataID>
        [PersistentMember("_UncheckOption")]
        public bool UncheckOption
        {
            get
            {
                return _UncheckOption;
            }

            set
            {
                if (_UncheckOption != value && !(DeclaringType is MenuModel.FixedScaleType))
                {

                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _UncheckOption = value;
                        stateTransition.Consistent = true;
                    }

                }
            }
        }
        /// <exclude>Excluded</exclude>
        IScaleType _DeclaringType;

        /// <MetaDataID>{8c2f284b-9d19-453e-b4ea-a91aec0645d1}</MetaDataID>
        [PersistentMember("_DeclaringType")]
        [BackwardCompatibilityID("+3")]
        public IScaleType DeclaringType
        {
            get
            {
                return _DeclaringType;
            }
        }
    }
}