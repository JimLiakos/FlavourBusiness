namespace MenuPresentationModel.MenuCanvas
{
    /// <MetaDataID>{4c25c565-55d9-4d4e-be6a-fc7d65159c97}</MetaDataID>
    public enum HeadingType
    {
        Normal,
        AltFont,
        Title,
        SubHeading
    }
}