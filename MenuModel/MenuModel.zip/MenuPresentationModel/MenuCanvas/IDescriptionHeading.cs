using OOAdvantech.MetaDataRepository;

namespace MenuPresentationModel.MenuCanvas
{
    /// <MetaDataID>{2cfa8573-a9a8-4630-964c-6175fc95d04d}</MetaDataID>
    /// <summary>I</summary>
    public interface IDescriptionHeading : IMenuCanvasHeading
    {
       
    }
}