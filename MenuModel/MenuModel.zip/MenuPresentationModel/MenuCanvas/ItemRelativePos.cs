namespace MenuPresentationModel.MenuCanvas
{
    /// <MetaDataID>{4779daed-1dbd-41a1-aba0-c681d87f0eab}</MetaDataID>
    public enum ItemRelativePos
    {
        Before,
        OnPos,
        After
    }
}