using OOAdvantech.MetaDataRepository;

namespace MenuPresentationModel.MenuCanvas
{
    /// <MetaDataID>{c0a5bbf6-0363-4759-84d9-5bc8695bda81}</MetaDataID>
    public interface IFoodItemsHeading : IMenuCanvasHeading
    {
    
    }
}