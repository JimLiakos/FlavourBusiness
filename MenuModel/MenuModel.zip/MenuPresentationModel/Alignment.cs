namespace MenuPresentationModel
{
    /// <MetaDataID>{25313645-49e9-4531-90d0-5647e640f1fe}</MetaDataID>
    public enum Alignment
    {
        Left,
        Center,
        Right
    }
}