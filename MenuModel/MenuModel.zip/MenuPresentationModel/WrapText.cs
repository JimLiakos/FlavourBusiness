namespace MenuPresentationModel.MenuCanvas
{
    /// <MetaDataID>{b8d46cc6-c906-4486-910b-e1b4253509de}</MetaDataID>
    public class WrapText
    {
        /// <MetaDataID>{6885a0b2-c41d-4ee5-8f8e-377c50145ab7}</MetaDataID>
        public double Width { set; get; }

        /// <MetaDataID>{f683a1f3-46d0-49d4-a8ad-967b017aa8b1}</MetaDataID>
        public double Height { set; get; }

        public string Text { set; get; }
    }
}