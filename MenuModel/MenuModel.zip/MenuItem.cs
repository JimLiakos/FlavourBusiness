using System;
using System.Collections.Generic;
using OOAdvantech.Collections.Generic;
using OOAdvantech.MetaDataRepository;
using OOAdvantech.Transactions;
using System.Linq;
using FinanceFacade;

namespace MenuModel
{
    /// <MetaDataID>{5c1aac35-2956-4ead-a424-435a5781c314}</MetaDataID>
    [BackwardCompatibilityID("{5c1aac35-2956-4ead-a424-435a5781c314}")]
    [Persistent()]
    public class MenuItem : FinanceFacade.ITaxable, IClassified, IMenuItem, OOAdvantech.PersistenceLayer.IObjectStateEventsConsumer
    {





        /// <exclude>Excluded</exclude>
        string _ExtrasDescription;

        /// <MetaDataID>{e4763b81-229a-4355-9e8f-c17f478f0286}</MetaDataID>
        [PersistentMember(nameof(_ExtrasDescription))]
        [BackwardCompatibilityID("+12")]
        public string ExtrasDescription
        {
            get
            {
                return _ExtrasDescription;
            }
            set
            {
                if (_ExtrasDescription != value)
                {
                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _ExtrasDescription = value;
                        stateTransition.Consistent = true;
                    }
                }
            }
        }

        /// <exclude>Excluded</exclude>
        string _Description;

        /// <MetaDataID>{afd37e91-852a-4b35-9374-49542bda5131}</MetaDataID>
        [PersistentMember(nameof(_Description))]
        [BackwardCompatibilityID("+11")]
        public string Description
        {
            get
            {
                return _Description;
            }
            set
            {
                if (_Description != value)
                {
                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _Description = value;
                        stateTransition.Consistent = true;
                    }
                }
            }
        }

        /// <exclude>Excluded</exclude>
        Set<IOptionMenuItemSpecific> _OptionsMenuItemSpecifics = new Set<IOptionMenuItemSpecific>();

        /// <MetaDataID>{9504c26b-fcbf-48da-a90b-a513b58e38cb}</MetaDataID>
        [PersistentMember(nameof(_OptionsMenuItemSpecifics))]
        [AssociationEndBehavior(PersistencyFlag.CascadeDelete)]
        [BackwardCompatibilityID("+10")]
        public IList<IOptionMenuItemSpecific> OptionsMenuItemSpecifics
        {
            get
            {
                return _OptionsMenuItemSpecifics.AsReadOnly();
            }
        }


        /// <MetaDataID>{ba74fea1-26ab-4a48-b988-0e7d2f7bb49c}</MetaDataID>
        public void RemoveMenuItemPrice(IMenuItemPrice price)
        {
            using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
            {
                _Prices.Remove(price);
                stateTransition.Consistent = true;
            }
        }

        /// <MetaDataID>{78ec4a3b-6cc9-41b8-8675-459d98c105ad}</MetaDataID>
        public void AddMenuItemPrice(IMenuItemPrice price)
        {
            using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
            {

                _Prices.Add(price);
                stateTransition.Consistent = true;
            }
        }

        /// <exclude>Excluded</exclude>
        OOAdvantech.ObjectStateManagerLink StateManagerLink;

        /// <MetaDataID>{169fc92b-6f27-48ae-9156-c00dca6ff47f}</MetaDataID>
        public MenuItem()
        {

        }
        /// <exclude>Excluded</exclude>
        Set<MenuModel.IMenuItemType> _Types;

        /// <MetaDataID>{fbf8d3d9-14d8-4d34-8259-a2fb77d09487}</MetaDataID>
        [PersistentMember("_Types")]
        [BackwardCompatibilityID("+8")]
        public IList<IMenuItemType> Types
        {
            get
            {

                return _Types.AsReadOnly();
            }
        }




        /// <exclude>Excluded</exclude>
        /// <MetaDataID>{75068c35-ca0a-44c0-8735-12f89ca5849d}</MetaDataID>
        string _Name;
        /// <MetaDataID>{931f9780-8036-4998-92f4-caac492abea8}</MetaDataID>
        [BackwardCompatibilityID("+1")]
        [PersistentMember(nameof(_Name))]
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                if (_Name != value)
                {
                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _Name = value;
                        if (DedicatedType != null)
                            DedicatedType.Name = value;

                        stateTransition.Consistent = true;
                    }
                }
            }
        }

        ///// <exclude>Excluded</exclude>
        //decimal _Price;
        ///// <MetaDataID>{583ba988-3966-4394-afb0-e96d2a5f82eb}</MetaDataID>
        //[BackwardCompatibilityID("+2")]
        //[PersistentMember("_Price")]
        //public decimal Price
        //{
        //    set
        //    {
        //        if (_Price != value)
        //        {
        //            using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
        //            {
        //                _Price = value;
        //                stateTransition.Consistent = true;
        //            }
        //        }
        //    }
        //    get
        //    {
        //        return _Price;
        //    }
        //}

        /// <exclude>Excluded</exclude>
        OOAdvantech.Member<MenuModel.IClass> _Class = new OOAdvantech.Member<MenuModel.IClass>();
        /// <MetaDataID>{e63bf395-f95b-445c-b03e-bb0b7ffec49b}</MetaDataID>
        [AssociationEndBehavior(PersistencyFlag.ReferentialIntegrity)]

        [PersistentMember(nameof(_Class))]
        [BackwardCompatibilityID("+5")]
        public MenuModel.IClass Class
        {
            get
            {
                return _Class.Value;
            }
            set
            {
                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _Class.Value = value;
                    stateTransition.Consistent = true;
                }
            }
        }

        /// <exclude>Excluded</exclude>
        OOAdvantech.Member<MenuModel.IMenuItemType> _DedicatedType = new OOAdvantech.Member<IMenuItemType>();

        /// <MetaDataID>{229addbe-f4e0-4876-97fb-656278b75af8}</MetaDataID>
        [BackwardCompatibilityID("+6")]
        [PersistentMember(nameof(_DedicatedType))]
        public MenuModel.IMenuItemType DedicatedType
        {
            get
            {
                return _DedicatedType.Value;
            }

            set
            {
                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _DedicatedType.Value = value;
                    stateTransition.Consistent = true;
                }
            }
        }

        /// <exclude>Excluded</exclude>
        /// <MetaDataID>{a30d55fa-c164-42a6-9630-37ad9de9c896}</MetaDataID>
        Set<IMenuItemPrice> _Prices = new Set<IMenuItemPrice>();

        /// <MetaDataID>{ae8f4cb7-40e5-4b06-a1b6-f06faa44dbb7}</MetaDataID>
        [PersistentMember(nameof(_Prices))]
        [BackwardCompatibilityID("+9")]
        [AssociationEndBehavior(PersistencyFlag.CascadeDelete)]
        public IList<IMenuItemPrice> Prices
        {
            get
            {
                return _Prices.AsReadOnly();
            }
        }

        /// <MetaDataID>{b7c34717-cfff-4037-95aa-054127d842e7}</MetaDataID>
        public MenuModel.IMenuItemPrice MenuItemPrice
        {
            get
            {
                var menuItemPrice = (from aMenuItemPrice in Prices.OfType<MenuItemPrice>()
                                     where aMenuItemPrice.ItemSelector != null && !aMenuItemPrice.ItemSelector.GetInitialFor(this).UncheckOption
                                     select aMenuItemPrice).FirstOrDefault();

                if (menuItemPrice == null)
                    menuItemPrice = (from aMenuItemPrice in Prices.OfType<MenuItemPrice>()
                                     where aMenuItemPrice.ItemSelector == null
                                     select aMenuItemPrice).FirstOrDefault();

                if (menuItemPrice == null)
                {

                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        menuItemPrice = new MenuItemPrice();
                        menuItemPrice.Name = "MenuItemDefault";
                        OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(this).CommitTransientObjectState(menuItemPrice);
                        AddMenuItemPrice(menuItemPrice);
                        menuItemPrice.Price = 0;

                        stateTransition.Consistent = true;
                    }
                }
                return menuItemPrice;
            }
        }

        /// <exclude>Excluded</exclude>
        IMenu _Menu;
        /// <MetaDataID>{d879a7b4-78a0-4a2e-af9d-e24d1d94935a}</MetaDataID>
        public IMenu Menu
        {
            get
            {
                if (_Menu == null)
                {
                    IClass rootClass = Class;

                    while (rootClass is IClassified && (rootClass as IClassified).Class != null)
                        rootClass = (rootClass as IClassified).Class;

                    OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(this));

                    _Menu = (from menu in storage.GetObjectCollection<IMenu>()
                             where menu.RootCategory == rootClass
                             select menu).FirstOrDefault();
                }
                return _Menu;
            }
        }


        /// <exclude>Excluded</exclude>
        ITaxableType _TaxableType;

        /// <MetaDataID>{ed3807ec-bea1-49ef-a315-032befbcabc0}</MetaDataID>
        [PersistentMember(nameof(_TaxableType))]
        [AssociationEndBehavior(PersistencyFlag.OnConstruction)]
        [BackwardCompatibilityID("+13")]
        public FinanceFacade.ITaxableType TaxableType
        {
            get
            {
                return _TaxableType;
            }

            set
            {
                if (_TaxableType != value)
                {
                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _TaxableType = value;
                        stateTransition.Consistent = true;
                    }
                }
            }
        }



        ///// <MetaDataID>{9504c26b-fcbf-48da-a90b-a513b58e38cb}</MetaDataID>
        //public IList<IPreparationScaledOption> OptionsMenuItemSpecifics
        //{
        //    get
        //    {
        //        throw new NotImplementedException();
        //    }
        //}


        //public decimal GetPriceFor(IPricedSubject pricedSubject)
        //{
        //    pricedSubject.GetPrice
        //    return pricedSubject.GetPrice(this);

        //    //ICustomazedPrice customazedPrice=(from anCustomazedPrice in PricedSubjects
        //    //                                  where anCustomazedPrice.PricedSubject== pricedSubject
        //    //                                  select anCustomazedPrice).f

        //}

        /// <MetaDataID>{dd8a9ccd-3ceb-4986-bf33-05425819ab2a}</MetaDataID>
        public void AddType(IMenuItemType type)
        {
            using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
            {
                _Types.Add(type);
                stateTransition.Consistent = true;
            }
        }

        /// <MetaDataID>{ed31ef4c-1d33-4d28-97a7-80f2bf684863}</MetaDataID>
        public void RemoveType(IMenuItemType type)
        {
            using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
            {
                foreach (MenuItemPrice menuItemPrice in Prices)
                {
                    if (menuItemPrice.ItemSelector != null && menuItemPrice.ItemSelector.MenuItemType == type)
                        RemoveMenuItemPrice(menuItemPrice);
                }

                foreach (IOptionMenuItemSpecific opionSpecific in OptionsMenuItemSpecifics)
                {
                    if (opionSpecific.Option != null && opionSpecific.Option.MenuItemType == type)
                        RemoveOptionsMenuItemSpecific(opionSpecific);
                }

                _Types.Remove(type);
                stateTransition.Consistent = true;
            }
        }

        /// <MetaDataID>{318a061a-73b3-48b3-8f48-16382e2eee2b}</MetaDataID>
        private void RemoveOptionsMenuItemSpecific(IOptionMenuItemSpecific opionSpecific)
        {
            using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
            {
                _OptionsMenuItemSpecifics.Remove(opionSpecific);
                stateTransition.Consistent = true;
            }
        }

        /// <MetaDataID>{d7fa8c30-054c-4a0d-8157-3db63026be01}</MetaDataID>
        public void OnCommitObjectState()
        {
            if (_DedicatedType.Value == null)
            {
                _DedicatedType.Value = new MenuItemType(Properties.Resources.ItemDedicatedTypeDefaultName);
                OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(this).CommitTransientObjectState(DedicatedType);
            }
        }

        /// <MetaDataID>{5d5d710e-cd9b-466a-a91b-5c26365caed8}</MetaDataID>
        public void OnActivate()
        {
            if (_DedicatedType.Value == null)
            {
                _DedicatedType.Value = new MenuItemType(Properties.Resources.ItemDedicatedTypeDefaultName);
                OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(this).CommitTransientObjectState(DedicatedType);
            }
        }



        /// <MetaDataID>{68546e78-9f52-42c1-8c34-c187ab483f51}</MetaDataID>
        public void OnDeleting()
        {

        }

        /// <MetaDataID>{b8e48928-982f-473f-b29c-0309d2230d7d}</MetaDataID>
        public void LinkedObjectAdded(object linkedObject, AssociationEnd associationEnd)
        {

        }

        /// <MetaDataID>{f55a61e3-26a7-424f-beae-cdfee6246957}</MetaDataID>
        public void LinkedObjectRemoved(object linkedObject, AssociationEnd associationEnd)
        {

        }
    }
}