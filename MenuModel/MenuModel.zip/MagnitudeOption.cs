using OOAdvantech.MetaDataRepository;

namespace MenuModel
{
    /// <MetaDataID>{76e5080c-6610-4022-906f-0e960e6aba63}</MetaDataID>
    [BackwardCompatibilityID("{76e5080c-6610-4022-906f-0e960e6aba63}")]
    [Persistent()]
    public class MagnitudeOption : PreparationScaledOption
    {
    }
}