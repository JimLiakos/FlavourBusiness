﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FloorLayoutDesigner
{
    /// <summary>
    /// Interaction logic for FloorLayoutToolBox.xaml
    /// </summary>
    /// <MetaDataID>{61917cb7-eedc-4bd2-8a17-730f0334b943}</MetaDataID>
    public partial class FloorLayoutToolBox : UserControl
    {
        public FloorLayoutToolBox()
        {
            InitializeComponent();
        }
    }
}
