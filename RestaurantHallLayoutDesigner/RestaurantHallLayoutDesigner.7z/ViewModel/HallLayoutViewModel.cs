﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using OOAdvantech.Transactions;
using RestaurantHallLayoutModel;
using StyleableWindow;
using UIBaseEx;

namespace FloorLayoutDesigner.ViewModel
{
    public delegate void HallLayoutSizeChangedHandle(HallLayout hallLayout, PaperSize newSize);
    /// <MetaDataID>{02fcfad8-6722-4e7b-ba63-033eeee228d9}</MetaDataID>
    [Transactional]
    public class HallLayoutViewModel: MarshalByRefObject, INotifyPropertyChanged
    {
        public event HallLayoutSizeChangedHandle HallLayoutSizeChanged;

        readonly HallLayout _HallLayout;
        public HallLayout HallLayout
        {
            get
            {
                var ss = FloorLayoutDesigner.Properties.Resources.HallLayoutLabelFontMenuItemHeader;
                return _HallLayout;
            }
        }



        public HallLayoutViewModel(HallLayout hallLayout)
        {
            _HallLayout = hallLayout;

            SelectedPaperSize = PaperSizes.Where(x => x.PaperType == PaperType.A4).FirstOrDefault();
            Landscape = true;
            _FontPresantation = new FontPresantation() { Font = hallLayout.Font };
            _FontPresantation.PropertyChanged += _FontPresantation_PropertyChanged;

            _LabelBkColor = (Color)ColorConverter.ConvertFromString(hallLayout.LabelBkColor);

            UpdateCanvasItemValues();

            HallLayoutShapeLabelFont = new WPFUIElementObjectBind.RelayCommand((object sender) =>
            {
                var win = System.Windows.Window.GetWindow(HallLayoutShapeLabelFont.UserInterfaceObjectConnection.ContainerControl as System.Windows.DependencyObject);
                (HallLayoutShapeLabelFont.UserInterfaceObjectConnection.ContainerControl as System.Windows.FrameworkElement).GetObjectContext().RunUnderContextTransaction(new Action(() =>
                {
                    using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
                    {
                        StyleableWindow.FontDialog fontDialog = new StyleableWindow.FontDialog();
                        fontDialog.GetObjectContext().SetContextInstance(FontPresantation);
                        fontDialog.Owner = win;
                        if (fontDialog.ShowDialog().Value)
                            stateTransition.Consistent = true;
                    }
                }));

            });

        }



        /// <exclude>Excluded</exclude> 
        SolidColorBrush _LabelBackground;

        public Brush LabelBackground
        {
            get
            {
                if (_LabelBackground == null)
                    _LabelBackground= new SolidColorBrush(LabelBkColor);

                return _LabelBackground;
            }
        }

        /// <exclude>Excluded</exclude>
        Color _LabelBkColor;
        public Color LabelBkColor 
        {
            get
            {
                return _LabelBkColor;
            } 
            set
            {
                _LabelBkColor = value;
                HallLayout.LabelBkColor = new ColorConverter().ConvertToString(value);
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LabelBkColor)));
            }
        }


        public string OpacityValue
        {
            get => Opacity.ToString("N2");
        }


  

        public double Opacity
        {
            get
            {
                return HallLayout.LabelBkOpacity;
            }
            set
            {
              
                HallLayout.LabelBkOpacity = value;

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OpacityValue)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Opacity)));


            }
        }


        
        public double LabelBkCornerRadius
        {
            get
            {
                return HallLayout.LabelBkCornerRadius;
            }
            set
            {
                HallLayout.LabelBkCornerRadius = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LabelBkCornerRadius)));
            }
        }



        public Thickness LabelMargin
        {
            get
            {
                double top, left, bottom, right = 0;
                left = LabelPaddingLeft;
                top = LabelPaddingTop - this.HallLayout.Font.GetTextCapsLine(SampleLabel);

                if (LabelPaddingRight - this.HallLayout.Font.ShadowXOffset < 0)
                    right = this.HallLayout.Font.ShadowXOffset;
                else
                    right = LabelPaddingRight;

                if (LabelPaddingBottom - this.HallLayout.Font.ShadowYOffset < 0)
                    bottom = this.HallLayout.Font.ShadowYOffset;
                else
                    bottom = LabelPaddingBottom;
                
                return new Thickness(left, top, right, bottom);
            }
        }

        public string SampleLabel
        {
            get
            {
                if (HallLayout.Font.AllCaps)
                    return "SampleText".ToUpper();
                else
                    return "SampleText";

            }
        }



        public double LabelPaddingTop
        {
            get
            {
                return HallLayout.Margin.MarginTop;
            }
            set
            {
                var margin = HallLayout.Margin;
                margin.MarginTop = value;
                HallLayout.Margin = margin;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LabelMargin)));
            }
        }

        public double LabelPaddingLeft
        {
            get
            {
                return HallLayout.Margin.MarginLeft;
            }
            set
            {
                var margin = HallLayout.Margin;
                margin.MarginLeft = value;
                HallLayout.Margin = margin;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LabelMargin)));
            }
        }

        public double LabelPaddingBottom
        {
            get
            {
                return HallLayout.Margin.MarginBottom;
            }
            set
            {
                var margin = HallLayout.Margin;
                margin.MarginBottom = value;
                HallLayout.Margin = margin;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LabelMargin)));
            }
        }

        public double LabelPaddingRight
        {
            get
            {
                return HallLayout.Margin.MarginRight;
            }
            set
            {
                var margin = HallLayout.Margin;
                margin.MarginRight = value;
                HallLayout.Margin = margin;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LabelMargin)));
            }
        }

        public string MarginUnit
        {
            get => "px";
        }
        public string RadiusUnit
        {
            get => "px";
        }
        
        /// <exclude>Excluded</exclude>
        System.Windows.Media.FontFamily _FontFamily;
        public FontFamily FontFamily
        {
            get
            {
                return _FontFamily;

            }
        }

        /// <exclude>Excluded</exclude>
        FontStyle _FontStyle;
        public FontStyle FontStyle
        {
            get
            {
                return _FontStyle;
            }
        }

        /// <exclude>Excluded</exclude>
        FontWeight _FontWeight;
        public FontWeight FontWeight
        {
            get
            {
                return _FontWeight;
            }
        }
        /// <exclude>Excluded</exclude>
        Color _StrokeFill;
        Brush _StrokeFillBrush;
        public Brush StrokeFill
        {
            get
            {
                return _StrokeFillBrush;
            }
        }

        /// <exclude>Excluded</exclude>
        double _StrokeThickness;
        public double StrokeThickness
        {
            get
            {
                return _StrokeThickness;
            }
        }

        /// <exclude>Excluded</exclude>
        bool _AllCaps;
        public bool AllCaps
        {
            get
            {
                return _AllCaps;
            }
        }

        /// <exclude>Excluded</exclude>
        Color _Foreground;

        /// <exclude>Excluded</exclude>
        Brush _ForegroundBrush;
        public Brush Foreground
        {
            get
            {
                return _ForegroundBrush;
            }
        }

        /// <exclude>Excluded</exclude>
        System.Windows.Media.Effects.DropShadowEffect _DropShadowEffect;
        public System.Windows.Media.Effects.DropShadowEffect DropShadowEffect
        {
            get
            {
                return _DropShadowEffect;
            }
        }

        /// <exclude>Excluded</exclude>
        double _FontSize;
        /// <MetaDataID>{e6273d48-ed55-4313-9ee7-8803ba40ecd1}</MetaDataID>
        public double FontSize
        {
            get
            {
                return _FontSize;

            }
        }

        /// <exclude>Excluded</exclude>
        double _FontSpacing;
        public double FontSpacing
        {
            get
            {
                return _FontSpacing;
            }
        }



        FontData? LabelFont
        {
            get
            {
                return FontPresantation.Font;
            }
        }
        private void UpdateCanvasItemValues()
        {

            FontFamily fontFamily = null;
            if (LabelFont != null)
                fontFamily = FontData.FontFamilies[LabelFont.Value.FontFamilyName];
            else
                fontFamily = null;

            if (fontFamily != _FontFamily)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontFamily = fontFamily;
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontFamily)));
            }

            FontStyle fontStyle = default(FontStyle);

            if (LabelFont != null)
                fontStyle = (FontStyle)new FontStyleConverter().ConvertFromString(LabelFont.Value.FontStyle);
            else
                fontStyle = default(FontStyle);
            if (fontStyle != _FontStyle)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontStyle = fontStyle;
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontStyle)));
            }

            FontWeight fontWeight = default(FontWeight);
            if (LabelFont != null)
                fontWeight = (FontWeight)new FontWeightConverter().ConvertFromString(LabelFont.Value.FontWeight);
            else
                fontWeight = default(FontWeight);

            if (fontWeight != _FontWeight)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontWeight = fontWeight;
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontWeight)));

            }

            double strokeThickness = 0;
            if (LabelFont != null && LabelFont.Value.Stroke)
                strokeThickness = LabelFont.Value.StrokeThickness;
            else
                strokeThickness = 0;

            if (strokeThickness != _StrokeThickness)
            {
                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _StrokeThickness = strokeThickness;
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(StrokeThickness)));
            }

            bool allCaps = false;
            if (LabelFont != null)
                allCaps = LabelFont.Value.AllCaps;
            else
                allCaps = false;

            if (allCaps != _AllCaps)
            {
                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _AllCaps = allCaps;
                    stateTransition.Consistent = true;
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(AllCaps)));
            }

            Color strokeFill = default(Color);

            if (LabelFont != null)
            {
                if (LabelFont.Value.StrokeFill != null && LabelFont.Value.Stroke)
                    strokeFill = (Color)ColorConverter.ConvertFromString(LabelFont.Value.StrokeFill);
                else
                    strokeFill = _Foreground;
            }
            else
                strokeFill = _Foreground;

            if (strokeFill != _StrokeFill)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _StrokeFill = strokeFill;
                    stateTransition.Consistent = true;
                }

                _StrokeFillBrush = new SolidColorBrush(strokeFill);
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(StrokeFill)));
            }


            System.Windows.Media.Effects.DropShadowEffect dropShadowEffect = null;

            if (LabelFont != null)
            {
                double deltaX = LabelFont.Value.ShadowXOffset;
                double deltaY = LabelFont.Value.ShadowXOffset;

                if (LabelFont.Value.ShadowColor == null && deltaX == 0 && deltaY == 0)
                    dropShadowEffect = null;
                else
                {

                    deltaY = -deltaY;
                    var rad = Math.Atan2(deltaY, deltaX);

                    var deg = rad * (180 / Math.PI);

                    if (deg < 0)
                        deg = 360 + deg;

                    double a = deltaX;
                    double b = deltaY;
                    if (a < 0)
                        a = -a;
                    if (b < 0)
                        b = -b;
                    double depth = Math.Sqrt(a * a + b * b);

                    var shaddow = new System.Windows.Media.Effects.DropShadowEffect();
                    shaddow.Direction = deg;
                    shaddow.ShadowDepth = depth;

                    shaddow.Opacity = 1;
                    shaddow.BlurRadius = LabelFont.Value.BlurRadius;
                    shaddow.Color = (Color)ColorConverter.ConvertFromString(LabelFont.Value.ShadowColor);
                    dropShadowEffect = shaddow;
                }
            }
            else
                dropShadowEffect = null;

            if (dropShadowEffect != _DropShadowEffect)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _DropShadowEffect = dropShadowEffect;
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DropShadowEffect)));
            }

            Color foreground = default(Color);

            if (LabelFont != null)
                foreground = (Color)ColorConverter.ConvertFromString(LabelFont.Value.Foreground);
            else
                foreground = default(Color);

            if (foreground != _Foreground)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _Foreground = foreground;
                    _ForegroundBrush = new SolidColorBrush(foreground);

                    stateTransition.Consistent = true;
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Foreground)));
            }

            double fontSize = 0;
            if (LabelFont != null)
                fontSize = LabelFont.Value.FontSize;
            else
                fontSize = 0;

            if (fontSize != _FontSize)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontSize = fontSize;
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontSize)));
            }

            double fontSpacing = 0;
            if (LabelFont != null)
                fontSpacing = LabelFont.Value.FontSpacing;
            else
                fontSpacing = 0;

            if (fontSpacing != _FontSpacing)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontSpacing = fontSpacing;
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontSpacing)));
            }
        }


        private void _FontPresantation_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            UpdateCanvasItemValues();
            if (LabelFont != null)
                HallLayout.Font = LabelFont.Value;
            //WindowsBaseEx.FontData font = new WindowsBaseEx.FontData() { AllCaps = true, BlurRadius = 0, FontFamilyName = "Airbag Free", FontSize = 22, Shadow = true, ShadowColor = "#FFD3D3D3", ShadowXOffset = 2, ShadowYOffset = 2 };
        }

        // FontPresantation


        /// <exclude>Excluded</exclude>
        bool _Portrait = true;
        public bool Portrait
        {
            get
            {
                return _Portrait;
            }
            set
            {
                if (value)
                    Landscape = false;

                _Portrait = value;
                if (_Portrait)
                {
                    PaperSize paperSize = new PaperSize(PaperType.Custom, PaperType.Custom.ToString(), mmToPixel(_PageWidth), mmToPixel(PageHeight), "px");
                    _HallLayout.Width = paperSize.Width;
                    _HallLayout.Height = paperSize.Height;
                    HallLayoutSizeChanged?.Invoke(_HallLayout, paperSize);
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutWidth)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutHeight)));

                }
    
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Portrait)));
            }
        }

        /// <exclude>Excluded</exclude>
        bool _Landscape;

        public bool Landscape
        {
            get
            {
                return _Landscape;
            }
            set
            {
                if (value)
                    Portrait = false;
                _Landscape = value;
                if (_Landscape)
                {
                    PaperSize paperSize = new PaperSize(PaperType.Custom, PaperType.Custom.ToString(), mmToPixel(PageHeight), mmToPixel(_PageWidth), "px");
                    _HallLayout.Width = paperSize.Width;
                    _HallLayout.Height = paperSize.Height;
                    HallLayoutSizeChanged?.Invoke(_HallLayout, paperSize);
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutWidth)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutHeight)));

                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Landscape)));
            }
        }

        

        /// <exclude>Excluded</exclude>
        static System.Collections.Generic.List<PaperSize> _PaperSizes = null;
        /// <MetaDataID>{031f7ff7-7702-4bb2-98b3-c22c1e3aa55d}</MetaDataID>
        public List<PaperSize> PaperSizes
        {
            get
            {
                if (_PaperSizes == null)
                {
                    _PaperSizes = new System.Collections.Generic.List<PaperSize>()
                    {
                        new PaperSize(PaperType.Letter,"Letter (216mm x 280mm)",216,280,"mm"),
                        new PaperSize(PaperType.Legal,"Legal (216mm x 355.6mm)",216,355.6,"mm" ),
                        new PaperSize(PaperType.Tabloid,"Tabloid (280mm x 432mm)",280,432 ,"mm"),
                        new PaperSize(PaperType.Statement,"Statement (140mm x 216mm)",140,216 ,"mm"),
                        new PaperSize(PaperType.A3,"A3 (297mm x 420mm)",297,420 ,"mm"),
                        new PaperSize(PaperType.A4,"A4 (210mm x 297mm)",210,297 ,"mm"),
                        new PaperSize(PaperType.A5,"A5 (148mm x 210mm)",148,210 ,"mm"),
                        new PaperSize(PaperType.B4,"B4 (250mm x 353mm)" ,250,353,"mm"),
                        new PaperSize(PaperType.B5,"B5 (176mm x 250mm)" ,176,250,"mm"),
                        new PaperSize(PaperType.HDTV,"HDTV (286mm x 508mm)" ,286,508,"mm"),
                        new PaperSize(PaperType.Custom,"Custom" ,0,0,"mm")
                    };
                }
                return _PaperSizes;
            }
        }


        /// <exclude>Excluded</exclude>
        double _PageWidth;
        public double PageWidth
        {
            set
            {
                _PageWidth = value;
                if (_PageWidth > 0)
                {
                    PaperSize paperSize = new PaperSize(PaperType.Custom,
                                                                PaperType.Custom.ToString(), mmToPixel(_PageWidth), mmToPixel(PageHeight), "px");

                    
                    //PageStyle.PageSize = paperSize;
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PageWidth)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutWidth)));
            }
            get
            {
                return _PageWidth;
            }
        }


   
        /// <exclude>Excluded</exclude>
        double _PageHeight;

        public event PropertyChangedEventHandler PropertyChanged;

        public double PageHeight
        {
            set
            {
                _PageHeight = value;
                if (_PageHeight > 0)
                {
                    PaperSize paperSize = new PaperSize(PaperType.Custom,
                                                        PaperType.Custom.ToString(), mmToPixel(_PageWidth), mmToPixel(PageHeight), "px");

                    

                    //PageStyle.PageSize = paperSize;
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PageHeight)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutHeight)));
            }
            get
            {

                return _PageHeight;
            }
        }

        public double BorderThickness
        {
            get
            {
                return 10;
            }
        }

        public double HallLayoutHeight
        {
            get
            {
                if(Portrait)
                    return mmToPixel (PageHeight)+2*BorderThickness;
                else
                    return mmToPixel(PageWidth)+ 2 * BorderThickness;
            }
        }

        public double HallLayoutWidth
        {
            get
            {
                if (Portrait)
                    return mmToPixel(PageWidth)+ 2 * BorderThickness;
                else
                    return mmToPixel(PageHeight)+ 2 * BorderThickness;
            }
        }


        PaperSize _SelectedPaperSize;
        public PaperSize SelectedPaperSize
        {
            get
            {
                return _SelectedPaperSize;
            }
            set
            {


                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this,TransactionOption.Supported))
                {
                    _SelectedPaperSize = value;
                    if (_SelectedPaperSize.Width != 0 && _SelectedPaperSize.Height != 0)
                    {
                        PageWidth = _SelectedPaperSize.Width;
                        PageHeight = _SelectedPaperSize.Height;

                        if (_Portrait)
                        {
                            PaperSize paperSize = new PaperSize(PaperType.Custom, PaperType.Custom.ToString(), mmToPixel(_PageWidth), mmToPixel(PageHeight), "px");
                            _HallLayout.Width = paperSize.Width;
                            _HallLayout.Height = paperSize.Height;
                            HallLayoutSizeChanged?.Invoke(_HallLayout, paperSize);
                            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutWidth)));
                            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutHeight)));


                        }
                        if (_Landscape)
                        {
                            PaperSize paperSize = new PaperSize(PaperType.Custom, PaperType.Custom.ToString(), mmToPixel(PageHeight), mmToPixel(_PageWidth), "px");
                            _HallLayout.Width = paperSize.Width;
                            _HallLayout.Height = paperSize.Height;
                            HallLayoutSizeChanged?.Invoke(_HallLayout, paperSize);
                            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutWidth)));
                            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutHeight)));

                        }

                    }


                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsCustomPaperSize)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedPaperSize)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PortraitLandscapeIsEnabled)));

            }

        }

        public bool PortraitLandscapeIsEnabled
        {
            get
            {
                if (_SelectedPaperSize.PaperType != PaperType.Custom)
                    return true;
                else
                    return false;
            }
        }

        public bool IsCustomPaperSize
        {
            get
            {
                if (SelectedPaperSize.PaperType == PaperType.Custom)
                    return true;
                else
                    return false;

            }
        }



        /// <exclude>Excluded</exclude>
        string _Unit = "mm";
        public string Unit
        {
            get
            {
                return _Unit;
            }
            set
            {
                _Unit = value;
            }
        }

        /// <exclude>Excluded</exclude>
        double _ZoomPercentage;
        public double ZoomPercentage
        {
            get
            {
                return _ZoomPercentage;
            }
            set
            {
                _ZoomPercentage = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentage)));
            }
        }
        FontPresantation _FontPresantation;
        public FontPresantation FontPresantation
        {
            get
            {
                return _FontPresantation;
            }
        }

        public WPFUIElementObjectBind.RelayCommand HallLayoutShapeLabelFont { get; protected set; }



        public static double PixelToMM(double px)
        {
            var pixpermm = (double)new System.Windows.LengthConverter().ConvertFromString("1in") / 25.4;
            return px / pixpermm;

            //return (int)Math.Round(px / pixpermm, 1);
        }

        public static double mmToPixel(double mm)
        {
            var pixpermm = (double)new System.Windows.LengthConverter().ConvertFromString("1in") / 25.4;
            return mm * pixpermm;

            //return (int)Math.Round(mm * pixpermm, 1);
        }



    }
}
