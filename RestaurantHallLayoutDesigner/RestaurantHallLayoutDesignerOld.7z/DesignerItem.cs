﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Linq;
using System.Windows.Media;
using FloorLayoutDesigner.Controls;
using OOAdvantech.Transactions;
using FloorLayoutDesigner;
using RestaurantHallLayoutModel;
using System.Collections.Generic;
using OOAdvantech.PersistenceLayer;

namespace FloorLayoutDesigner
{
    //These attributes identify the types of the named parts that are used for templating
    /// <MetaDataID>{99f297d6-bc59-4c78-b2c1-2da41a72c000}</MetaDataID>
    [TemplatePart(Name = "PART_DragThumb", Type = typeof(DragThumb))]
    [TemplatePart(Name = "PART_ResizeDecorator", Type = typeof(Control))]
    [TemplatePart(Name = "PART_ConnectorDecorator", Type = typeof(Control))]
    [TemplatePart(Name = "PART_ContentPresenter", Type = typeof(ContentPresenter))]
    public class DesignerItem : ContentControl, ISelectable, IGroupable, ICommandTargetObject
    {
        #region ID
        private Guid id;
        internal Shape Shape;

        public Guid ID
        {
            get { return id; }
        }
        #endregion

        #region ParentID
        public Guid ParentID
        {
            get { return (Guid)GetValue(ParentIDProperty); }
            set { SetValue(ParentIDProperty, value); }
        }
        public static readonly DependencyProperty ParentIDProperty = DependencyProperty.Register("ParentID", typeof(Guid), typeof(DesignerItem));
        #endregion

        #region IsGroup
        public bool IsGroup
        {
            get { return (bool)GetValue(IsGroupProperty); }
            set { SetValue(IsGroupProperty, value); }
        }
        public static readonly DependencyProperty IsGroupProperty =
            DependencyProperty.Register("IsGroup", typeof(bool), typeof(DesignerItem));
        #endregion

        #region IsSelected Property

        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set
            {

                if (this.GetObjectContext() == null)
                {

                }



                SetValue(IsSelectedProperty, value);
            }
        }
        public static readonly DependencyProperty IsSelectedProperty =
          DependencyProperty.Register("IsSelected",
                                       typeof(bool),
                                       typeof(DesignerItem),
                                       new FrameworkPropertyMetadata(false));

        #endregion

        #region DragThumbTemplate Property

        // can be used to replace the default template for the DragThumb
        public static readonly DependencyProperty DragThumbTemplateProperty =
            DependencyProperty.RegisterAttached("DragThumbTemplate", typeof(ControlTemplate), typeof(DesignerItem));

        public static ControlTemplate GetDragThumbTemplate(UIElement element)
        {
            return (ControlTemplate)element.GetValue(DragThumbTemplateProperty);
        }

        public static void SetDragThumbTemplate(UIElement element, ControlTemplate value)
        {
            element.SetValue(DragThumbTemplateProperty, value);
        }

        #endregion

        #region ConnectorDecoratorTemplate Property

        // can be used to replace the default template for the ConnectorDecorator
        public static readonly DependencyProperty ConnectorDecoratorTemplateProperty =
            DependencyProperty.RegisterAttached("ConnectorDecoratorTemplate", typeof(ControlTemplate), typeof(DesignerItem));

        public static ControlTemplate GetConnectorDecoratorTemplate(UIElement element)
        {
            return (ControlTemplate)element.GetValue(ConnectorDecoratorTemplateProperty);
        }

        public static void SetConnectorDecoratorTemplate(UIElement element, ControlTemplate value)
        {
            element.SetValue(ConnectorDecoratorTemplateProperty, value);
        }

        #endregion

        #region IsDragConnectionOver

        // while drag connection procedure is ongoing and the mouse moves over 
        // this item this value is true; if true the ConnectorDecorator is triggered
        // to be visible, see template
        public bool IsDragConnectionOver
        {
            get { return (bool)GetValue(IsDragConnectionOverProperty); }
            set { SetValue(IsDragConnectionOverProperty, value); }
        }

       internal bool HasChanges
        {
            get
            {
                bool hasChanges = false;
                if (Content is SvgHostControl)
                {
                    hasChanges |= Shape.Left != Canvas.GetLeft(this) + ((Content as SvgHostControl).svgHost).TranslatePoint(new Point(0, 0), this).X;
                    hasChanges |= Shape.Top != Canvas.GetTop(this) + ((Content as SvgHostControl).svgHost).TranslatePoint(new Point(0, 0), this).Y;
                    if ((Content as SvgHostControl).svgHost.ActualWidth == 0 && (Content as SvgHostControl).svgHost.ActualHeight == 0)
                    {
                        hasChanges |= Shape.Width != Width;
                        hasChanges |= Shape.Height != Height;
                    }
                    else
                    {
                        hasChanges |= Shape.Width != (Content as SvgHostControl).svgHost.ActualWidth;
                        hasChanges |= Shape.Height != (Content as SvgHostControl).svgHost.ActualHeight;
                    }
                    hasChanges |= Shape.ZIndex != Canvas.GetZIndex(this);
                }
                else
                {
                    hasChanges |= Shape.Left != Canvas.GetLeft(this);
                    hasChanges |= Shape.Top != Canvas.GetTop(this);
                    hasChanges |= Shape.Width != Width;
                    hasChanges |= Shape.Height != Height;
                    hasChanges |= Shape.ZIndex != Canvas.GetZIndex(this);

                }
                return hasChanges;
            }
        }
        internal void UpdateShape(FloorLayoutDesigner.UndoRedoCommand undoRedoCommand)
        {

            if (Shape != null)
            {
                
                

                    this.GetObjectContext().RunUnderContextTransaction(new Action(() =>
                    {
                        if (undoRedoCommand != null)
                            this.MarkUndo(undoRedoCommand);

                        using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
                        {
                            if (Content is SvgHostControl)
                            {
                                Shape.Left = Canvas.GetLeft(this) + ((Content as SvgHostControl).svgHost).TranslatePoint(new Point(0, 0), this).X;
                                Shape.Top = Canvas.GetTop(this) + ((Content as SvgHostControl).svgHost).TranslatePoint(new Point(0, 0), this).Y;
                                if ((Content as SvgHostControl).svgHost.ActualWidth == 0 && (Content as SvgHostControl).svgHost.ActualHeight == 0)
                                {
                                    Shape.Width = Width;
                                    Shape.Height = Height;
                                }
                                else
                                {
                                    Shape.Width = (Content as SvgHostControl).svgHost.ActualWidth;
                                    Shape.Height = (Content as SvgHostControl).svgHost.ActualHeight;
                                }
                                Shape.ZIndex = Canvas.GetZIndex(this);
                            }
                            else
                            {

                                Shape.Left = Canvas.GetLeft(this);
                                Shape.Top = Canvas.GetTop(this);
                                Shape.Width = this.ActualWidth;
                                Shape.Height = this.ActualHeight;
                                if (Shape.Width == 0 && Shape.Height == 0)
                                {
                                    Shape.Width = Width;
                                    Shape.Height = Height;
                                }
                                Shape.ZIndex = Canvas.GetZIndex(this);

                            }

                            stateTransition.Consistent = true;
                        }
                        if (undoRedoCommand != null)
                            this.MarkRedo(undoRedoCommand);

                        else
                        {

                        }
                    }));
               
            }
        }

        public static readonly DependencyProperty IsDragConnectionOverProperty =
            DependencyProperty.Register("IsDragConnectionOver",
                                         typeof(bool),
                                         typeof(DesignerItem),
                                         new FrameworkPropertyMetadata(false));

        #endregion

        static DesignerItem()
        {
            // set the key to reference the style for this control
            FrameworkElement.DefaultStyleKeyProperty.OverrideMetadata(
                typeof(DesignerItem), new FrameworkPropertyMetadata(typeof(DesignerItem)));
        }

        public DesignerItem(Guid id)
        {
            this.id = id;
            this.Loaded += new RoutedEventHandler(DesignerItem_Loaded);
            this.SizeChanged += DesignerItem_SizeChanged;

            ResourceDictionary resourceDictionary = new ResourceDictionary();

            Resources.Source = new Uri(@"pack://application:,,,/RestaurantHallLayoutDesigner;component/RestaurantHallLayoutDesigner.xaml");
        }

        private void DesignerItem_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            try
            {
                ContentPresenter contentPresenter =
                         this.Template.FindName("PART_ContentPresenter", this) as ContentPresenter;
                if (contentPresenter != null)
                {
                    UserControl contentVisual = VisualTreeHelper.GetChild(contentPresenter, 0) as UserControl;
                    if (contentVisual != null)
                    {
                        contentVisual.Height = e.NewSize.Height;
                        contentVisual.Width = e.NewSize.Width;
                    }
                }
                // UpdateShape(null);
            }
            catch (Exception error)
            {
            }
        }

        public DesignerItem()
            : this(Guid.NewGuid())
        {
        }

        public DesignerItem(Shape shape) : this(new Guid(shape.Identity))
        {
            this.Shape = shape;

            Width = shape.Width;//  Double.Parse(itemXML.Element("Width").Value, CultureInfo.InvariantCulture);
            Height = shape.Height;// Double.Parse(itemXML.Element("Height").Value, CultureInfo.InvariantCulture);
            //item.ParentID = new Guid(itemXML.Element("ParentID").Value);
            //item.IsGroup = Boolean.Parse(itemXML.Element("IsGroup").Value);
            Canvas.SetLeft(this, shape.Left);
            Canvas.SetTop(this, shape.Top);
            //Canvas.SetTop(item, Double.Parse(itemXML.Element("Top").Value, CultureInfo.InvariantCulture) + OffsetY);
            Canvas.SetZIndex(this, shape.ZIndex);
            //Object content = XamlReader.Load(XmlReader.Create(new StringReader(itemXML.Element("Content").Value)));
            //item.Content = content;
            //return item;
        }

        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseDown(e);
            DesignerCanvas designer = VisualTreeHelper.GetParent(this) as DesignerCanvas;

            // update selection
            if (designer != null)
            {
                if ((Keyboard.Modifiers & (ModifierKeys.Shift | ModifierKeys.Control)) != ModifierKeys.None)
                    if (this.IsSelected)
                    {
                        designer.SelectionService.RemoveFromSelection(this);
                    }
                    else
                    {
                        designer.SelectionService.AddToSelection(this);
                    }
                else if (!this.IsSelected)
                {
                    designer.SelectionService.SelectItem(this);
                }
                Focus();
            }

            e.Handled = false;
        }

        void DesignerItem_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                if (base.Template != null)
                {
                    ContentPresenter contentPresenter =
                        this.Template.FindName("PART_ContentPresenter", this) as ContentPresenter;
                    if (contentPresenter != null)
                    {
                        UIElement contentVisual = VisualTreeHelper.GetChild(contentPresenter, 0) as UIElement;
                        if (contentVisual != null)
                        {
                            DragThumb thumb = this.Template.FindName("PART_DragThumb", this) as DragThumb;
                            if (thumb != null)
                            {
                                ControlTemplate template =
                                    DesignerItem.GetDragThumbTemplate(contentVisual) as ControlTemplate;
                                if (template != null)
                                    thumb.Template = template;
                            }

                        }
                    }
                }
            }
            catch (Exception error)
            {
            }
        }

        public void Undo(UndoRedoCommand command)
        {
            var state = command.UndoData.Where(x => x.CommandTargetObject == this).Select(x => x.Data).FirstOrDefault() as System.Collections.Generic.Dictionary<string, object>;
            Shape.Left = (double)state["Left"];
            Shape.Top = (double)state["Top"];
            Shape.Width = (double)state["Width"];
            Shape.Height = (double)state["Height"];
            Shape.ZIndex = (int)state["ZIndex"];

            Width = Shape.Width;
            Height = Shape.Height;
            Canvas.SetLeft(this, Shape.Left);
            Canvas.SetTop(this, Shape.Top);
            Canvas.SetZIndex(this, Shape.ZIndex);

            if (Shape is ShapesGroup)
            {
                var shapes = state["GroupedSaphes"] as System.Collections.Generic.List<Shape>;
                List<Shape> removeShapes = new List<Shape>();
                foreach (var shape in (Shape as ShapesGroup).Shapes)
                {
                    if (!shapes.Contains(shape))
                        removeShapes.Add(shape);
                }
                List<Shape> addShapes = new List<Shape>();
                foreach (var shape in shapes)
                {
                    if (!(Shape as ShapesGroup).Shapes.Contains(shape))
                        addShapes.Add(shape);
                }

                foreach (var removeShape in removeShapes)
                {
                    if (Parent != null)
                    {

                        var dItem = (from designerItem in (Parent as DesignerCanvas).Children.OfType<DesignerItem>()
                                     where designerItem.Shape == removeShape
                                     select designerItem).FirstOrDefault();
                        dItem.ParentID = Guid.Empty;
                    }
                    (Shape as ShapesGroup).RemoveGroupedShape(removeShape);
                }

                foreach (var addShape in addShapes)
                {
                    if (Parent != null)
                    {
                        var dItem = (from designerItem in (Parent as DesignerCanvas).Children.OfType<DesignerItem>()
                                     where designerItem.Shape == addShape
                                     select designerItem).FirstOrDefault();
                        dItem.ParentID = this.id;
                    }
                    if (!OOAdvantech.PersistenceLayer.ObjectStorage.IsPersistent(addShape))
                        ObjectStorage.GetStorageOfObject(Shape).CommitTransientObjectState(addShape);

                    (Shape as ShapesGroup).AddGroupedShape(addShape);
                }

                this.InvalidateVisual();
            }


        }

        public void Redo(UndoRedoCommand command)
        {
            var state = command.RedoData.Where(x => x.CommandTargetObject == this).Select(x => x.Data).FirstOrDefault() as System.Collections.Generic.Dictionary<string, object>;
            //var state = command.RedoData[this] as System.Collections.Generic.Dictionary<string, object>;
            Shape.Left = (double)state["Left"];
            Shape.Top = (double)state["Top"];
            Shape.Width = (double)state["Width"];
            Shape.Height = (double)state["Height"];
            Shape.ZIndex = (int)state["ZIndex"];

            Width = Shape.Width;
            Height = Shape.Height;
            Canvas.SetLeft(this, Shape.Left);
            Canvas.SetTop(this, Shape.Top);
            Canvas.SetZIndex(this, Shape.ZIndex);
            if (Shape is ShapesGroup)
            {
                var shapes = state["GroupedSaphes"] as System.Collections.Generic.List<Shape>;
                List<Shape> removeShapes = new List<Shape>();
                foreach (var shape in (Shape as ShapesGroup).Shapes)
                {
                    if (!shapes.Contains(shape))
                        removeShapes.Add(shape);
                }
                List<Shape> addShapes = new List<Shape>();
                foreach (var shape in shapes)
                {
                    if (!(Shape as ShapesGroup).Shapes.Contains(shape))
                        addShapes.Add(shape);
                }

                foreach (var removeShape in removeShapes)
                {
                    if (Parent != null)
                    {
                        var dItem = (from designerItem in (Parent as DesignerCanvas).Children.OfType<DesignerItem>()
                                     where designerItem.Shape == removeShape
                                     select designerItem).FirstOrDefault();
                        dItem.ParentID = Guid.Empty;
                    }
                    (Shape as ShapesGroup).RemoveGroupedShape(removeShape);
                }

                foreach (var addShape in addShapes)
                {
                    if (Parent != null)
                    {
                        var dItem = (from designerItem in (Parent as DesignerCanvas).Children.OfType<DesignerItem>()
                                     where designerItem.Shape == addShape
                                     select designerItem).FirstOrDefault();
                        dItem.ParentID = this.id;
                    }

                    if (!OOAdvantech.PersistenceLayer.ObjectStorage.IsPersistent(addShape))
                        ObjectStorage.GetStorageOfObject(Shape).CommitTransientObjectState(addShape);

                    (Shape as ShapesGroup).AddGroupedShape(addShape);
                }

                this.InvalidateVisual();
            }
        }

        public void MarkUndo(UndoRedoCommand command)
        {
            System.Collections.Generic.Dictionary<string, object> state = new System.Collections.Generic.Dictionary<string, object>();
            state["Left"] = Shape.Left;
            state["Top"] = Shape.Top;
            state["Width"] = Shape.Width;
            state["Height"] = Shape.Height;
            state["ZIndex"] = Shape.ZIndex;
            if (Shape is ShapesGroup)
                state["GroupedSaphes"] = (Shape as ShapesGroup).Shapes.ToList();


            command.UndoData.Insert(0, new CommandTarget() { CommandTargetObject = this, Data = state });
            //command.UndoData[this] = state;



        }

        public void MarkRedo(UndoRedoCommand command)
        {
            System.Collections.Generic.Dictionary<string, object> state = new System.Collections.Generic.Dictionary<string, object>();
            state["Left"] = Shape.Left;
            state["Top"] = Shape.Top;
            state["Width"] = Shape.Width;
            state["Height"] = Shape.Height;
            state["ZIndex"] = Shape.ZIndex;

            if (Shape is ShapesGroup)
                state["GroupedSaphes"] = (Shape as ShapesGroup).Shapes.ToList();

            command.RedoData.Insert(0, new CommandTarget() { CommandTargetObject = this, Data = state });
            //command.RedoData[this] = state;



        }
    }
}
