﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FloorLayoutDesigner.ViewModel
{
    /// <MetaDataID>{02fcfad8-6722-4e7b-ba63-033eeee228d9}</MetaDataID>
    public class HallLayoutViewModel
    {

    }
}
