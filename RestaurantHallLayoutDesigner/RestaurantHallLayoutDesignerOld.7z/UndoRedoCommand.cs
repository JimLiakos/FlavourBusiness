﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FloorLayoutDesigner
{

    public class CommandTarget
    {
        public ICommandTargetObject CommandTargetObject;

        public object Data;

    }
    public class UndoRedoCommand
    {
        public List<CommandTarget> UndoData = new List<CommandTarget>();

        internal void ReplaceCommandTarget(ICommandTargetObject commandTargetObject)
        {
            foreach(var commandTarget in UndoData.Where(x=>x.CommandTargetObject.ID==commandTargetObject.ID))
                commandTarget.CommandTargetObject = commandTargetObject;

            foreach (var commandTarget in RedoData.Where(x => x.CommandTargetObject.ID == commandTargetObject.ID))
                commandTarget.CommandTargetObject = commandTargetObject;

        }

        public List<CommandTarget> RedoData =new List<CommandTarget>();

        internal void Undo()
        {
            foreach (var commandTargetObject in UndoData.Select(x=>x.CommandTargetObject))
                commandTargetObject.Undo(this);
        }

        internal void Redo()
        {
            foreach (var commandTargetObject in RedoData.Select(x => x.CommandTargetObject))
                commandTargetObject.Redo(this);
        }
    }

    public interface ICommandTargetObject
    {
        Guid ID { get; }
        void Undo(UndoRedoCommand command);
        void Redo(UndoRedoCommand command);

        void MarkUndo(UndoRedoCommand command); 
        void MarkRedo(UndoRedoCommand command);

    }
}
