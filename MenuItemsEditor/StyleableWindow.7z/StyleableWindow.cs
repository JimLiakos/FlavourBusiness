﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WinInterop = System.Windows.Interop;



namespace StyleableWindow
{
    /// <MetaDataID>{765665a6-3e84-4cdd-ac89-cfd3fd44e656}</MetaDataID>
    [TemplatePart(Name = "MinimizeBox", Type = typeof(UIElement))]
    [TemplatePart(Name = "MaximizeBox", Type = typeof(UIElement))]
    [TemplatePart(Name = "SubTitle", Type = typeof(System.Windows.Controls.Label))]
    [TemplatePart(Name = "ShadowBorder", Type = typeof(System.Windows.Controls.Border))]
    [TemplatePart(Name = "LanguageButton", Type = typeof(System.Windows.Controls.Button))]

    public class Window : System.Windows.Window
    {

        public virtual void OnBack()
        {

        }
        static Window()
        {
            string uriString = string.Format(@"/{0};component/CustomWindowStyle.xaml", typeof(Window).Assembly.GetName().Name);
            Application.Current.Resources.MergedDictionaries.Add(new ResourceDictionary { Source = new Uri(uriString, UriKind.Relative) });
        }

        public Window()
        {
            Style = Application.Current.Resources["CustomWindowStyle"] as Style;
            Loaded += StyleableWindow_Loaded;
            SourceInitialized += new EventHandler(win_SourceInitialized);
            StateChanged += Window_StateChanged;
        }
        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            if (DataContext is WPFUIElementObjectBind.ObjectContext)
                (DataContext as WPFUIElementObjectBind.ObjectContext).Initialize(this);
        }

        private void Window_StateChanged(object sender, EventArgs e)
        {
            switch (this.WindowState)
            {
                case WindowState.Maximized:
                    {
                        if (Template != null)
                        {
                            System.Windows.Controls.Border border = Template.FindName("ShadowBorder", this) as System.Windows.Controls.Border;
                            if (border != null)
                            {
                                border.BorderThickness = new Thickness(0);
                                border.CornerRadius = new CornerRadius(0);
                            }
                        }
                        break;
                    }
                case WindowState.Minimized:
                    // Do your stuff
                    break;
                case WindowState.Normal:
                    {
                        if (Template != null)
                        {
                            System.Windows.Controls.Border border = Template.FindName("ShadowBorder", this) as System.Windows.Controls.Border;
                            if (border != null)
                            {
                                border.BorderThickness = new Thickness(10);
                                border.CornerRadius = new CornerRadius(10);
                            }
                        }

                        break;
                    }
            }

        }

        double OrgHeight;
        private void StyleableWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (Template != null)
            {
                OrgHeight = Height;
                UIElement uiElement = Template.FindName("MaximizeBox", this) as UIElement;
                if (uiElement != null)
                {
                    if (MaximizeBox)
                        uiElement.Visibility = Visibility.Visible;
                    else
                        uiElement.Visibility = Visibility.Collapsed;
                }

                uiElement = Template.FindName("MinimizeBox", this) as UIElement;
                if (uiElement != null)
                {
                    if (MinimizeBox)
                        uiElement.Visibility = Visibility.Visible;
                    else
                        uiElement.Visibility = Visibility.Collapsed;
                }

                System.Windows.Controls.Button languageButton = Template.FindName("LanguageButton", this) as System.Windows.Controls.Button;
                if (languageButton != null)
                {
                    if (LanguageButton)
                        languageButton.Visibility = Visibility.Visible;
                    else
                        languageButton.Visibility = Visibility.Hidden;

                    languageButton.Click += LanguageButton_Click;
                }



                System.Windows.Controls.Label label = Template.FindName("SubTitle", this) as System.Windows.Controls.Label;

                System.Windows.Controls.Grid windowArea = Template.FindName("WindowArea", this) as System.Windows.Controls.Grid;

                System.Windows.Controls.Button backButton = Template.FindName("BackButton", this) as System.Windows.Controls.Button;

                Point windowMargin = windowArea.TranslatePoint(new Point(0, 0), this);



                if (backButton != null)
                {
                    backButton.Visibility = BackButtonVisibility;
                    backButton.Click += BackButton_Click;
                }

                if (label != null)
                {
                    if (string.IsNullOrWhiteSpace(SubTitle))
                    {
                        label.Visibility = Visibility.Collapsed;
                        Height -= 30;
                    }
                    else
                    {
                        label.Visibility = Visibility.Visible;
                        Height += 30;
                    }
                    label.Content = SubTitle;
                }

                UpdateLayout();
                System.Windows.Controls.Grid titleBarArea = Template.FindName("TitleBarArea", this) as System.Windows.Controls.Grid;
                if (titleBarArea != null)
                {
                    System.Windows.Controls.Border border = Template.FindName("ShadowBorder", this) as System.Windows.Controls.Border;
                    double borderThickness = windowMargin.X;
                    if (border != null)
                        borderThickness += border.BorderThickness.Top;

                    double titleBarAreaActualHeight = titleBarArea.ActualHeight;
                    double windowCaptionHeight = SystemParameters.WindowCaptionHeight;
                    Height = OrgHeight + (titleBarAreaActualHeight + borderThickness - SystemParameters.WindowCaptionHeight) + 2;
                }
            }

        }

        private void LanguageButton_Click(object sender, RoutedEventArgs e)
        {

            System.Windows.Controls.Primitives.Popup languagePopup = Template.FindName("LanguagePopup", this) as System.Windows.Controls.Primitives.Popup;
            if (languagePopup != null)
            {
                System.Windows.Shapes.Line titleBarLine = Template.FindName("TitleBarLine", this) as System.Windows.Shapes.Line;
                System.Windows.Controls.Button languageButton = Template.FindName("LanguageButton", this) as System.Windows.Controls.Button;
                languagePopup.VerticalOffset =titleBarLine.TranslatePoint(new Point(0, 0), this).Y - languageButton.TranslatePoint(new Point(0, 0), this).Y;
                languagePopup.VerticalOffset += 5;
                languagePopup.HorizontalOffset = languageButton.ActualWidth;
                //var w = languagePopup.Width;


                languagePopup.IsOpen = true;
            }


        }

        public static readonly DependencyProperty LanguagePopupProperty =
         DependencyProperty.Register("LanguagePopup", typeof(System.Windows.Controls.ContentControl), typeof(StyleableWindow.Window), new UIPropertyMetadata(null));

        public System.Windows.Controls.ContentControl LanguagePopup
        {
            get { return (System.Windows.Controls.ContentControl)GetValue(LanguagePopupProperty); }
            set { SetValue(LanguagePopupProperty, value); }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OnBack();
            }
            catch (Exception error)
            {
            }

        }

        public static readonly DependencyProperty MinimizeBoxProperty = DependencyProperty.Register(
                                                           "MinimizeBox",
                                                           typeof(bool),
                                                           typeof(Window),
                                                           new UIPropertyMetadata(true, new PropertyChangedCallback(OnMinimizeBoxChanged)));
        private static void OnMinimizeBoxChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            System.Windows.Window window = d as System.Windows.Window;
            if (((bool)e.NewValue))
            {
                if (window.Template != null)
                {
                    UIElement uiElement = window.Template.FindName("MinimizeBox", window) as UIElement;
                    if (uiElement != null)
                        uiElement.Visibility = Visibility.Visible;
                }
            }
            else
            {
                if (window.Template != null)
                {
                    UIElement uiElement = window.Template.FindName("MinimizeBox", window) as UIElement;
                    if (uiElement != null)
                        uiElement.Visibility = Visibility.Collapsed;
                }

            }
        }
        [Description("Minimize button is visible"), Category("Common")]
        public bool MinimizeBox
        {
            get { return (bool)GetValue(MinimizeBoxProperty); }
            set { SetValue(MinimizeBoxProperty, value); }
        }


        public static readonly DependencyProperty MaximizeBoxProperty = DependencyProperty.Register(
                                                           "MaximizeBox",
                                                           typeof(bool),
                                                           typeof(Window),
                                                           new UIPropertyMetadata(true, new PropertyChangedCallback(OnMaximizeBoxChanged)));
        private static void OnMaximizeBoxChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            System.Windows.Window window = d as System.Windows.Window;
            if (((bool)e.NewValue))
            {
                if (window.Template != null)
                {
                    UIElement uiElement = window.Template.FindName("MaximizeBox", window) as UIElement;
                    if (uiElement != null)
                        uiElement.Visibility = Visibility.Visible;
                }
            }
            else
            {
                if (window.Template != null)
                {
                    UIElement uiElement = window.Template.FindName("MaximizeBox", window) as UIElement;
                    if (uiElement != null)
                        uiElement.Visibility = Visibility.Collapsed;
                }
            }
        }
        [Description("Maximize button is visible"), Category("Common")]
        public bool MaximizeBox
        {
            get { return (bool)GetValue(MaximizeBoxProperty); }
            set { SetValue(MaximizeBoxProperty, value); }
        }




        public static readonly DependencyProperty SubTitleProperty = DependencyProperty.Register(
                                                           "SubTitle",
                                                           typeof(string),
                                                           typeof(Window),
                                                           new UIPropertyMetadata("", new PropertyChangedCallback(OnSubTitleChanged)));
        private static void OnSubTitleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            StyleableWindow.Window window = d as StyleableWindow.Window;
            if (window.Template != null)
            {
                System.Windows.Controls.Label label = window.Template.FindName("SubTitle", window) as System.Windows.Controls.Label;
                if (label != null)
                {
                    if (string.IsNullOrWhiteSpace(e.NewValue as string))
                    {
                        label.Visibility = Visibility.Collapsed;
                        window.Height -= 30;
                    }
                    else
                    {
                        label.Visibility = Visibility.Visible;
                        window.Height += 30;
                    }
                    label.Content = e.NewValue as string;

                    window.UpdateLayout();
                    System.Windows.Controls.Grid titleBarArea = window.Template.FindName("TitleBarArea", window) as System.Windows.Controls.Grid;
                    if (titleBarArea != null)
                    {
                        double titleBarAreaActualHeight = titleBarArea.ActualHeight;
                        double windowCaptionHeight = SystemParameters.WindowCaptionHeight;
                        window.Height = window.OrgHeight + (titleBarAreaActualHeight - SystemParameters.WindowCaptionHeight);
                    }


                }
            }
        }

        [Description("Title bar sub title"), Category("Common")]
        public String SubTitle
        {
            get { return GetValue(SubTitleProperty) as string; }
            set { SetValue(SubTitleProperty, value); }
        }




        public static readonly DependencyProperty LanguageButtonProperty = DependencyProperty.Register(
                                                           "LanguageButton",
                                                           typeof(bool),
                                                           typeof(Window),
                                                           new UIPropertyMetadata(false, new PropertyChangedCallback(OnLanguageButtonChanged)));
        private static void OnLanguageButtonChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

            System.Windows.Window window = d as System.Windows.Window;
            if (((bool)e.NewValue))
            {
                if (window.Template != null)
                {
                    UIElement uiElement = window.Template.FindName("LanguageButton", window) as UIElement;
                    if (uiElement != null)
                        uiElement.Visibility = Visibility.Visible;
                }
            }
            else
            {
                if (window.Template != null)
                {
                    UIElement uiElement = window.Template.FindName("LanguageButton", window) as UIElement;
                    if (uiElement != null)
                        uiElement.Visibility = Visibility.Hidden;
                }

            }

        }


        [Description("Language button visibility"), Category("Common")]
        public bool LanguageButton
        {
            get { return (bool)GetValue(LanguageButtonProperty); }
            set { SetValue(LanguageButtonProperty, value); }
        }




        public static readonly DependencyProperty BackButtonVisibilityProperty = DependencyProperty.Register(
                                                        "BackButtonVisibility",
                                                        typeof(Visibility),
                                                        typeof(Window),
                                                        new UIPropertyMetadata(Visibility.Collapsed, new PropertyChangedCallback(OnBackButtonVisibilityChanged)));
        private static void OnBackButtonVisibilityChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            StyleableWindow.Window window = d as StyleableWindow.Window;
            if (window.Template != null)
            {
                System.Windows.Controls.Button button = window.Template.FindName("BackButton", window) as System.Windows.Controls.Button;
                if (button != null)
                {
                    button.Visibility = (Visibility)e.NewValue;
                    window.UpdateLayout();
                }
            }
        }

        [Description("Back button visibility"), Category("Common")]
        public Visibility BackButtonVisibility
        {
            get { return (Visibility)GetValue(BackButtonVisibilityProperty); }
            set { SetValue(BackButtonVisibilityProperty, value); }
        }


        void win_SourceInitialized(object sender, EventArgs e)
        {
            System.IntPtr handle = (new WinInterop.WindowInteropHelper(this)).Handle;
            WinInterop.HwndSource.FromHwnd(handle).AddHook(new WinInterop.HwndSourceHook(WindowProc));

        }



        //public override void OnApplyTemplate()
        //{
        //    System.IntPtr handle = (new WinInterop.WindowInteropHelper(this)).Handle;
        //    WinInterop.HwndSource.FromHwnd(handle).AddHook(new WinInterop.HwndSourceHook(WindowProc));
        //}

        private static System.IntPtr WindowProc(
              System.IntPtr hwnd,
              int msg,
              System.IntPtr wParam,
              System.IntPtr lParam,
              ref bool handled)
        {
            switch (msg)
            {
                case 0x0024:
                    WmGetMinMaxInfo(hwnd, lParam);
                    handled = true;
                    break;
            }

            return (System.IntPtr)0;
        }

        private static void WmGetMinMaxInfo(System.IntPtr hwnd, System.IntPtr lParam)
        {

            MINMAXINFO mmi = (MINMAXINFO)Marshal.PtrToStructure(lParam, typeof(MINMAXINFO));

            // Adjust the maximized size and position to fit the work area of the correct monitor
            int MONITOR_DEFAULTTONEAREST = 0x00000002;
            System.IntPtr monitor = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);

            if (monitor != System.IntPtr.Zero)
            {

                MONITORINFO monitorInfo = new MONITORINFO();
                GetMonitorInfo(monitor, monitorInfo);
                RECT rcWorkArea = monitorInfo.rcWork;
                RECT rcMonitorArea = monitorInfo.rcMonitor;
                mmi.ptMaxPosition.x = Math.Abs(rcWorkArea.left - rcMonitorArea.left);
                mmi.ptMaxPosition.y = Math.Abs(rcWorkArea.top - rcMonitorArea.top);
                mmi.ptMaxSize.x = Math.Abs(rcWorkArea.right - rcWorkArea.left);
                mmi.ptMaxSize.y = Math.Abs(rcWorkArea.bottom - rcWorkArea.top);
            }

            Marshal.StructureToPtr(mmi, lParam, true);
        }


        /// <summary>
        /// POINT aka POINTAPI
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            /// <summary>
            /// x coordinate of point.
            /// </summary>
            public int x;
            /// <summary>
            /// y coordinate of point.
            /// </summary>
            public int y;

            /// <summary>
            /// Construct a point of coordinates (x,y).
            /// </summary>
            public POINT(int x, int y)
            {
                this.x = x;
                this.y = y;
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MINMAXINFO
        {
            public POINT ptReserved;
            public POINT ptMaxSize;
            public POINT ptMaxPosition;
            public POINT ptMinTrackSize;
            public POINT ptMaxTrackSize;
        };




        /// <summary>
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public class MONITORINFO
        {
            /// <summary>
            /// </summary>            
            public int cbSize = Marshal.SizeOf(typeof(MONITORINFO));

            /// <summary>
            /// </summary>            
            public RECT rcMonitor = new RECT();

            /// <summary>
            /// </summary>            
            public RECT rcWork = new RECT();

            /// <summary>
            /// </summary>            
            public int dwFlags = 0;
        }


        /// <summary> Win32 </summary>
        [StructLayout(LayoutKind.Sequential, Pack = 0)]
        public struct RECT
        {
            /// <summary> Win32 </summary>
            public int left;
            /// <summary> Win32 </summary>
            public int top;
            /// <summary> Win32 </summary>
            public int right;
            /// <summary> Win32 </summary>
            public int bottom;

            /// <summary> Win32 </summary>
            public static readonly RECT Empty = new RECT();

            /// <summary> Win32 </summary>
            public int Width
            {
                get { return Math.Abs(right - left); }  // Abs needed for BIDI OS
            }
            /// <summary> Win32 </summary>
            public int Height
            {
                get { return bottom - top; }
            }

            /// <summary> Win32 </summary>
            public RECT(int left, int top, int right, int bottom)
            {
                this.left = left;
                this.top = top;
                this.right = right;
                this.bottom = bottom;
            }


            /// <summary> Win32 </summary>
            public RECT(RECT rcSrc)
            {
                this.left = rcSrc.left;
                this.top = rcSrc.top;
                this.right = rcSrc.right;
                this.bottom = rcSrc.bottom;
            }

            /// <summary> Win32 </summary>
            public bool IsEmpty
            {
                get
                {
                    // BUGBUG : On Bidi OS (hebrew arabic) left > right
                    return left >= right || top >= bottom;
                }
            }
            /// <summary> Return a user friendly representation of this struct </summary>
            public override string ToString()
            {
                if (this == RECT.Empty) { return "RECT {Empty}"; }
                return "RECT { left : " + left + " / top : " + top + " / right : " + right + " / bottom : " + bottom + " }";
            }

            /// <summary> Determine if 2 RECT are equal (deep compare) </summary>
            public override bool Equals(object obj)
            {
                if (!(obj is Rect)) { return false; }
                return (this == (RECT)obj);
            }

            /// <summary>Return the HashCode for this struct (not garanteed to be unique)</summary>
            public override int GetHashCode()
            {
                return left.GetHashCode() + top.GetHashCode() + right.GetHashCode() + bottom.GetHashCode();
            }


            /// <summary> Determine if 2 RECT are equal (deep compare)</summary>
            public static bool operator ==(RECT rect1, RECT rect2)
            {
                return (rect1.left == rect2.left && rect1.top == rect2.top && rect1.right == rect2.right && rect1.bottom == rect2.bottom);
            }

            /// <summary> Determine if 2 RECT are different(deep compare)</summary>
            public static bool operator !=(RECT rect1, RECT rect2)
            {
                return !(rect1 == rect2);
            }


        }

        [DllImport("user32")]
        internal static extern bool GetMonitorInfo(IntPtr hMonitor, MONITORINFO lpmi);

        /// <summary>
        /// 
        /// </summary>
        [DllImport("User32")]
        internal static extern IntPtr MonitorFromWindow(IntPtr handle, int flags);
    }
}
