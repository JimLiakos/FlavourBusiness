﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;

namespace StyleableWindow
{
    /// <MetaDataID>{a835fe73-9322-47d9-b604-db15a22f506e}</MetaDataID>
    public class DialogContentControl : System.Windows.Controls.ContentControl, System.ComponentModel.INotifyPropertyChanged
    {
        System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
        public DialogContentControl()
        {
            OKClickCommand = new WPFUIElementObjectBind.RelayCommand((object sender) =>
            {
                var objectContext = this.GetObjectContext();
                if (objectContext != null)
                    objectContext.OnOKCommand.CallExecute(sender);
            }, (object sender) => PreventTransactionCommit);

            CancelClickCommand = new WPFUIElementObjectBind.RelayCommand((object sender) =>
            {
                var objectContext = this.GetObjectContext();
                if (objectContext != null)
                    objectContext.OnCancelCommand.CallExecute(sender);
            });


            dispatcherTimer.Tick += DispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 1000);
            dispatcherTimer.Start();

        }

        private void DispatcherTimer_Tick(object sender, EventArgs e)
        {
            OKClickCommand.Refresh();

        }

        DialogButtons _Buttons = DialogButtons.OKCancel;

        public Visibility OkButtonVisibility
        {
            get
            {
                if (_Buttons == DialogButtons.OK || _Buttons == DialogButtons.OKCancel)
                    return Visibility.Visible;
                else
                    return Visibility.Collapsed;
            }
        }

        public Visibility CancelButtonVisibility
        {
            get
            {
                if (_Buttons == DialogButtons.OKCancel)
                    return Visibility.Visible;
                else
                    return Visibility.Collapsed;
            }
        }
        //static DialogContentControl()
        //{
        //    DefaultStyleKeyProperty.OverrideMetadata(typeof(DialogContentControl), new FrameworkPropertyMetadata(typeof(DialogContentControl)));
        //}

        public System.Windows.Controls.ContentControl Footer
        {
            get { return (System.Windows.Controls.ContentControl)GetValue(FooterProperty); }
            set { SetValue(FooterProperty, value); }
        }
        public WPFUIElementObjectBind.RelayCommand OKClickCommand { get; protected set; }
        public WPFUIElementObjectBind.RelayCommand CancelClickCommand { get; protected set; }



        // Using a DependencyProperty as the backing store for Footer.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FooterProperty =
            DependencyProperty.Register("Footer", typeof(System.Windows.Controls.ContentControl), typeof(DialogContentControl), new UIPropertyMetadata(null));


        public bool PreventTransactionCommit
        {
            get
            {



                object value = GetValue(PreventTransactionCommitProperty);
                if (value is bool)
                {
                    if ((bool)value)
                    {
                        if (this.GetObjectContext() == null)
                            return false;

                        //System.Diagnostics.Debug.WriteLine(string.Format("PreventTransactionCommit {0}", !this.GetObjectContext().OpenStateTransitionsInOtherThreads));
                        return !this.GetObjectContext().OpenStateTransitionsInOtherThreads;
                    }
                    //System.Diagnostics.Debug.WriteLine(string.Format("PreventTransactionCommit {0}", (bool)value));
                    return (bool)value;
                }
                else
                {
                    //System.Diagnostics.Debug.WriteLine(string.Format("PreventTransactionCommit {0}", true));
                    return true;
                }
            }
            set
            {

                SetValue(PreventTransactionCommitProperty, value);
            }
        }
        public static readonly DependencyProperty PreventTransactionCommitProperty =
                    DependencyProperty.Register(
                    "PreventTransactionCommit",
                    typeof(bool),
                    typeof(DialogContentControl),
                    new PropertyMetadata(true, new PropertyChangedCallback(PreventTransactionCommitPropertyChangedCallback)));

        public event PropertyChangedEventHandler PropertyChanged;

        public static void PreventTransactionCommitPropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

            if (d is DialogContentControl)
                (d as DialogContentControl).PreventTransactionCommitPropertyChanged();
        }
        private void PreventTransactionCommitPropertyChanged()
        {
            OKClickCommand.Refresh();
        }


        public DialogButtons Buttons
        {
            get
            {
                object value = GetValue(ButtonsProperty);
                if (value is DialogButtons)
                {
                    return (DialogButtons)value;
                }
                else
                {
                    //System.Diagnostics.Debug.WriteLine(string.Format("PreventTransactionCommit {0}", true));
                    return DialogButtons.OKCancel;
                }
            }
            set
            {

                SetValue(ButtonsProperty, value);
            }
        }
        public static readonly DependencyProperty ButtonsProperty =
                    DependencyProperty.Register(
                    "DialogButtons",
                    typeof(DialogButtons),
                    typeof(DialogContentControl),
                    new PropertyMetadata(DialogButtons.OKCancel, new PropertyChangedCallback(ButtonsPropertyChangedCallback)));



        public static void ButtonsPropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

            if (d is DialogContentControl)
                (d as DialogContentControl).ButtonsPropertyChanged();
        }
        private void ButtonsPropertyChanged()
        {
            _Buttons = Buttons;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OkButtonVisibility)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CancelButtonVisibility)));
        }


        public enum DialogButtons
        {
            //
            // Summary:
            //     The message box displays an OK button.
            OK = 0,
            //
            // Summary:
            //     The message box displays OK and Cancel buttons.
            OKCancel = 1,
            ////
            //// Summary:
            ////     The message box displays Yes, No, and Cancel buttons.
            //YesNoCancel = 3,
            ////
            //// Summary:
            ////     The message box displays Yes and No buttons.
            //YesNo = 4
        }

    }
}
