﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace MenuDesigner.Controls
{
    /// <MetaDataID>{48f1dd53-fee2-4ca9-aa41-086222e7c2e5}</MetaDataID>
    public class ResizeThumb : Thumb
    {
        /// <MetaDataID>{efd1809d-0af3-4378-9e70-8a90c3354e12}</MetaDataID>
        public ResizeThumb()
        {
            
            
            base.DragDelta += new DragDeltaEventHandler(ResizeThumb_DragDelta);
        }

        /// <MetaDataID>{a787fb83-d1de-408a-a176-656cf27d9d7f}</MetaDataID>
        void ResizeThumb_DragDelta(object sender, DragDeltaEventArgs e)
        {
            //DesignerItem designerItem = this.DataContext as DesignerItem;
            //DesignerCanvas designer = VisualTreeHelper.GetParent(designerItem) as DesignerCanvas;

            //if (designerItem != null && designer != null && designerItem.IsSelected)
            //{
            //    double minLeft, minTop, minDeltaHorizontal, minDeltaVertical;
            //    double dragDeltaVertical, dragDeltaHorizontal, scale;

            //    IEnumerable<DesignerItem> selectedDesignerItems = designer.SelectionService.CurrentSelection.OfType<DesignerItem>();

            //    CalculateDragLimits(selectedDesignerItems, out minLeft, out minTop,
            //                        out minDeltaHorizontal, out minDeltaVertical);

            //    foreach (DesignerItem item in selectedDesignerItems)
            //    {
            //        if (item != null && item.ParentID == Guid.Empty)
            //        {
            //            switch (base.VerticalAlignment)
            //            {
            //                case VerticalAlignment.Bottom:
            //                    dragDeltaVertical = Math.Min(-e.VerticalChange, minDeltaVertical);
            //                    scale = (item.ActualHeight - dragDeltaVertical) / item.ActualHeight;
            //                    DragBottom(scale, item, designer.SelectionService);
            //                    break;
            //                case VerticalAlignment.Top:
            //                    double top = Canvas.GetTop(item);
            //                    dragDeltaVertical = Math.Min(Math.Max(-minTop, e.VerticalChange), minDeltaVertical);
            //                    scale = (item.ActualHeight - dragDeltaVertical) / item.ActualHeight;
            //                    DragTop(scale, item, designer.SelectionService);
            //                    break;
            //                default:
            //                    break;
            //            }

            //            switch (base.HorizontalAlignment)
            //            {
            //                case HorizontalAlignment.Left:
            //                    double left = Canvas.GetLeft(item);
            //                    dragDeltaHorizontal = Math.Min(Math.Max(-minLeft, e.HorizontalChange), minDeltaHorizontal);
            //                    scale = (item.ActualWidth - dragDeltaHorizontal) / item.ActualWidth;
            //                    DragLeft(scale, item, designer.SelectionService);
            //                    break;
            //                case HorizontalAlignment.Right:
            //                    dragDeltaHorizontal = Math.Min(-e.HorizontalChange, minDeltaHorizontal);
            //                    scale = (item.ActualWidth - dragDeltaHorizontal) / item.ActualWidth;
            //                    DragRight(scale, item, designer.SelectionService);
            //                    break;
            //                default:
            //                    break;
            //            }
            //        }
            //    }
            //    e.Handled = true;
            //}
        }

        #region Helper methods

        ///// <MetaDataID>{aeeca2c2-d47b-4373-8bfd-197ec67e92ad}</MetaDataID>
        //private void DragLeft(double scale, DesignerItem item, SelectionService selectionService)
        //{
        //    IEnumerable<DesignerItem> groupItems = selectionService.GetGroupMembers(item).Cast<DesignerItem>();

        //    double groupLeft = Canvas.GetLeft(item) + item.Width;
        //    foreach (DesignerItem groupItem in groupItems)
        //    {
        //        double groupItemLeft = Canvas.GetLeft(groupItem);
        //        double delta = (groupLeft - groupItemLeft) * (scale - 1);
        //        Canvas.SetLeft(groupItem, groupItemLeft - delta);
        //        groupItem.Width = groupItem.ActualWidth * scale;
        //    }
        //}

        ///// <MetaDataID>{2112fae6-36e6-4105-9aa5-bb610e63d1ca}</MetaDataID>
        //private void DragTop(double scale, DesignerItem item, SelectionService selectionService)
        //{
        //    IEnumerable<DesignerItem> groupItems = selectionService.GetGroupMembers(item).Cast<DesignerItem>();
        //    double groupBottom = Canvas.GetTop(item) + item.Height;
        //    foreach (DesignerItem groupItem in groupItems)
        //    {
        //        double groupItemTop = Canvas.GetTop(groupItem);
        //        double delta = (groupBottom - groupItemTop) * (scale - 1);
        //        Canvas.SetTop(groupItem, groupItemTop - delta);
        //        groupItem.Height = groupItem.ActualHeight * scale;
        //    }
        //}

        ///// <MetaDataID>{a38fca49-9497-43fe-a4af-a0b39b0a242f}</MetaDataID>
        //private void DragRight(double scale, DesignerItem item, SelectionService selectionService)
        //{
        //    IEnumerable<DesignerItem> groupItems = selectionService.GetGroupMembers(item).Cast<DesignerItem>();

        //    double groupLeft = Canvas.GetLeft(item);
        //    foreach (DesignerItem groupItem in groupItems)
        //    {
        //        double groupItemLeft = Canvas.GetLeft(groupItem);
        //        double delta = (groupItemLeft - groupLeft) * (scale - 1);

        //        Canvas.SetLeft(groupItem, groupItemLeft + delta);
        //        groupItem.Width = groupItem.ActualWidth * scale;
        //    }
        //}

        ///// <MetaDataID>{5f3720cd-9d71-4c2c-b447-ebdb5fbebe09}</MetaDataID>
        //private void DragBottom(double scale, DesignerItem item, SelectionService selectionService)
        //{
        //    IEnumerable<DesignerItem> groupItems = selectionService.GetGroupMembers(item).Cast<DesignerItem>();
        //    double groupTop = Canvas.GetTop(item);
        //    foreach (DesignerItem groupItem in groupItems)
        //    {
        //        double groupItemTop = Canvas.GetTop(groupItem);
        //        double delta = (groupItemTop - groupTop) * (scale - 1);

        //        Canvas.SetTop(groupItem, groupItemTop + delta);
        //        groupItem.Height = groupItem.ActualHeight * scale;
        //    }
        //}

        ///// <MetaDataID>{f3f1eeb9-4cc8-471f-b0d3-b49d0da3a244}</MetaDataID>
        //private void CalculateDragLimits(IEnumerable<DesignerItem> selectedItems, out double minLeft, out double minTop, out double minDeltaHorizontal, out double minDeltaVertical)
        //{
        //    minLeft = double.MaxValue;
        //    minTop = double.MaxValue;
        //    minDeltaHorizontal = double.MaxValue;
        //    minDeltaVertical = double.MaxValue;

        //    // drag limits are set by these parameters: canvas top, canvas left, minHeight, minWidth
        //    // calculate min value for each parameter for each item
        //    foreach (DesignerItem item in selectedItems)
        //    {
        //        double left = Canvas.GetLeft(item);
        //        double top = Canvas.GetTop(item);

        //        minLeft = double.IsNaN(left) ? 0 : Math.Min(left, minLeft);
        //        minTop = double.IsNaN(top) ? 0 : Math.Min(top, minTop);

        //        minDeltaVertical = Math.Min(minDeltaVertical, item.ActualHeight - item.MinHeight);
        //        minDeltaHorizontal = Math.Min(minDeltaHorizontal, item.ActualWidth - item.MinWidth);
        //    }
        //}

        #endregion
    }
}
