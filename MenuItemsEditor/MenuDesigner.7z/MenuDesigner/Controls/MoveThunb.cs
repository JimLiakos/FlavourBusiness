﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Windows.Media;

namespace MenuDesigner.Controls
{
    /// <MetaDataID>{c50d6507-cb24-4e75-be52-b8566aa93836}</MetaDataID>
    public class MoveThunb : System.Windows.Controls.Grid
    {
        public MoveThunb()
        {
            
        }

        System.Windows.Point OrgMousePosition;
        System.Windows.Point OrgDesignerItemPosition;

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            OrgMousePosition = e.GetPosition(null);
            DesignerItem designerItem = this.DataContext as DesignerItem;
            DesignerCanvas designer = VisualTreeHelper.GetParent(designerItem) as DesignerCanvas;
            OrgDesignerItemPosition = new System.Windows.Point(DesignerCanvas.GetLeft(designerItem), DesignerCanvas.GetTop(designerItem));

            base.OnMouseLeftButtonDown(e);
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            //if(e.LeftButton==MouseButtonState.Pressed)
            //{
            //    System.Windows.Point mousePosition = e.GetPosition(null);
            //    DesignerItem designerItem = this.DataContext as DesignerItem;


            //    DesignerCanvas.SetLeft(designerItem, OrgDesignerItemPosition.X + mousePosition.X - OrgMousePosition.X);
            //    DesignerCanvas.SetTop(designerItem, OrgDesignerItemPosition.Y + mousePosition.Y - OrgMousePosition.Y);
            //}
            base.OnMouseMove(e);
        }
    }
}
