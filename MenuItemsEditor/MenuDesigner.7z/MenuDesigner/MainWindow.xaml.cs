﻿using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;
using OOAdvantech.Transactions;
using System.Windows.Input;

namespace MenuDesigner
{
    /// <MetaDataID>{9b85f465-b03e-4989-ad24-8e8cf77440f8}</MetaDataID>
    public partial class MainWindow : Window
    {
        /// <MetaDataID>{2d99df56-f6a0-4e8b-b377-d5e0f67db175}</MetaDataID>
        public MainWindow()
        {
            InitializeComponent();
            this.GetObjectContext().Initialize(this);

            this.GetObjectContext().SetContextInstance(MenuDesignerViewModel);
            //MyPageDesigner.SelectionDesignerCanvas = MyDesigner;
            
            Loaded += MainWindow_Loaded;
            MenuDesignerViewModel.SignInUser.SwitchOnOffPopupView += SignInUser_Maximizing;
            LocationChanged += (object sender, System.EventArgs e) =>
            {
                if(SignInWindow!=null)
                    SignInWindow.Hide();
            };
        }


        private void SignInUser_Maximizing(object sender, System.EventArgs e)
        {
            if (SignInWindow.IsVisible)
                SignInWindow.Hide();
            else
                SignInWindow.Show(SignInToolBarItem.PointToScreen(new Point(SignInToolBarItem.ActualWidth / 2, SignInToolBarItem.ActualHeight + 4)));
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {

            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            SignInWindow = new Views.SignInWindow(this.GetDataContextObject<ViewModel.FlavourBusinessManagerViewModel>().SignInUser);
            SignInWindow.Owner = win;

            SignInWindow.PreLoad(SignInToolBarItem.PointToScreen(new Point(SignInToolBarItem.ActualWidth / 2, SignInToolBarItem.ActualHeight + 4)));
        }

        ViewModel.FlavourBusinessManagerViewModel MenuDesignerViewModel = new ViewModel.FlavourBusinessManagerViewModel();

        ViewModel.BookViewModel BookViewModel
        {
            get
            {
                return MenuDesignerViewModel.Menu;
            }
        }
      
        
        private void TreeViewSelectedItemChanged(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TreeViewItem item = sender as System.Windows.Controls.TreeViewItem;
            if (item != null)
            {
                item.BringIntoView();
                e.Handled = true;
            }
        }
       
        Views.SignInWindow SignInWindow;
    }
}
