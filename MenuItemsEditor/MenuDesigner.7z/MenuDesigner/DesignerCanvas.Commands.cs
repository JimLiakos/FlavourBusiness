﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Xml;
using System.Xml.Linq;
using MenuDesigner.ViewModel;
using Microsoft.Win32;
using OOAdvantech.Transactions;

namespace MenuDesigner
{
    /// <MetaDataID>MenuDesigner.DesignerCanvas</MetaDataID>
    public partial class DesignerCanvas
    {
        /// <MetaDataID>{1b487ffe-831d-4a71-8d47-581e0c933de9}</MetaDataID>
        public static RoutedCommand Group = new RoutedCommand();
        /// <MetaDataID>{9a27df37-8a41-4698-81d4-52c309a7b649}</MetaDataID>
        public static RoutedCommand Ungroup = new RoutedCommand();
        /// <MetaDataID>{de33c6fd-202e-49cd-87a3-c9f384c54e68}</MetaDataID>
        public static RoutedCommand BringForward = new RoutedCommand();
        /// <MetaDataID>{63e5a0bb-e3f2-485d-ba4f-c681c2ec38dd}</MetaDataID>
        public static RoutedCommand BringToFront = new RoutedCommand();
        /// <MetaDataID>{c67dc082-f91f-4364-bbd6-93b47c4d9ade}</MetaDataID>
        public static RoutedCommand SendBackward = new RoutedCommand();
        /// <MetaDataID>{ce02933f-3d74-4a7b-980f-9675c6ef214e}</MetaDataID>
        public static RoutedCommand SendToBack = new RoutedCommand();
        /// <MetaDataID>{f6127aaa-2b3b-445a-ab30-77681d82c7d6}</MetaDataID>
        public static RoutedCommand AlignTop = new RoutedCommand();
        /// <MetaDataID>{d90c85bf-7df3-41b4-8bc8-03014f35f6d2}</MetaDataID>
        public static RoutedCommand AlignVerticalCenters = new RoutedCommand();
        /// <MetaDataID>{9c8825cc-2bcb-4cb1-95db-a2b724353d6e}</MetaDataID>
        public static RoutedCommand AlignBottom = new RoutedCommand();
        /// <MetaDataID>{de6d2773-c3f5-4989-b98b-6d8d84c16f03}</MetaDataID>
        public static RoutedCommand AlignLeft = new RoutedCommand();
        /// <MetaDataID>{2e14119f-9e6c-4cc3-9b51-f662fee58b28}</MetaDataID>
        public static RoutedCommand AlignHorizontalCenters = new RoutedCommand();
        /// <MetaDataID>{32f15748-b6e3-4c02-81e8-ecbf62ec29c8}</MetaDataID>
        public static RoutedCommand AlignRight = new RoutedCommand();
        /// <MetaDataID>{e38733d9-0a2f-4cfc-88ae-08241be9e6e3}</MetaDataID>
        public static RoutedCommand DistributeHorizontal = new RoutedCommand();
        /// <MetaDataID>{ad39b42c-c0dd-4d51-9849-99497dd503d7}</MetaDataID>
        public static RoutedCommand DistributeVertical = new RoutedCommand();
        /// <MetaDataID>{d74d6464-c817-4c41-97bd-4dfac20ef0e6}</MetaDataID>
        public static RoutedCommand SelectAll = new RoutedCommand();


        /// <MetaDataID>{fe4c59fc-c3d0-42c9-b977-862a9676c261}</MetaDataID>
        public static RoutedCommand MoveToNextPage = new RoutedCommand();
        /// <MetaDataID>{4e25fa65-8b6e-4d53-829c-708f9bcd0999}</MetaDataID>
        public static RoutedCommand MoveToPreviousPage = new RoutedCommand();

        /// <MetaDataID>{d08857af-83c8-4239-bf96-2cd03c691fcf}</MetaDataID>
        public static RoutedCommand ShrinkLineSpace = new RoutedCommand();
        /// <MetaDataID>{a58d78fb-c241-42d0-9363-e34dd86d27e1}</MetaDataID>
        public static RoutedCommand ExpandLineSpace = new RoutedCommand();
        /// <MetaDataID>{1cb789cb-9812-4988-bfd8-02ba1d199ffb}</MetaDataID>
        public static RoutedCommand ResetLineSpace = new RoutedCommand();

        /// <MetaDataID>{bc94c3ca-789a-4261-beb2-aec4dcdfccb4}</MetaDataID>
        public static RoutedCommand ShrinkPageFontsSizes = new RoutedCommand();
        /// <MetaDataID>{d44e1943-3628-4b42-ad01-ee682c9f6848}</MetaDataID>
        public static RoutedCommand ExpandPageFontsSizes = new RoutedCommand();
        /// <MetaDataID>{7166a97c-4277-4c38-9fd0-6d985eb3bc4e}</MetaDataID>
        public static RoutedCommand ResetPageFontsSizes = new RoutedCommand();

        /// <MetaDataID>{b1e05e66-96b1-495d-82f5-0c92de157da7}</MetaDataID>
        public static RoutedCommand TitleHeadingFonts = new RoutedCommand();

        /// <MetaDataID>{a9248b60-6edc-4b27-8063-06b6ebf06656}</MetaDataID>
        public static RoutedCommand NormalHeadingFonts = new RoutedCommand();

        /// <MetaDataID>{9585386c-82e0-468f-9816-972ed85c1385}</MetaDataID>
        public static RoutedCommand SubHeadingFonts = new RoutedCommand();

        /// <MetaDataID>{4121d7df-a5d1-4125-ada3-efb11d9a747f}</MetaDataID>
        public static RoutedCommand DownloadStyleSheet = new RoutedCommand();

        /// <MetaDataID>{f47a6dc5-1cf5-407d-abec-ff0e9717dc4e}</MetaDataID>
        public static RoutedCommand SignInSignUp = new RoutedCommand();

        /// <MetaDataID>{f9bc506e-3ae2-435c-9a59-37f9d4904421}</MetaDataID>
        public static RoutedCommand FoodItemNameFonts = new RoutedCommand();

        /// <MetaDataID>{ba9d90c3-b296-4395-9e34-51dfcbeea289}</MetaDataID>
        public static RoutedCommand FoodItemDescriptionFonts = new RoutedCommand();

        /// <MetaDataID>{7d1a65a0-b144-4daf-8d76-45400295522c}</MetaDataID>
        public static RoutedCommand FoodItemExtrasFonts = new RoutedCommand();

        /// <MetaDataID>{94940fce-7697-454e-9709-e48bfdd38773}</MetaDataID>
        public static RoutedCommand FoodItemPriceFonts = new RoutedCommand();

        /// <MetaDataID>{d9d7beba-e152-40f5-9b47-bd4cd59a27d3}</MetaDataID>
        public static RoutedCommand LayoutOptions = new RoutedCommand();


        /// <MetaDataID>{3e557c6a-5f22-4be4-aede-f1d0da65d0db}</MetaDataID>
        public static RoutedCommand BorderSelection = new RoutedCommand();


        /// <MetaDataID>{0dc3a1c0-397a-4dbd-a927-20502caf2395}</MetaDataID>
        public static RoutedCommand BackgroundSelection = new RoutedCommand();

        /// <MetaDataID>{ae9b0813-9de8-4d00-b5e2-9064b70d2d79}</MetaDataID>
        public static RoutedCommand HeadingTypesAccents = new RoutedCommand();


        /// <MetaDataID>{ba29407c-cdc0-4df3-b78d-e253565695d1}</MetaDataID>
        public static RoutedCommand StyleSelection = new RoutedCommand();


        /// <MetaDataID>{77eb2f6d-825b-4f1c-8fd3-4506f330824a}</MetaDataID>
        protected override void OnChildDesiredSizeChanged(UIElement child)
        {
            base.OnChildDesiredSizeChanged(child);
        }
        /// <MetaDataID>{d4f7f06d-39a3-4d5f-a36f-4dafe7d4f7c2}</MetaDataID>
        bool SuspendChildChangeConsum;
        /// <MetaDataID>{17a11e2d-4fdf-4eb3-ae22-fa7f160a1e14}</MetaDataID>
        protected override void OnVisualChildrenChanged(DependencyObject visualAdded, DependencyObject visualRemoved)
        {
            base.OnVisualChildrenChanged(visualAdded, visualRemoved);
            if (SuspendChildChangeConsum)
                return;
            //if(visualAdded is DesignerItem)
            //    (DataContext as BookPageViewModel).AddDesignerItem(visualAdded as DesignerItem);
            //if (visualRemoved is DesignerItem)
            //    (DataContext as BookPageViewModel).RemoveDesignerItem(visualRemoved as DesignerItem);
        }

        /// <MetaDataID>{ae5b8dac-906f-4e7d-a289-5c35f1db55fa}</MetaDataID>
        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);

            try
            {
                if (this.GetObjectContextConnection() != null && this.GetObjectContextConnection().Transaction != null)
                {
                    using (SystemStateTransition suppress = new SystemStateTransition(TransactionOption.Suppress))
                    {
                        using (SystemStateTransition stateTransition = new SystemStateTransition(this.GetObjectContextConnection().Transaction))
                        {
                            ReloadDesignerCanvas();
                            stateTransition.Consistent = true;
                        }
                    }
                }
                else
                    ReloadDesignerCanvas();


            }
            finally
            {
                SuspendChildChangeConsum = false;
            }

        }


        /// <MetaDataID>{98f502de-696f-4857-b847-681bb2c60c81}</MetaDataID>
        private void ReloadDesignerCanvas()
        {
            return;
            BookPageViewModel bookPageViewModel = this.GetDataContextObject<BookPageViewModel>();
            this.Children.Clear();
            SuspendChildChangeConsum = true;
            foreach (var presentationItem in bookPageViewModel.MenuPage.PresentationItems)
            {
                DesignerItem item = new DesignerItem(presentationItem.ID, presentationItem);
                item.Width = presentationItem.Width;// Double.Parse(itemXML.Element("Width").Value, CultureInfo.InvariantCulture);
                item.Height = presentationItem.Height;// Double.Parse(itemXML.Element("Height").Value, CultureInfo.InvariantCulture);

                item.IsGroup = presentationItem is MenuPresentationModel.PresentationItemsGroup;
                Canvas.SetLeft(item, presentationItem.Left);
                Canvas.SetTop(item, presentationItem.Top);
                Canvas.SetZIndex(item, bookPageViewModel.MenuPage.PresentationItems.IndexOf(presentationItem));
                if (presentationItem is MenuPresentationModel.PresentationItemsGroup && presentationItem.PageContentType == MenuPresentationModel.PageContentType.PresentationItemsGroup)
                {
                    Canvas groupCanvas = new Canvas();
                    item.Content = groupCanvas;
                }
                else
                {
                    Object content = Application.Current.Resources[presentationItem.PageContentType] as UIElement;
                    string xamlString = XamlWriter.Save(content);
                    content = XamlReader.Load(XmlReader.Create(new StringReader(xamlString))) as UIElement;
                    //Object content = XamlReader.Load(XmlReader.Create(new StringReader(itemXML.Element("Content").Value)));
                    item.Content = content;
                }
                this.Children.Add(item);
                //  SetConnectorDecoratorTemplate(item);

            }
            foreach (var groupDesignerItem in this.Children.OfType<DesignerItem>().Where(item => item.IsGroup))
            {
                foreach (var desingerItem in this.Children.OfType<DesignerItem>())
                {
                    MenuPresentationModel.PresentationItemsGroup presentationItemsGroup = groupDesignerItem.PresentationItem as MenuPresentationModel.PresentationItemsGroup;
                    if (desingerItem.PresentationItem != null && presentationItemsGroup.GroupedItems.Contains(desingerItem.PresentationItem))
                        desingerItem.ParentID = groupDesignerItem.ID;
                }

            }

        }

        #region New Command

        /// <MetaDataID>{b8cf2209-4e00-4142-a22e-18fd9a5fa379}</MetaDataID>
        private void New_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            
            this.Children.Clear();
            this.SelectionService.ClearSelection();
        }

        #endregion

        #region Open Command

        /// <MetaDataID>{75739cc2-29a5-4950-b5f7-2f7f3f834796}</MetaDataID>
        private void Open_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            XElement root = LoadSerializedDataFromFile();

            if (root == null)
                return;

            this.Children.Clear();
            this.SelectionService.ClearSelection();

            IEnumerable<XElement> itemsXML = root.Elements("DesignerItems").Elements("DesignerItem");
            foreach (XElement itemXML in itemsXML)
            {
                Guid id = new Guid(itemXML.Element("ID").Value);
                DesignerItem item = DeserializeDesignerItem(itemXML, id, 0, 0);
                this.Children.Add(item);
                SetConnectorDecoratorTemplate(item);
            }

            this.InvalidateVisual();

            IEnumerable<XElement> connectionsXML = root.Elements("Connections").Elements("Connection");
            foreach (XElement connectionXML in connectionsXML)
            {
                Guid sourceID = new Guid(connectionXML.Element("SourceID").Value);
                Guid sinkID = new Guid(connectionXML.Element("SinkID").Value);

                String sourceConnectorName = connectionXML.Element("SourceConnectorName").Value;
                String sinkConnectorName = connectionXML.Element("SinkConnectorName").Value;

                #region Connctors Code
                //Connector sourceConnector = GetConnector(sourceID, sourceConnectorName);
                //Connector sinkConnector = GetConnector(sinkID, sinkConnectorName);

                //Connection connection = new Connection(sourceConnector, sinkConnector);
                //Canvas.SetZIndex(connection, Int32.Parse(connectionXML.Element("zIndex").Value));
                //this.Children.Add(connection);
                #endregion
            }
        }

        /// <MetaDataID>{30a3a7d3-e8de-44b5-81d1-b903773280ec}</MetaDataID>
        internal void ItemSelected()
        {
            SelectedDesignerCanvas = this;
        }

        #endregion

        #region Save Command

        /// <MetaDataID>{ae643d4a-4fb7-4710-820b-cd520292d77f}</MetaDataID>
        public void Save_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            IEnumerable<DesignerItem> designerItems = this.Children.OfType<DesignerItem>();

            //IEnumerable<Connection> connections = this.Children.OfType<Connection>();

            XElement designerItemsXML = SerializeDesignerItems(designerItems);
            //XElement connectionsXML = SerializeConnections(connections);

            XElement root = new XElement("Root");
            root.Add(designerItemsXML);
            //root.Add(connectionsXML);

            SaveFile(root);
        }

        #endregion

        #region Print Command

        /// <MetaDataID>{d1ded89a-081a-4cb0-886c-fcf915cc2786}</MetaDataID>
        private void Print_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            SelectionService.ClearSelection();

            PrintDialog printDialog = new PrintDialog();

            if (true == printDialog.ShowDialog())
            {
                printDialog.PrintVisual(this, "WPF Diagram");
            }
        }

        #endregion

        #region Copy Command

        /// <MetaDataID>{a2196a1b-68d4-4e72-826c-55331523749f}</MetaDataID>
        internal void Copy_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            CopyCurrentSelection();
        }

        /// <MetaDataID>{d220e6f9-6089-4137-b090-3da2ed56f574}</MetaDataID>
        internal void Copy_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = SelectionService.CurrentSelection.Count() > 0;
        }

        #endregion

        #region Paste Command

        /// <MetaDataID>{8bc542f7-fd8d-4749-9602-ccd8d1f68e1e}</MetaDataID>
        internal void Paste_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            //XElement root = LoadSerializedDataFromClipBoard();

            //if (root == null)
            //    return;

            if (Clipboard.ContainsData(DataFormats.Xaml))
            {
                String clipboardData = Clipboard.GetData(DataFormats.Xaml) as String;

                if (String.IsNullOrEmpty(clipboardData))
                    return ;
                try
                {
                    XDocument copyDoc= XDocument.Load(new StringReader(clipboardData));
                    OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(OOAdvantech.PersistenceLayer.ObjectStorage.OpenStorage("CopyItems", copyDoc, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider"));
                    Dictionary<object, object> copiedObjects = new Dictionary<object, object>();

                    MenuPresentationModel.MenuPage menuPage = (from page in storage.GetObjectCollection<MenuPresentationModel.MenuPage>() select page).FirstOrDefault();
                    BookPageViewModel bookPage = this.GetDataContextObject<BookPageViewModel>();

                    foreach (var presentationItem in menuPage.PresentationItems)
                    {
                        MenuPresentationModel.PresentationItem copyPresentationItem = null;
                        object copiedObject = null;
                        if (!copiedObjects.TryGetValue(presentationItem, out copiedObject))
                        {
                            copyPresentationItem = presentationItem.Copy(copiedObjects);
                            OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(bookPage.MenuPage).CommitTransientObjectState(copyPresentationItem);
                        }
                        else
                            copyPresentationItem = copiedObject as MenuPresentationModel.PresentationItem;
                        bookPage.MenuPage.AddPresentationItem(copyPresentationItem);
                    }

                    ReloadDesignerCanvas();
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.StackTrace, error.Message, MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            


            //// create DesignerItems
            //Dictionary<Guid, Guid> mappingOldToNewIDs = new Dictionary<Guid, Guid>();
            //List<ISelectable> newItems = new List<ISelectable>();
            //IEnumerable<XElement> itemsXML = root.Elements("DesignerItems").Elements("DesignerItem");

            //double offsetX = Double.Parse(root.Attribute("OffsetX").Value, CultureInfo.InvariantCulture);
            //double offsetY = Double.Parse(root.Attribute("OffsetY").Value, CultureInfo.InvariantCulture);

            //foreach (XElement itemXML in itemsXML)
            //{
            //    Guid oldID = new Guid(itemXML.Element("ID").Value);
            //    Guid newID = Guid.NewGuid();
            //    mappingOldToNewIDs.Add(oldID, newID);
            //    DesignerItem item = DeserializeDesignerItem(itemXML, newID, offsetX, offsetY);
            //    this.Children.Add(item);
            //    SetConnectorDecoratorTemplate(item);
            //    newItems.Add(item);
            //}

            //// update group hierarchy
            //SelectionService.ClearSelection();
            //foreach (DesignerItem el in newItems)
            //{
            //    if (el.ParentID != Guid.Empty)
            //        el.ParentID = mappingOldToNewIDs[el.ParentID];
            //}


            //foreach (DesignerItem item in newItems)
            //{
            //    if (item.ParentID == Guid.Empty)
            //    {
            //        SelectionService.AddToSelection(item);
            //    }
            //}

            //// create Connections
            //IEnumerable<XElement> connectionsXML = root.Elements("Connections").Elements("Connection");
            //foreach (XElement connectionXML in connectionsXML)
            //{
            //    Guid oldSourceID = new Guid(connectionXML.Element("SourceID").Value);
            //    Guid oldSinkID = new Guid(connectionXML.Element("SinkID").Value);

            //    if (mappingOldToNewIDs.ContainsKey(oldSourceID) && mappingOldToNewIDs.ContainsKey(oldSinkID))
            //    {
            //        Guid newSourceID = mappingOldToNewIDs[oldSourceID];
            //        Guid newSinkID = mappingOldToNewIDs[oldSinkID];

            //        String sourceConnectorName = connectionXML.Element("SourceConnectorName").Value;
            //        String sinkConnectorName = connectionXML.Element("SinkConnectorName").Value;

            //        #region Connctors Code
            //        //Connector sourceConnector = GetConnector(newSourceID, sourceConnectorName);
            //        //Connector sinkConnector = GetConnector(newSinkID, sinkConnectorName);

            //        //Connection connection = new Connection(sourceConnector, sinkConnector);
                    
            //        //Canvas.SetZIndex(connection, Int32.Parse(connectionXML.Element("zIndex").Value));
            //        //this.Children.Add(connection);

            //        //SelectionService.AddToSelection(connection);
            //        #endregion
            //    }
            //}

            //DesignerCanvas.BringToFront.Execute(null, this);

            //// update paste offset
            //root.Attribute("OffsetX").Value = (offsetX + 10).ToString();
            //root.Attribute("OffsetY").Value = (offsetY + 10).ToString();
            //Clipboard.Clear();
            //Clipboard.SetData(DataFormats.Xaml, root);
        }

        /// <MetaDataID>{b398cd6f-83be-4818-b48d-518e586312b2}</MetaDataID>
        internal void Paste_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = Clipboard.ContainsData(DataFormats.Xaml);
        }

        #endregion

        #region Delete Command

        /// <MetaDataID>{99d133ba-9b17-4c25-af01-c984252d6d20}</MetaDataID>
        internal void Delete_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            DeleteCurrentSelection();
        }

        /// <MetaDataID>{4c6d200e-da1a-45a6-aadc-c6ee11a5e8e7}</MetaDataID>
        internal void Delete_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = this.SelectionService.CurrentSelection.Count() > 0;
        }

        #endregion

        #region Cut Command

        /// <MetaDataID>{6964d755-52dd-4948-bed7-dce924fdd84e}</MetaDataID>
        internal void Cut_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            CopyCurrentSelection();
            DeleteCurrentSelection();
        }

        /// <MetaDataID>{fa64c4be-66eb-4ab4-bcea-aba10ca11ebd}</MetaDataID>
        internal void Cut_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = this.SelectionService.CurrentSelection.Count() > 0;
        }

        #endregion

        #region Group Command

        /// <MetaDataID>{3879efb5-f22e-48d6-9161-324d9880b306}</MetaDataID>
        internal void Group_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var items = from item in this.SelectionService.CurrentSelection.OfType<DesignerItem>()
                        where item.ParentID == Guid.Empty
                        select item;

            Rect rect = GetBoundingRectangle(items);

            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
            {
                DesignerItem groupItem = new DesignerItem(new MenuPresentationModel.PresentationItemsGroup());
                groupItem.IsGroup = true;
                groupItem.Width = rect.Width;
                groupItem.Height = rect.Height;
                Canvas.SetLeft(groupItem, rect.Left);
                Canvas.SetTop(groupItem, rect.Top);
                Canvas groupCanvas = new Canvas();
                groupItem.Content = groupCanvas;
                Canvas.SetZIndex(groupItem, this.Children.Count);
                this.Children.Add(groupItem);

                foreach (DesignerItem item in items)
                {
                    item.ParentID = groupItem.ID;
                    (groupItem.PresentationItem as MenuPresentationModel.PresentationItemsGroup).AddGroupedItem(item.PresentationItem);
                }
                BookPageViewModel bookPage = this.GetDataContextObject<BookPageViewModel>();
                OOAdvantech.PersistenceLayer.ObjectStorage objectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(bookPage.MenuPage);
                groupItem.PresentationItem.PageContentType =MenuPresentationModel.PageContentType.PresentationItemsGroup;
                groupItem.UpdatePresentationItem();

                bookPage.MenuPage.AddPresentationItem(groupItem.PresentationItem);

                objectStorage.CommitTransientObjectState(groupItem.PresentationItem);

                this.SelectionService.SelectItem(groupItem);
                stateTransition.Consistent = true;
            }

            
        }

        /// <MetaDataID>{8dd3fdff-59bb-4610-98e8-15067f6b8fca}</MetaDataID>
        internal void Group_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            int count = (from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                         where item.ParentID == Guid.Empty
                         select item).Count();

            e.CanExecute = count > 1;
        }

        #endregion

        #region Ungroup Command

        /// <MetaDataID>{c7f38990-0b67-4750-b5ba-6d582e1c3dd0}</MetaDataID>
        internal void Ungroup_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var groups = (from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                          where item.IsGroup && item.ParentID == Guid.Empty
                          select item).ToArray();
            BookPageViewModel bookPage = this.GetDataContextObject<BookPageViewModel>();
            foreach (DesignerItem groupRoot in groups)
            {
                var children = from child in SelectionService.CurrentSelection.OfType<DesignerItem>()
                               where child.ParentID == groupRoot.ID
                               select child;

                foreach (DesignerItem child in children)
                    child.ParentID = Guid.Empty;

                this.SelectionService.RemoveFromSelection(groupRoot);
                this.Children.Remove(groupRoot);
                if(groupRoot.PresentationItem!=null)
                    bookPage.MenuPage.RemovePresentationItem(groupRoot.PresentationItem);
                UpdateZIndex();
            }
        }

        /// <MetaDataID>{48b2d049-6e71-417b-872d-4c0c002e4c5b}</MetaDataID>
        internal void Ungroup_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            var groupedItem = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                              where item.ParentID != Guid.Empty
                              select item;


            e.CanExecute = groupedItem.Count() > 0;
        }

        #endregion

        #region BringForward Command

        /// <MetaDataID>{ef05057b-67ea-4e01-8074-e4031a326e9b}</MetaDataID>
        internal void BringForward_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            List<UIElement> ordered = (from item in SelectionService.CurrentSelection
                                       orderby Canvas.GetZIndex(item as UIElement) descending
                                       select item as UIElement).ToList();

            int count = this.Children.Count;

            for (int i = 0; i < ordered.Count; i++)
            {
                int currentIndex = Canvas.GetZIndex(ordered[i]);
                int newIndex = Math.Min(count - 1 - i, currentIndex + 1);
                if (currentIndex != newIndex)
                {
                    Canvas.SetZIndex(ordered[i], newIndex);
                    IEnumerable<UIElement> it = this.Children.OfType<UIElement>().Where(item => Canvas.GetZIndex(item) == newIndex);

                    foreach (UIElement elm in it)
                    {
                        if (elm != ordered[i])
                        {
                            Canvas.SetZIndex(elm, currentIndex);
                            break;
                        }
                    }
                }
            }

            UpdatePresentationItemsIndex();
        }

      

        /// <MetaDataID>{92fc1b08-4363-4a5b-a2cc-9b6731906a10}</MetaDataID>
        internal void Order_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            //e.CanExecute = SelectionService.CurrentSelection.Count() > 0;
            e.CanExecute = true;
        }

        #endregion

        #region BringToFront Command

        /// <MetaDataID>{2f27d3f7-b797-4d94-a99c-3fa8a2276eed}</MetaDataID>
        internal void BringToFront_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            List<UIElement> selectionSorted = (from item in SelectionService.CurrentSelection
                                               orderby Canvas.GetZIndex(item as UIElement) ascending
                                               select item as UIElement).ToList();

            List<UIElement> childrenSorted = (from UIElement item in this.Children
                                              orderby Canvas.GetZIndex(item as UIElement) ascending
                                              select item as UIElement).ToList();

            int i = 0;
            int j = 0;
            foreach (UIElement item in childrenSorted)
            {
                if (selectionSorted.Contains(item))
                {
                    int idx = Canvas.GetZIndex(item);
                    Canvas.SetZIndex(item, childrenSorted.Count - selectionSorted.Count + j++);
                }
                else
                {
                    Canvas.SetZIndex(item, i++);
                }
            }
            UpdatePresentationItemsIndex();
        }

        #endregion

        #region SendBackward Command

        /// <MetaDataID>{757d15b6-2ca8-4e6f-9dc4-70de2c2aa8db}</MetaDataID>
        internal void SendBackward_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            List<UIElement> ordered = (from item in SelectionService.CurrentSelection
                                       orderby Canvas.GetZIndex(item as UIElement) ascending
                                       select item as UIElement).ToList();

            int count = this.Children.Count;

            for (int i = 0; i < ordered.Count; i++)
            {
                int currentIndex = Canvas.GetZIndex(ordered[i]);
                int newIndex = Math.Max(i, currentIndex - 1);
                if (currentIndex != newIndex)
                {
                    Canvas.SetZIndex(ordered[i], newIndex);
                    IEnumerable<UIElement> it = this.Children.OfType<UIElement>().Where(item => Canvas.GetZIndex(item) == newIndex);

                    foreach (UIElement elm in it)
                    {
                        if (elm != ordered[i])
                        {
                            Canvas.SetZIndex(elm, currentIndex);
                            break;
                        }
                    }
                }
            }
            UpdatePresentationItemsIndex();
        }

        #endregion

        #region SendToBack Command

        /// <MetaDataID>{ee3c3ad1-5648-4fe0-a26a-cfe96ad59878}</MetaDataID>
        internal void SendToBack_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            
            List<UIElement> selectionSorted = (from item in SelectionService.CurrentSelection
                                               orderby Canvas.GetZIndex(item as UIElement) ascending
                                               select item as UIElement).ToList();

            List<UIElement> childrenSorted = (from UIElement item in this.Children
                                              orderby Canvas.GetZIndex(item as UIElement) ascending
                                              select item as UIElement).ToList();
            int i = 0;
            int j = 0;
            foreach (UIElement item in childrenSorted)
            {
                if (selectionSorted.Contains(item))
                {
                    int idx = Canvas.GetZIndex(item);
                    Canvas.SetZIndex(item, j++);

                }
                else
                {
                    Canvas.SetZIndex(item, selectionSorted.Count + i++);
                }
            }

            UpdatePresentationItemsIndex();
        }

        #endregion

        #region AlignTop Command

        /// <MetaDataID>{fe543536-c5a1-480b-b0e8-ea6a572bf819}</MetaDataID>
        internal void AlignTop_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var selectedItems = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                                where item.ParentID == Guid.Empty
                                select item;

            if (selectedItems.Count() > 1)
            {
                double top = Canvas.GetTop(selectedItems.First());

                foreach (DesignerItem item in selectedItems)
                {
                    double delta = top - Canvas.GetTop(item);
                    foreach (DesignerItem di in SelectionService.GetGroupMembers(item))
                    {
                        Canvas.SetTop(di, Canvas.GetTop(di) + delta);
                    }
                }
            }
        }

        /// <MetaDataID>{061297fb-4637-421a-8ddc-bbf17ceb73b5}</MetaDataID>
        internal void Align_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            //var groupedItem = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
            //                  where item.ParentID == Guid.Empty
            //                  select item;


            //e.CanExecute = groupedItem.Count() > 1;
            e.CanExecute = true;
        }

        #endregion

        #region AlignVerticalCenters Command

        /// <MetaDataID>{3bc68440-fc89-4298-9b33-851566587ade}</MetaDataID>
        internal void AlignVerticalCenters_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var selectedItems = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                                where item.ParentID == Guid.Empty
                                select item;

            if (selectedItems.Count() > 1)
            {
                double bottom = Canvas.GetTop(selectedItems.First()) + selectedItems.First().Height / 2;

                foreach (DesignerItem item in selectedItems)
                {
                    double delta = bottom - (Canvas.GetTop(item) + item.Height / 2);
                    foreach (DesignerItem di in SelectionService.GetGroupMembers(item))
                    {
                        Canvas.SetTop(di, Canvas.GetTop(di) + delta);
                    }
                }
            }
        }

        #endregion

        #region AlignBottom Command

        /// <MetaDataID>{9ecb997a-a7d7-4017-bbbf-1f78b364945c}</MetaDataID>
        internal void AlignBottom_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var selectedItems = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                                where item.ParentID == Guid.Empty
                                select item;

            if (selectedItems.Count() > 1)
            {
                double bottom = Canvas.GetTop(selectedItems.First()) + selectedItems.First().Height;

                foreach (DesignerItem item in selectedItems)
                {
                    double delta = bottom - (Canvas.GetTop(item) + item.Height);
                    foreach (DesignerItem di in SelectionService.GetGroupMembers(item))
                    {
                        Canvas.SetTop(di, Canvas.GetTop(di) + delta);
                    }
                }
            }
        }

        #endregion

        #region AlignLeft Command

        /// <MetaDataID>{98c1c91b-742c-4506-8fb8-f12a55e0fa74}</MetaDataID>
        internal void AlignLeft_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var selectedItems = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                                where item.ParentID == Guid.Empty
                                select item;

            if (selectedItems.Count() > 1)
            {
                double left = Canvas.GetLeft(selectedItems.First());

                foreach (DesignerItem item in selectedItems)
                {
                    double delta = left - Canvas.GetLeft(item);
                    foreach (DesignerItem di in SelectionService.GetGroupMembers(item))
                    {
                        Canvas.SetLeft(di, Canvas.GetLeft(di) + delta);
                    }
                }
            }
        }

        #endregion

        #region AlignHorizontalCenters Command

        /// <MetaDataID>{5af93b31-3e20-401a-bd3e-958f0abf6baa}</MetaDataID>
        internal void AlignHorizontalCenters_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var selectedItems = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                                where item.ParentID == Guid.Empty
                                select item;

            if (selectedItems.Count() > 1)
            {
                double center = Canvas.GetLeft(selectedItems.First()) + selectedItems.First().Width / 2;

                foreach (DesignerItem item in selectedItems)
                {
                    double delta = center - (Canvas.GetLeft(item) + item.Width / 2);
                    foreach (DesignerItem di in SelectionService.GetGroupMembers(item))
                    {
                        Canvas.SetLeft(di, Canvas.GetLeft(di) + delta);
                    }
                }
            }
        }

        #endregion

        #region AlignRight Command

        /// <MetaDataID>{0409c219-9bed-4584-a3e7-cf5532a954ec}</MetaDataID>
        internal void AlignRight_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var selectedItems = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                                where item.ParentID == Guid.Empty
                                select item;

            if (selectedItems.Count() > 1)
            {
                double right = Canvas.GetLeft(selectedItems.First()) + selectedItems.First().Width;

                foreach (DesignerItem item in selectedItems)
                {
                    double delta = right - (Canvas.GetLeft(item) + item.Width);
                    foreach (DesignerItem di in SelectionService.GetGroupMembers(item))
                    {
                        Canvas.SetLeft(di, Canvas.GetLeft(di) + delta);
                    }
                }
            }
        }

        #endregion

        #region DistributeHorizontal Command

        /// <MetaDataID>{596ebe3d-8970-46fb-a324-01ef755a3443}</MetaDataID>
        internal void DistributeHorizontal_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var selectedItems = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                                where item.ParentID == Guid.Empty
                                let itemLeft = Canvas.GetLeft(item)
                                orderby itemLeft
                                select item;

            if (selectedItems.Count() > 1)
            {
                double left = Double.MaxValue;
                double right = Double.MinValue;
                double sumWidth = 0;
                foreach (DesignerItem item in selectedItems)
                {
                    left = Math.Min(left, Canvas.GetLeft(item));
                    right = Math.Max(right, Canvas.GetLeft(item) + item.Width);
                    sumWidth += item.Width;
                }

                double distance = Math.Max(0, (right - left - sumWidth) / (selectedItems.Count() - 1));
                double offset = Canvas.GetLeft(selectedItems.First());

                foreach (DesignerItem item in selectedItems)
                {
                    double delta = offset - Canvas.GetLeft(item);
                    foreach (DesignerItem di in SelectionService.GetGroupMembers(item))
                    {
                        Canvas.SetLeft(di, Canvas.GetLeft(di) + delta);
                    }
                    offset = offset + item.Width + distance;
                }
            }
        }

        /// <MetaDataID>{abeee83a-affd-49f2-98fc-c29bded1000e}</MetaDataID>
        internal void Distribute_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            //var groupedItem = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
            //                  where item.ParentID == Guid.Empty
            //                  select item;


            //e.CanExecute = groupedItem.Count() > 1;
            e.CanExecute = true;
        }

        #endregion

        #region ExpandLineSpace Command
        /// <MetaDataID>{84c6acb5-9e0e-45e9-9f68-29569a03415c}</MetaDataID>
        internal void ExpandLineSpace_Executed(object sender, ExecutedRoutedEventArgs e)
        {

        }
        /// <MetaDataID>{074aa654-072e-4a06-b6b9-dec02292c0d5}</MetaDataID>
        internal void ExpandLineSpace_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {

        }
        #endregion

        #region ResetLineSpace Command
        /// <MetaDataID>{3a128251-f1d3-4e95-bc6a-e152d05453fc}</MetaDataID>
        internal void ResetLineSpace_Executed(object sender, ExecutedRoutedEventArgs e)
        {

        }
        /// <MetaDataID>{6ea47558-0262-4b35-b22b-9c0db8dacdaf}</MetaDataID>
        internal void ResetLineSpace_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {

        }
        #endregion

        #region ShrinkPageFontsSizes Command
        /// <MetaDataID>{ac41f922-aca2-4e0e-8493-c1d1eb35d969}</MetaDataID>
        internal void ShrinkPageFontsSizes_Executed(object sender, ExecutedRoutedEventArgs e)
        {

        }
        /// <MetaDataID>{aabbf1ca-fb14-4662-aace-ac0e9c6a26f6}</MetaDataID>
        internal void ShrinkPageFontsSizes_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {

        }
        #endregion

        #region ExpandPageFontsSizes Command
        /// <MetaDataID>{dc741f41-ffc6-4f84-8dc2-fd2a6ee661de}</MetaDataID>
        internal void ExpandPageFontsSizes_Executed(object sender, ExecutedRoutedEventArgs e)
        {

        }
        /// <MetaDataID>{14612e11-69b8-475a-b1df-fae1c12dd036}</MetaDataID>
        internal void ExpandPageFontsSizes_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {

        }
        #endregion

        #region RestPageFontsSizes Command
        /// <MetaDataID>{50a30f89-355f-4d8d-94e9-5260e10c500e}</MetaDataID>
        internal void RestPageFontsSizes_Executed(object sender, ExecutedRoutedEventArgs e)
        {

        }
        /// <MetaDataID>{5cfb7885-230f-4697-91c4-32f83b5b05f6}</MetaDataID>
        internal void RestPageFontsSizes_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {

        }
        #endregion

        #region ShrinkLineSpace Command
        /// <MetaDataID>{c084db4d-9cf0-4b1f-bfff-416bcbf8d28b}</MetaDataID>
        internal void ShrinkLineSpace_Executed(object sender, ExecutedRoutedEventArgs e)
        {

        }
        /// <MetaDataID>{1cf6a508-1aa2-4641-a260-936da9f99890}</MetaDataID>
        internal void ShrinkLineSpace_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {

        }
        #endregion


        #region DistributeVertical Command

        /// <MetaDataID>{9df59387-2421-4c9a-929f-3a9f26333243}</MetaDataID>
        internal void DistributeVertical_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var selectedItems = from item in SelectionService.CurrentSelection.OfType<DesignerItem>()
                                where item.ParentID == Guid.Empty
                                let itemTop = Canvas.GetTop(item)
                                orderby itemTop
                                select item;

            if (selectedItems.Count() > 1)
            {
                double top = Double.MaxValue;
                double bottom = Double.MinValue;
                double sumHeight = 0;
                foreach (DesignerItem item in selectedItems)
                {
                    top = Math.Min(top, Canvas.GetTop(item));
                    bottom = Math.Max(bottom, Canvas.GetTop(item) + item.Height);
                    sumHeight += item.Height;
                }

                double distance = Math.Max(0, (bottom - top - sumHeight) / (selectedItems.Count() - 1));
                double offset = Canvas.GetTop(selectedItems.First());

                foreach (DesignerItem item in selectedItems)
                {
                    double delta = offset - Canvas.GetTop(item);
                    foreach (DesignerItem di in SelectionService.GetGroupMembers(item))
                    {
                        Canvas.SetTop(di, Canvas.GetTop(di) + delta);
                    }
                    offset = offset + item.Height + distance;
                }
            }
        }

        #endregion

        #region SelectAll Command

        /// <MetaDataID>{98fe6484-2931-4b62-ad66-b6b05571beeb}</MetaDataID>
        internal void SelectAll_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            SelectionService.SelectAll();
        }
        /// <MetaDataID>{789b7bd6-8298-492a-9971-c2fb7856afbf}</MetaDataID>
        internal void TitleHeadingFonts_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            SelectionService.TitleHeadingFonts(sender, e);
        }
        /// <MetaDataID>{dd3c9908-6899-40be-a8f4-0305f953f204}</MetaDataID>
        internal void StyleSelection_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            // SelectionService.TitleHeadingFonts(sender, e);
        }

        #endregion

        #region Helper Methods

        /// <MetaDataID>{974d29a8-90a1-4228-b125-166f6472595c}</MetaDataID>
        private XElement LoadSerializedDataFromFile()
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "Designer Files (*.xml)|*.xml|All Files (*.*)|*.*";

            if (openFile.ShowDialog() == true)
            {
                try
                {
                    return XElement.Load(openFile.FileName);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.StackTrace, e.Message, MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            return null;
        }

        /// <MetaDataID>{72e8716c-d9e7-443a-86ae-1928f038bda9}</MetaDataID>
        void SaveFile(XElement xElement)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Files (*.xml)|*.xml|All Files (*.*)|*.*";
            if (saveFile.ShowDialog() == true)
            {
                try
                {
                    xElement.Save(saveFile.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.StackTrace, ex.Message, MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        /// <MetaDataID>{f16a4872-50fb-4323-8a67-64e1033cb45b}</MetaDataID>
        private XElement LoadSerializedDataFromClipBoard()
        {
            if (Clipboard.ContainsData(DataFormats.Xaml))
            {
                String clipboardData = Clipboard.GetData(DataFormats.Xaml) as String;

                if (String.IsNullOrEmpty(clipboardData))
                    return null;
                try
                {
                    return XElement.Load(new StringReader(clipboardData));
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.StackTrace, e.Message, MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            return null;
        }

        /// <MetaDataID>{05182a56-4fa8-4d52-b8bd-82953f866990}</MetaDataID>
        private XElement SerializeDesignerItems(IEnumerable<DesignerItem> designerItems)
        {
            XElement serializedItems = new XElement("DesignerItems",
                                       from item in designerItems
                                       let contentXaml = XamlWriter.Save(((DesignerItem)item).Content)
                                       select new XElement("DesignerItem",
                                                  new XElement("Left", Canvas.GetLeft(item)),
                                                  new XElement("Top", Canvas.GetTop(item)),
                                                  new XElement("Width", item.Width),
                                                  new XElement("Height", item.Height),
                                                  new XElement("ID", item.ID),
                                                  new XElement("zIndex", Canvas.GetZIndex(item)),
                                                  new XElement("IsGroup", item.IsGroup),
                                                  new XElement("ParentID", item.ParentID),
                                                  new XElement("Content", contentXaml)
                                              )
                                   );

            return serializedItems;
        }

        //private XElement SerializeConnections(IEnumerable<Connection> connections)
        //{
        //    var serializedConnections = new XElement("Connections",
        //                   from connection in connections
        //                   select new XElement("Connection",
        //                              new XElement("SourceID", connection.Source.ParentDesignerItem.ID),
        //                              new XElement("SinkID", connection.Sink.ParentDesignerItem.ID),
        //                              new XElement("SourceConnectorName", connection.Source.Name),
        //                              new XElement("SinkConnectorName", connection.Sink.Name),
        //                              new XElement("SourceArrowSymbol", connection.SourceArrowSymbol),
        //                              new XElement("SinkArrowSymbol", connection.SinkArrowSymbol),
        //                              new XElement("zIndex", Canvas.GetZIndex(connection))
        //                             )
        //                          );

        //    return serializedConnections;
        //}

        /// <MetaDataID>{8ee736b9-1863-4a96-9c3b-98487f398918}</MetaDataID>
        private static DesignerItem DeserializeDesignerItem(XElement itemXML, Guid id, double OffsetX, double OffsetY)
        {
            DesignerItem item = new DesignerItem(id,null);
            item.Width = Double.Parse(itemXML.Element("Width").Value, CultureInfo.InvariantCulture);
            item.Height = Double.Parse(itemXML.Element("Height").Value, CultureInfo.InvariantCulture);
            item.ParentID = new Guid(itemXML.Element("ParentID").Value);
            item.IsGroup = Boolean.Parse(itemXML.Element("IsGroup").Value);
            Canvas.SetLeft(item, Double.Parse(itemXML.Element("Left").Value, CultureInfo.InvariantCulture) + OffsetX);
            Canvas.SetTop(item, Double.Parse(itemXML.Element("Top").Value, CultureInfo.InvariantCulture) + OffsetY);
            Canvas.SetZIndex(item, Int32.Parse(itemXML.Element("zIndex").Value));
            Object content = XamlReader.Load(XmlReader.Create(new StringReader(itemXML.Element("Content").Value)));
            item.Content = content;
            return item;
        }

        /// <MetaDataID>{555da4c6-d95a-49c7-bb21-112acf03dbd1}</MetaDataID>
        private void CopyCurrentSelection()
        {


           var ere=  (from designerItem in this.SelectionService.SelectedPresentationItems
             select designerItem).ToList();
            if (SelectionService.CurrentSelection.OfType<DesignerItem>().Where(designerItem=>designerItem.PresentationItem!=null).Count() > 0)
            {
                XDocument copyDoc = new XDocument();
                Dictionary<object, object> copiedObjects = new Dictionary<object, object>();
                using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
                {
                    OOAdvantech.PersistenceLayer.ObjectStorage copyObjectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.NewStorage("CopyItems", copyDoc, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider");
                    MenuPresentationModel.MenuPage pageCopyItems= new MenuPresentationModel.MenuPage();
                    copyObjectStorage.CommitTransientObjectState(pageCopyItems);
                    foreach (var presentationItem in from designerItem in SelectionService.CurrentSelection.OfType<DesignerItem>() where designerItem.PresentationItem != null select designerItem.PresentationItem)
                    {
                        MenuPresentationModel.PresentationItem copyPresentationItem = null;
                        object copiedObject = null;
                        if (!copiedObjects.TryGetValue(presentationItem, out copiedObject))
                        {
                            copyPresentationItem = presentationItem.Copy(copiedObjects);
                            copyObjectStorage.CommitTransientObjectState(copyPresentationItem);
                        }
                        else
                            copyPresentationItem = copiedObject as MenuPresentationModel.PresentationItem;
                        pageCopyItems.AddPresentationItem(copyPresentationItem);
                    }
                    stateTransition.Consistent = true;
                }

                Clipboard.Clear();
                Clipboard.SetData(DataFormats.Xaml, copyDoc.Root);

            }

            
            return;
            
            //XElement root = new XElement("Root");
            //XElement designerItemsXML = SerializeDesignerItems(selectedDesignerItems);

            //#region Connctors Code
            ////List<Connection> selectedConnections =
            ////    this.SelectionService.CurrentSelection.OfType<Connection>().ToList();

            ////foreach (Connection connection in this.Children.OfType<Connection>())
            ////{
            ////    if (!selectedConnections.Contains(connection))
            ////    {
            ////        DesignerItem sourceItem = (from item in selectedDesignerItems
            ////                                   where item.ID == connection.Source.ParentDesignerItem.ID
            ////                                   select item).FirstOrDefault();

            ////        DesignerItem sinkItem = (from item in selectedDesignerItems
            ////                                 where item.ID == connection.Sink.ParentDesignerItem.ID
            ////                                 select item).FirstOrDefault();

            ////        if (sourceItem != null &&
            ////            sinkItem != null &&
            ////            BelongToSameGroup(sourceItem, sinkItem))
            ////        {
            ////            selectedConnections.Add(connection);
            ////        }
            ////    }
            ////}


            ////XElement connectionsXML = SerializeConnections(selectedConnections);
            //#endregion


            //root.Add(designerItemsXML);
            ////root.Add(connectionsXML);

            //root.Add(new XAttribute("OffsetX", 10));
            //root.Add(new XAttribute("OffsetY", 10));

            //Clipboard.Clear();
            //Clipboard.SetData(DataFormats.Xaml, copyDoc.ro);
        }

        /// <MetaDataID>{ef3842af-04ab-477b-9753-34e8d6a27063}</MetaDataID>
        private void DeleteCurrentSelection()
        {
            #region Connctors Code
            //foreach (Connection connection in SelectionService.CurrentSelection.OfType<Connection>())
            //{
            //    this.Children.Remove(connection);
            //}
            #endregion

            BookPageViewModel bookPage = this.GetDataContextObject<BookPageViewModel>();

            foreach (DesignerItem item in SelectionService.CurrentSelection.OfType<DesignerItem>())
            {
                Control cd = item.Template.FindName("PART_ConnectorDecorator", item) as Control;

                #region Connctors Code
                //List<Connector> connectors = new List<Connector>();
                //GetConnectors(cd, connectors);

                //foreach (Connector connector in connectors)
                //{
                //    foreach (Connection con in connector.Connections)
                //    {
                //        this.Children.Remove(con);
                //    }
                //}
                #endregion

                bookPage.MenuPage.RemovePresentationItem(item.PresentationItem);
                this.Children.Remove(item);
            }

            SelectionService.ClearSelection();
            UpdateZIndex();
        }

        /// <MetaDataID>{fd409a60-9b9a-4f57-a5af-9367dfc607fc}</MetaDataID>
        private void UpdateZIndex()
        {
            List<UIElement> ordered = (from UIElement item in this.Children
                                       orderby Canvas.GetZIndex(item as UIElement)
                                       select item as UIElement).ToList();

            for (int i = 0; i < ordered.Count; i++)
            {
                Canvas.SetZIndex(ordered[i], i);
            }
        }

        /// <MetaDataID>{fffad9e5-6aaf-498f-b1ca-84efdc41df4b}</MetaDataID>
        private static Rect GetBoundingRectangle(IEnumerable<DesignerItem> items)
        {
            double x1 = Double.MaxValue;
            double y1 = Double.MaxValue;
            double x2 = Double.MinValue;
            double y2 = Double.MinValue;

            foreach (DesignerItem item in items)
            {
                x1 = Math.Min(Canvas.GetLeft(item), x1);
                y1 = Math.Min(Canvas.GetTop(item), y1);

                x2 = Math.Max(Canvas.GetLeft(item) + item.Width, x2);
                y2 = Math.Max(Canvas.GetTop(item) + item.Height, y2);
            }

            return new Rect(new Point(x1, y1), new Point(x2, y2));
        }

        //private void GetConnectors(DependencyObject parent, List<Connector> connectors)
        //{
        //    int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
        //    for (int i = 0; i < childrenCount; i++)
        //    {
        //        DependencyObject child = VisualTreeHelper.GetChild(parent, i);
        //        if (child is Connector)
        //        {
        //            connectors.Add(child as Connector);
        //        }
        //        else
        //            GetConnectors(child, connectors);
        //    }
        //}

        //private Connector GetConnector(Guid itemID, String connectorName)
        //{
        //    DesignerItem designerItem = (from item in this.Children.OfType<DesignerItem>()
        //                                 where item.ID == itemID
        //                                 select item).FirstOrDefault();

        //    Control connectorDecorator = designerItem.Template.FindName("PART_ConnectorDecorator", designerItem) as Control;
        //    connectorDecorator.ApplyTemplate();

        //    return connectorDecorator.Template.FindName(connectorName, connectorDecorator) as Connector;
        //}

        /// <MetaDataID>{05046b68-f782-4d02-8b68-9fe8e30c2c98}</MetaDataID>
        private bool BelongToSameGroup(IGroupable item1, IGroupable item2)
        {
            IGroupable root1 = SelectionService.GetGroupRoot(item1);
            IGroupable root2 = SelectionService.GetGroupRoot(item2);

            return (root1.ID == root2.ID);
        }

        #endregion
    }
}
