﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Linq;
using FlavourBusinessFacade;

namespace MenuDesigner
{
    public class RawStorageData : OOAdvantech.PersistenceLayer.IRawStorageData
    {
        string _FileName;

        public string FileName
        {
            get
            {
                return _FileName;
            }
        }
        public readonly XDocument  StorageDoc;
        private OrganizationStorageRef StorageRef;
        IUploadService UploadService;
        public RawStorageData(XDocument storageDoc,string fileName, OrganizationStorageRef storageRef,IUploadService uploadService)
        {
            StorageDoc = storageDoc;
            _FileName = fileName;
            StorageRef = storageRef;
            UploadService = uploadService;
        }

        public object RawData
        {
            get
            {
                return StorageDoc;
                
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public void SaveRawData()
        {
            if (!string.IsNullOrWhiteSpace(FileName))
            {
                StorageDoc.Root.Save(FileName);
                MemoryStream memoryStream = new MemoryStream();
                
                StorageDoc.Save(memoryStream,SaveOptions.None);
                byte[] Buffer = new byte[memoryStream.Length];
                memoryStream.Position = 0;
                //memoryStream.Read(Buffer, 0,(int) memoryStream.Length);

                var uploadSlot = UploadService.GetUploadSlotFor(StorageRef);
                FlavourBusinessToolKit.RestApiBlobFileManager.Upload(memoryStream, uploadSlot, "application/xml");
                return;
            }
            else
            {
                //SaveFileDialog saveFile = new SaveFileDialog();
                //saveFile.Filter = "Files (*.xml)|*.xml|All Files (*.*)|*.*";
                //if (saveFile.ShowDialog() == true)
                //{
                //    try
                //    {
                //        StorageDoc.Root.Save(saveFile.FileName);
                //        _FileName = saveFile.FileName;
                //    }
                //    catch (Exception ex)
                //    {
                //        MessageBox.Show(ex.StackTrace, ex.Message, MessageBoxButton.OK, MessageBoxImage.Error);
                //    }
                //}
            }

        }
    }
}
