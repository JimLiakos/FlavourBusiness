﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuDesigner
{
    /// <summary>
    /// Interaction logic for FontTestWindow.xaml
    /// </summary>
    public partial class FontTestWindow : StyleableWindow.Window
    {
        public FontTestWindow()
        {
            InitializeComponent();
            var fontFam = System.Windows.Media.Fonts.GetFontFamilies(@"C:\ProgramData\Microneme\DontWaitWater\Fonts\airbag\").ToArray();
            TextBlock.FontFamily = fontFam[0];

            TextBlock.FontSize = 70;
        }
    }
}
