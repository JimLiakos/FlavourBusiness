﻿using System.Windows.Controls;

namespace MenuDesigner.Misc
{
    /// <summary>
    /// Interaction logic for Block.xaml
    /// </summary>
    /// <MetaDataID>{e30ab841-b713-4f79-ba5c-0108f39d6e11}</MetaDataID>
    public partial class Block : UserControl
    {
        public Block()
        {
            InitializeComponent();
        }
    }
}
