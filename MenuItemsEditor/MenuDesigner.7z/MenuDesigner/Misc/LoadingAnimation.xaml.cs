﻿using System.Windows.Controls;

namespace MenuDesigner.Misc
{
    /// <summary>
    /// Interaction logic for LoadingAnimation.xaml
    /// </summary>
    /// <MetaDataID>{a3a41752-2816-45a7-bbe3-6896c87e1f3b}</MetaDataID>
    public partial class LoadingAnimation : UserControl
    {
        public LoadingAnimation()
        {
            InitializeComponent();
        }
    }
}
