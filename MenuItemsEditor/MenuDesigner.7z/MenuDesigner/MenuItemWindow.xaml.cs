﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MenuDesigner.MenuPresentetion;

namespace MenuDesigner
{
    /// <summary>
    /// Interaction logic for MenuItemWindow.xaml
    /// </summary>
    /// <MetaDataID>{f7fbace8-3395-4cd1-8db0-2098f6010ec0}</MetaDataID>
    public partial class MenuItemWindow : StyleableWindow.Window
    {

        public MenuItemWindow()
        {
            InitializeComponent();
            this.GetObjectContext().Initialize(this);
        }


    }
}
