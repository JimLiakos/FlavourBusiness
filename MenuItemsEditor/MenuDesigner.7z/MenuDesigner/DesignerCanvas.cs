﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Xml;
using MenuDesigner.ViewModel;
using MenuPresentationModel.MenuCanvas;
using OOAdvantech.Transactions;
using SharpVectors.Converters;


namespace MenuDesigner
{
    /// <MetaDataID>MenuDesigner.DesignerCanvas</MetaDataID>
    public partial class DesignerCanvas : Canvas
    {

        

        /// <MetaDataID>{2524fec9-115f-4515-a47b-bb3e905a31cc}</MetaDataID>
        private Point? rubberbandSelectionStartPoint = null;

        /// <MetaDataID>{4a2aa3e9-ac0e-432a-b66b-94ce7bb17ed1}</MetaDataID>
        private SelectionService selectionService;
        /// <MetaDataID>{48f10911-77d0-428c-a1b6-97aac5e10030}</MetaDataID>
        internal SelectionService SelectionService
        {
            get
            {
                if (selectionService == null)
                    selectionService = new SelectionService(this);

                return selectionService;
            }
        }

        /// <MetaDataID>{7cb37773-9eae-4d6d-ad90-b4c40f91e5e9}</MetaDataID>
        public DesignerCanvas()
        {

            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.New, New_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Open, Open_Executed));
            this.CommandBindings.Add(new CommandBinding(ApplicationCommands.Save, Save_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Print, Print_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Cut, Cut_Executed, Cut_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Copy, Copy_Executed, Copy_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Paste, Paste_Executed, Paste_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Delete, Delete_Executed, Delete_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.Group, Group_Executed, Group_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.Ungroup, Ungroup_Executed, Ungroup_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.BringForward, BringForward_Executed, Order_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.BringToFront, BringToFront_Executed, Order_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.SendBackward, SendBackward_Executed, Order_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.SendToBack, SendToBack_Executed, Order_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignTop, AlignTop_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignVerticalCenters, AlignVerticalCenters_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignBottom, AlignBottom_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignLeft, AlignLeft_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignHorizontalCenters, AlignHorizontalCenters_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignRight, AlignRight_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.DistributeHorizontal, DistributeHorizontal_Executed, Distribute_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.DistributeVertical, DistributeVertical_Executed, Distribute_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.SelectAll, SelectAll_Executed));

            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.TitleHeadingFonts, TitleHeadingFonts_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.StyleSelection, StyleSelection_Executed));

            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ShrinkLineSpace, ShrinkLineSpace_Executed, ShrinkLineSpace_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ExpandLineSpace, ExpandLineSpace_Executed, ExpandLineSpace_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ResetLineSpace, ResetLineSpace_Executed, ResetLineSpace_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ShrinkPageFontsSizes, ShrinkPageFontsSizes_Executed, ShrinkPageFontsSizes_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ExpandPageFontsSizes, ExpandPageFontsSizes_Executed, ExpandPageFontsSizes_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ResetPageFontsSizes, RestPageFontsSizes_Executed, RestPageFontsSizes_Enabled));

            SelectAll.InputGestures.Add(new KeyGesture(Key.A, ModifierKeys.Control));

            this.AllowDrop = true;
            Clipboard.Clear();

            Loaded += DesignerCanvas_Loaded;


            




        }
        /// <MetaDataID>{cd3ae040-3b41-4d65-a723-e3d7668350cf}</MetaDataID>
        static System.Drawing.Text.PrivateFontCollection privateFonts;
        /// <MetaDataID>{94e30237-fdd0-459a-a03a-f906b03f2488}</MetaDataID>
        static DesignerCanvas()
        {
            //privateFonts = new System.Drawing.Text.PrivateFontCollection();
            //string appFontsDataPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\Microneme\\DontWaitWater\\Fonts";
            //if (System.IO.Directory.Exists(appFontsDataPath))
            //{
            //    System.IO.DirectoryInfo directoryInfo = new System.IO.DirectoryInfo(appFontsDataPath);
            //    foreach (var fileInfo in directoryInfo.GetFiles("*.ttf"))
            //        privateFonts.AddFontFile(fileInfo.FullName);
            //    foreach (var fileInfo in directoryInfo.GetFiles("*.otf"))
            //        privateFonts.AddFontFile(fileInfo.FullName);

            //}
            //bool exist = privateFonts.Families[2].IsStyleAvailable(System.Drawing.FontStyle.Bold);
        }
        /// <MetaDataID>{b52455c7-af2e-4eaa-b390-f702b8356c40}</MetaDataID>
        private void DesignerCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            return;
            //this.GetObjectContext().ExecuteUnderContextTransaction(new Action(() =>
            //{
            //    BookPageViewModel bookPageViewModel = this.GetDataContextObject<BookPageViewModel>();
            //    bookPageViewModel.PropertyChanged += BookPageViewModel_PropertyChanged;
            //    //bookPageViewModel.MenuPage.RenderMenuCanvasItems();
            //    TextBlock text = new TextBlock();
            //    foreach (var menuCanvaItem in bookPageViewModel.ItemsToShowInCanvas)
            //    {

            //        HeadingStyleAccentViewModel headingStyleAccentViewModel = new HeadingStyleAccentViewModel(menuCanvaItem);
            //        text = new TextBlock();
            //        text.Text = menuCanvaItem.Text;
            //        text.FontFamily = menuCanvaItem.FontFamily;
            //        text.FontWeight = menuCanvaItem.FontWeight;
            //        text.FontStyle = menuCanvaItem.FontStyle;
            //        text.FontSize = menuCanvaItem.FontSize;
            //        text.Foreground = menuCanvaItem.Foreground;
            //        SetLeft(text, menuCanvaItem.Left);
            //        SetTop(text, menuCanvaItem.Top);
            //        Grid accentGrid = new Grid();
            //        //SetLeft(accentGrid, headingStyleAccentViewModel.HeadingAccentLeft);
            //        //SetTop(accentGrid, headingStyleAccentViewModel.HeadingAccentTop);
            //        //accentGrid.Width = headingStyleAccentViewModel.AccentWidth;
            //        //accentGrid.Height = headingStyleAccentViewModel.AccentHeight;

            //        //if (!string.IsNullOrWhiteSpace(headingStyleAccentViewModel.AccentUri))
            //        //{
            //        //    SvgViewbox svgViewbox = new SvgViewbox();
            //        //    svgViewbox.Source =new Uri( headingStyleAccentViewModel.AccentUri);
            //        //    svgViewbox.HorizontalAlignment = HorizontalAlignment.Stretch;
            //        //    svgViewbox.VerticalAlignment = VerticalAlignment.Stretch;
            //        //    svgViewbox.Stretch = Stretch.Fill;
            //        //    accentGrid.Children.Add(svgViewbox);
            //        //}
                 
            //        this.Children.Add(accentGrid);
            //        this.Children.Add(text);

            //    }
            //}));


            ////var fontFam = System.Windows.Media.Fonts.GetFontFamilies(@"C:\ProgramData\Microneme\DontWaitWater\Fonts\airbag\").ToArray();

            //double x = 20;
            //double y = 20;
            //string sendex = "This item uses Market for price. The price field can be any number or text, and can even be multiple prices (separate them with a semi-colon)";
            ////var size = MeasureText(sendex, text.FontFamily, text.FontStyle, text.FontWeight, text.FontStretch, text.FontSize);
            ////var matches = Regex.Matches(sendex, @"\b[\w']*\b");
            //List<string> wrappedText = new List<string>();
            //string sendecs = null;


            ////string appFontsDataPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\Microneme\\DontWaitWater\\Fonts";

            ////appFontsDataPath += "\\" + "OpenSans-CondBold.ttf";
            ////FontFamily fontFamily = fontFam[0];// new FontFamily(new Uri("C:/ProgramData/Microneme/DontWaitWater/Fonts/OpenSans-CondBold.ttf"), "Open Sans Condensed");
            //// FontFamily fontFamily = new FontFamily("Open Sans Condensed");
            //double fontSize = (double)new FontSizeConverter().ConvertFrom("19pt");
            //foreach (var word in sendex.Split(' '))
            //{

            //    var size = WpfFontStyle.MeasureText(sendecs + word + " ", text.FontFamily, FontStyles.Normal, FontWeights.Bold,FontStretches.Normal, fontSize);
            //    if (size.Width < 240)
            //        sendecs += word + " ";
            //    else
            //    {
            //        wrappedText.Add(sendecs);

            //        text = new TextBlock();
            //        //text.FontFamily = fontFamily;
            //        //text.FontWeight = FontWeights.Bold;
            //        text.FontSize = fontSize;
            //        text.Text = sendecs;
            //        //DesignerCanvas.SetLeft(text, x);
            //        //DesignerCanvas.SetTop(text, y);
            //        //this.Children.Add(text);
            //        y += size.Height + 2;


            //        sendecs = word + " ";
            //    }
            //}
            //if (sendecs.Length > 0)
            //{
            //    text = new TextBlock();
            //   // DesignerCanvas.SetLeft(text, x);
            //   // DesignerCanvas.SetTop(text, y);
            //    //this.Children.Add(text);
            //    text.Text = sendecs;
            //    //text.FontFamily = fontFamily;
            //    //text.FontWeight = FontWeights.Bold;
            //    text.FontSize = fontSize;
            //    wrappedText.Add(sendecs);
            //}

        }

 
        

        /// <MetaDataID>{e77075ab-27dd-495a-acd4-7e296f617e6f}</MetaDataID>
        private void BookPageViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            return;
            //this.GetObjectContext().ExecuteUnderContextTransaction(new Action(() =>
            //{
            //    this.Children.Clear();
            //    BookPageViewModel bookPageViewModel = this.GetDataContextObject<BookPageViewModel>();
            //    //TextBlock text = new TextBlock();
            //    //foreach (var menuCanvaItem in bookPageViewModel.ItemsToShowInCanvas)
            //    //{
            //    //    text = new TextBlock();
            //    //    text.Text = menuCanvaItem.Text;
            //    //    text.FontFamily = menuCanvaItem.FontFamily;
            //    //    text.FontWeight = menuCanvaItem.FontWeight;
            //    //    text.FontStyle = menuCanvaItem.FontStyle;
            //    //    text.FontSize = menuCanvaItem.FonSize;
            //    //    text.Foreground = menuCanvaItem.Foreground;
            //    //    DesignerCanvas.SetLeft(text, menuCanvaItem.Left);
            //    //    DesignerCanvas.SetTop(text, menuCanvaItem.Top);
            //    //    this.Children.Add(text);

            //    //}

            //    TextBlock text = new TextBlock();
            //    foreach (var menuCanvaItem in bookPageViewModel.ItemsToShowInCanvas)
            //    {

            //        HeadingStyleAccentViewModel headingStyleAccentViewModel = new HeadingStyleAccentViewModel(menuCanvaItem);
            //        headingStyleAccentViewModel.CanvasWidth = bookPageViewModel.PageWidth;
            //        headingStyleAccentViewModel.CanvasHeight = bookPageViewModel.PageHeight;


            //        text = new TextBlock();
            //        text.Text = menuCanvaItem.Text;
            //        text.FontFamily = menuCanvaItem.FontFamily;
            //        text.FontWeight = menuCanvaItem.FontWeight;
            //        text.FontStyle = menuCanvaItem.FontStyle;
            //        text.FontSize = menuCanvaItem.FontSize;
            //        text.Foreground = menuCanvaItem.Foreground;
            //        SetLeft(text, menuCanvaItem.Left);
            //        SetTop(text, menuCanvaItem.Top);
            //        Grid accentGrid = new Grid();
            //        //SetLeft(accentGrid, headingStyleAccentViewModel.HeadingAccentLeft);
            //        //SetTop(accentGrid, headingStyleAccentViewModel.HeadingAccentTop);
            //        //accentGrid.Width = headingStyleAccentViewModel.AccentWidth;
            //        //accentGrid.Height = headingStyleAccentViewModel.AccentHeight;

            //        //if (!string.IsNullOrWhiteSpace(headingStyleAccentViewModel.AccentUri))
            //        //{
            //        //    SvgViewbox svgViewbox = new SvgViewbox();
            //        //    svgViewbox.Source = new Uri(headingStyleAccentViewModel.AccentUri);
            //        //    svgViewbox.HorizontalAlignment = HorizontalAlignment.Stretch;
            //        //    svgViewbox.VerticalAlignment = VerticalAlignment.Stretch;
            //        //    svgViewbox.Stretch = Stretch.Fill;
            //        //    accentGrid.Children.Add(svgViewbox);
            //        //}
                    
            //        this.Children.Add(accentGrid);
            //        this.Children.Add(text);
            //    }
            //}));

        }





        /// <summary>
        /// Get the required height and width of the specified text. Uses Glyph's
        /// </summary>


        /// <summary>
        /// Get the required height and width of the specified text. Uses FortammedText
        /// </summary>
        /// <MetaDataID>{103361e7-2e33-48d1-a6a2-4a98a3c86621}</MetaDataID>
        public static Size MeasureTextSize(string text, FontFamily fontFamily, FontStyle fontStyle, FontWeight fontWeight, FontStretch fontStretch, double fontSize)
        {
            FormattedText ft = new FormattedText(text,
                                                 CultureInfo.CurrentCulture,
                                                 FlowDirection.LeftToRight,
                                                 new Typeface(fontFamily, fontStyle, fontWeight, fontStretch),
                                                 fontSize,
                                                 Brushes.Black);
            return new Size(ft.Width, ft.Height);
        }
        /// <MetaDataID>{439f4f43-2fa6-4ad3-bf98-36098710972b}</MetaDataID>
        static DesignerCanvas _SelectedDesignerCanvas;
        /// <MetaDataID>{ac16038c-5f4c-414d-9dbd-860b3ed6d926}</MetaDataID>
        public static DesignerCanvas SelectedDesignerCanvas
        {
            set
            {
                if (_SelectedDesignerCanvas != value)
                {
                    if (_SelectedDesignerCanvas != null)
                        _SelectedDesignerCanvas.selectionService.ClearSelection();
                    _SelectedDesignerCanvas = value;
                    if (_SelectedDesignerCanvas != null)
                        (_SelectedDesignerCanvas.DataContext as BookPageViewModel).Select();
                }
            }
            get
            {
                return _SelectedDesignerCanvas;
            }
        }

        /// <MetaDataID>{aaeb7dbf-1120-45d2-bb3a-197f478780de}</MetaDataID>
        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Source == this)
            {
                // in case that this click is the start of a 
                // drag operation we cache the start point
                this.rubberbandSelectionStartPoint = new Point?(e.GetPosition(this));

                // if you click directly on the canvas all 
                // selected items are 'de-selected'
                SelectionService.ClearSelection();
                Focus();
                SelectedDesignerCanvas = this;
                e.Handled = true;
            }
        }
        /// <MetaDataID>{268c842d-7011-46d0-8829-d73f1966b1b7}</MetaDataID>
        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            base.OnMouseUp(e);
        }

        /// <MetaDataID>{94802eed-f91a-4296-a1f4-f8b11f4f5e5c}</MetaDataID>
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            return;

            // if mouse button is not pressed we have no drag operation, ...
            if (e.LeftButton != MouseButtonState.Pressed)
                this.rubberbandSelectionStartPoint = null;

            // ... but if mouse button is pressed and start
            // point value is set we do have one
            if (this.rubberbandSelectionStartPoint.HasValue)
            {
                // create rubberband adorner
                AdornerLayer adornerLayer = AdornerLayer.GetAdornerLayer(this);
                if (adornerLayer != null)
                {
                    RubberbandAdorner adorner = new RubberbandAdorner(this, rubberbandSelectionStartPoint);
                    if (adorner != null)
                    {
                        adornerLayer.Add(adorner);
                    }
                }
            }
            e.Handled = true;
        }


        //protected override void OnDragEnter(DragEventArgs e)
        //{
        //    base.OnDragEnter(e);

        //    this.GetObjectContext().ExecuteUnderContextTransaction(new Action(() =>
        //    {
        //        this.GetDataContextObject<BookPageViewModel>().OnDragEnter(e);
        //    }));


        //}

        //protected override void OnDragLeave(DragEventArgs e)
        //{
        //    base.OnDragLeave(e);
        //    this.GetObjectContext().ExecuteUnderContextTransaction(new Action(() =>
        //    {
        //        this.GetDataContextObject<BookPageViewModel>().OnDragLeave(e);
        //    }));
        //    System.Diagnostics.Trace.WriteLine("OnDragLeave");
        //}

        /// <MetaDataID>{14a86e3d-05a1-4896-9ee9-e10d8e25dae5}</MetaDataID>
        Dictionary<FrameworkElement, bool> CanvasChilds;
        /// <MetaDataID>{7ad0fded-c0f6-4b84-abe4-50f7b79f0bf5}</MetaDataID>
        protected override void OnDragEnter(DragEventArgs e)
        {
            DragEnter(e);
            base.OnDragEnter(e);
        }

        /// <MetaDataID>{a576105d-6b00-40be-b61a-ae1a61e03b8f}</MetaDataID>
        public void DragEnter(DragEventArgs e)
        {
            CanvasChilds = WPFUIElementObjectBind.ObjectContext.FindChilds<FrameworkElement>(this).ToDictionary(x => x, x => x.IsHitTestVisible);
            foreach (var child in CanvasChilds)
                child.Key.IsHitTestVisible = false;
        }

        /// <MetaDataID>{cce46fed-49c2-42c3-b9af-e0664acee304}</MetaDataID>
        int i = 0;

        

        /// <MetaDataID>{b49e7d2b-0bb4-4539-a5f1-aa3e0bdd3552}</MetaDataID>
        protected override void OnDragLeave(DragEventArgs e)
        {
            DragLeave(e);
            base.OnDragLeave(e);
        }

        /// <MetaDataID>{3686a35d-0696-4ffc-a817-5905be6b3f0e}</MetaDataID>
        public void DragLeave(DragEventArgs e)
        {
            foreach (var child in CanvasChilds)
                child.Key.IsHitTestVisible = child.Value;


            var bookPageViewModel = this.GetDataContextObject<BookPageViewModel>();
            if (bookPageViewModel == null)
            {
                var canvasFrameViewModel = this.GetDataContextObject<CanvasFrameViewModel>();
                if (canvasFrameViewModel != null)
                    bookPageViewModel = canvasFrameViewModel.BookPageViewModel;
            }
            Point screenPoint = this.PointToScreen(e.GetPosition(this));
            bookPageViewModel.DragDropArea.Opacity = 0;
            bookPageViewModel.DragDropArea.Visibility = Visibility.Collapsed;
            i++;
        }

        /// <MetaDataID>{89badf75-9d93-4451-aac3-15237ff5fa5d}</MetaDataID>
        protected override void OnDragOver(DragEventArgs e)
        {
            base.OnDragOver(e);
            DragOver(e);
        }

        /// <MetaDataID>{58de779d-702c-422f-bbd1-e02405faa8e6}</MetaDataID>
        public void DragOver(DragEventArgs e)
        {
            ViewModel.DragCanvasItem canvasItem = e.Data.GetData(typeof(ViewModel.DragCanvasItem)) as ViewModel.DragCanvasItem;
            if (canvasItem != null)
            {
                this.GetObjectContext().RunUnderContextTransaction(new Action(() =>
                {


                    var bookPageViewModel = this.GetDataContextObject<BookPageViewModel>();

                    Point screenPoint = PointToScreen(e.GetPosition(this));


                    var canvasPoint = PointFromScreen(screenPoint);
                    var dropRectangle = bookPageViewModel.GetDropRectangle(canvasPoint);


                    bookPageViewModel.DragDropArea.Opacity = 1;
                    bookPageViewModel.DragDropArea.Visibility = Visibility.Visible;

                    if (bookPageViewModel.DragDropArea.MenuItem == null || bookPageViewModel.DragDropArea.MenuItem.MenuCanvasItem != canvasItem.MenuCanvasItem)
                        bookPageViewModel.DragDropArea.MenuItem = new MenuCanvasItemViewModel(canvasItem.MenuCanvasItem);

                    bookPageViewModel.DragDropArea.Top = canvasPoint.Y;
                    bookPageViewModel.DragDropArea.Left = dropRectangle.X;
                    bookPageViewModel.DragDropArea.Width = dropRectangle.Width;

                }));
            }
        }




        /// <MetaDataID>{42d4d8d5-c130-4b71-a54e-b16bbe6c397c}</MetaDataID>
        protected override void OnDrop(DragEventArgs e)
        {
            Drop(e);
            base.OnDrop(e);

        }

        /// <MetaDataID>{0ef1d36e-f15a-430a-ad46-66c77c95599b}</MetaDataID>
        public void Drop(DragEventArgs e)
        {
            foreach (var child in CanvasChilds)
                child.Key.IsHitTestVisible = child.Value;


            this.GetObjectContext().RunUnderContextTransaction(new Action(() =>
            {
                Point point = e.GetPosition(this);
                DragCanvasItem dragCanvasItem = e.Data.GetData(typeof(DragCanvasItem)) as DragCanvasItem;

                if (dragCanvasItem.MenuCanvasItem.Page != null)
                    this.GetDataContextObject<BookPageViewModel>().BookViewModel.ShowPopUpMessage = true;
                else
                {
                    this.GetDataContextObject<BookPageViewModel>().BookViewModel.RestaurantMenu.AddMenuItem(dragCanvasItem.MenuCanvasItem);
                    this.GetDataContextObject<BookPageViewModel>().MenuPage.InsertCanvasItemTo(dragCanvasItem.MenuCanvasItem, point);
                    this.GetDataContextObject<BookPageViewModel>().BookViewModel.MenuItemDropOnPage(this.GetDataContextObject<BookPageViewModel>());

                    // this.GetDataContextObject<BookPageViewModel>().Refresh();
                }
                this.GetDataContextObject<BookPageViewModel>().DragDropArea.Opacity = 0;
                this.GetDataContextObject<BookPageViewModel>().DragDropArea.Visibility = Visibility.Collapsed;





                DragObject dragObject = e.Data.GetData(typeof(DragObject)) as DragObject;
                Point position = e.GetPosition(this);

                var objectContextConnection = this.GetObjectContextConnection();
                if (objectContextConnection.Transaction != null)
                {
                    using (SystemStateTransition stateTransition = new SystemStateTransition(objectContextConnection.Transaction))
                    {
                        DrobDraggedObject(position, dragObject);
                        e.Handled = true;
                        stateTransition.Consistent = true;
                    }
                }
                else
                {
                    DrobDraggedObject(position, dragObject);
                    e.Handled = true;
                }
            }));
        }




        /// <MetaDataID>{a592cbc3-2f0f-42b7-8dc9-8223cad100eb}</MetaDataID>
        private void UpdatePresentationItemsIndex()
        {

            List<DesignerItem> childrenSorted = (from item in this.Children.OfType<DesignerItem>()
                                                 where item.PresentationItem != null
                                                 orderby Canvas.GetZIndex(item) ascending
                                                 select item).ToList();
            BookPageViewModel bookPage = this.GetDataContextObject<BookPageViewModel>();
            for (int i = 0; i < childrenSorted.Count; i++)
            {
                if (childrenSorted[i].PresentationItem != null)
                    bookPage.MenuPage.MovePresentationItem(i, childrenSorted[i].PresentationItem);
            }
        }

        /// <MetaDataID>{037cc79f-5978-46e2-bf5b-6cf258c7c907}</MetaDataID>
        private void DrobDraggedObject(Point position, DragObject dragObject)
        {
            if (dragObject != null && !String.IsNullOrEmpty(dragObject.Xaml))
            {
                DesignerItem newItem = null;
                UIElement dropItem = XamlReader.Load(XmlReader.Create(new StringReader(dragObject.Xaml))) as UIElement;

                UIElement content = null;
                MenuPresentationModel.MenuItemsPresentation menuItemsPresentation = null;
                if (dragObject.ToolboxItem != null && dragObject.ToolboxItem.GetDataContextObject() is MenuModel.MenuItem)
                {
                    content = new FoodItemsGroupView();
                    //Application.Current.Resources[MenuPresentationModel.PageContentType.FoodItemsGroup] as UIElement;
                    //string xamlString = XamlWriter.Save(content);
                    //content = XamlReader.Load(XmlReader.Create(new StringReader(xamlString))) as UIElement;

                    MenuModel.MenuItem menuItem = dragObject.ToolboxItem.GetDataContextObject<MenuModel.MenuItem>();
                    menuItemsPresentation = new MenuPresentationModel.MenuItemsPresentation();
                    MenuDesigner.MenuPresentetion.MenuItemsPresentationViewModel menuItemsPresentationViewModel = new MenuPresentetion.MenuItemsPresentationViewModel(menuItemsPresentation);
                    menuItemsPresentationViewModel.AddMenuItem(new MenuPresentetion.MenuItemPresentationViewModel(menuItemsPresentationViewModel, menuItem));

                    (content as FrameworkElement).DataContext = dragObject.ToolboxItem.GetObjectContext().Control(menuItemsPresentationViewModel);
                }
                else
                {
                    switch (dropItem.Uid)
                    {
                        case MenuPresentationModel.PageContentType.MenuHeading:
                            {
                                break;
                            }
                        case MenuPresentationModel.PageContentType.FoodItem:
                            {
                                content = Application.Current.Resources[MenuPresentationModel.PageContentType.FoodItem] as UIElement;
                                string xamlString = XamlWriter.Save(content);
                                content = XamlReader.Load(XmlReader.Create(new StringReader(xamlString))) as UIElement;

                                break;
                            }
                        case MenuPresentationModel.PageContentType.FoodItemsGroup:
                            {
                                break;
                            }
                    }
                }

                if (content != null)
                {

                    if (menuItemsPresentation == null)
                        newItem = new DesignerItem(new MenuPresentationModel.PresentationItem());
                    else
                        newItem = new DesignerItem(menuItemsPresentation);
                    newItem.Content = content;



                    if (dragObject.DesiredSize.HasValue)
                    {
                        Size desiredSize = dragObject.DesiredSize.Value;
                        newItem.Width = desiredSize.Width;
                        newItem.Height = desiredSize.Height;

                        DesignerCanvas.SetLeft(newItem, Math.Max(0, position.X - newItem.Width / 2));
                        DesignerCanvas.SetTop(newItem, Math.Max(0, position.Y - newItem.Height / 2));
                    }
                    else
                    {
                        DesignerCanvas.SetLeft(newItem, Math.Max(0, position.X));
                        DesignerCanvas.SetTop(newItem, Math.Max(0, position.Y));
                    }

                    Canvas.SetZIndex(newItem, this.Children.Count);
                    this.Children.Add(newItem);
                    SetConnectorDecoratorTemplate(newItem);

                    //update selection
                    this.SelectionService.SelectItem(newItem);
                    newItem.Focus();

                    BookPageViewModel bookPage = this.GetDataContextObject<BookPageViewModel>();
                    OOAdvantech.PersistenceLayer.ObjectStorage objectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(bookPage.MenuPage);
                    newItem.PresentationItem.PageContentType = dropItem.Uid;
                    newItem.UpdatePresentationItem();
                    objectStorage.CommitTransientObjectState(newItem.PresentationItem);
                    bookPage.MenuPage.AddPresentationItem(newItem.PresentationItem);
                    SelectedDesignerCanvas = this;
                }


            }
        }

        /// <MetaDataID>{2361f6b3-ae01-47ff-abba-28db150fe276}</MetaDataID>
        internal DesignerItem GetDesignerItem(Guid id)
        {
            return (from designerItem in Children.Cast<UIElement>().OfType<DesignerItem>()
                    where designerItem.ID == id
                    select designerItem).FirstOrDefault();

        }

        /// <MetaDataID>{f0a11605-d612-4b80-b085-bff0134698f0}</MetaDataID>
        protected override Size MeasureOverride(Size constraint)
        {
            Size size = new Size();

            foreach (UIElement element in this.InternalChildren)
            {
                double left = Canvas.GetLeft(element);
                double top = Canvas.GetTop(element);
                left = double.IsNaN(left) ? 0 : left;
                top = double.IsNaN(top) ? 0 : top;

                //measure desired size for each child
                element.Measure(constraint);

                Size desiredSize = element.DesiredSize;
                if (!double.IsNaN(desiredSize.Width) && !double.IsNaN(desiredSize.Height))
                {
                    size.Width = Math.Max(size.Width, left + desiredSize.Width);
                    size.Height = Math.Max(size.Height, top + desiredSize.Height);
                }
            }
            // add margin 
            size.Width += 10;
            size.Height += 10;
            return size;
        }

        /// <MetaDataID>{fdca11a8-9a4f-42ac-8d47-e13b069f3041}</MetaDataID>
        private void SetConnectorDecoratorTemplate(DesignerItem item)
        {
            if (item.ApplyTemplate() && item.Content is UIElement)
            {
                //ControlTemplate template = DesignerItem.GetConnectorDecoratorTemplate(item.Content as UIElement);
                Control decorator = item.Template.FindName("PART_ConnectorDecorator", item) as Control;
                //if (decorator != null && template != null)
                //    decorator.Template = template;
            }
        }
    }
}

//.page-margins{margins:.58,1,.96,1}.style{type:next;line-spacing:1;name-indent:.14;desc-left-indent:.14;extras-left-indent:.24;desc-right-indent:.3;desc-separator:none;extras-separator:&#43;photo-height:1;width-balance:100;space-between-columns:.37;line-between-columns:no;line-type:single;stroke-width:2px;shorter-line:no;fill:#636363;stroke-opacity:1}.price-options{layout:normal;currency:&#36;price-leader:&#46;dot-space-price:1;dot-space-item:1;dot-space-between:1;dots-match-name-color:no;space-between-prices:.8}.symbol{fill-1:#6ba069;fill-2:#6ba069;fill-opacity1:1;fill-opacity2:1;large:no;keep-inline:yes}.background{image:none;background-margin:0;opacity:1;paper-color:#e8e8e8;mirror:no;flip:no;preserveAspectRatio:no}.border{image:Black_Tie_10.svg;border-margin:.3;color:none;fill-opacity:1;stroke-opacity:1;mirror:no;flip:no}.title-heading{font-family:"Tangerine",sans-serif;font-size:50pt;font-weight:400;font-style:normal;icaps:no;text-decoration:none;itext-shadow:none;fill:#4d4d4d;fill-opacity:1;stroke-opacity:1;letter-spacing:1px;stroke:none;stroke-width:0;space-before:.1;space-after:0;indent:0;justification:left;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}.title-heading-accent{name:none;color:#d2b48a;fill-opacity:1;stroke-opacity:1}.heading{font-family:"Cardo",serif;font-size:27pt;font-weight:400;font-style:italic;icaps:no;text-decoration:none;itext-shadow:none;fill:#a67c52;fill-opacity:1;stroke-opacity:1;letter-spacing:0;stroke:none;stroke-width:0;space-before:.26;space-after:0;indent:0;justification:left;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}.heading-accent{name:none;color:#d2b48a;fill-opacity:1;stroke-opacity:1}.alt-font-heading{font-family:"Quattrocento Sans",sans-serif;font-size:20pt;font-weight:700;font-style:italic;icaps:no;text-decoration:none;itext-shadow:none;fill:#de1d3c;fill-opacity:1;stroke-opacity:1;letter-spacing:0;stroke:none;stroke-width:0;space-before:.28;space-after:0;indent:0;justification:left;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}.alt-font-heading-accent{name:none;color:#d2b48a;fill-opacity:1;stroke-opacity:1}.small-heading{font-family:"Open Sans",sans-serif;font-size:10pt;font-weight:400;font-style:normal;icaps:yes;text-decoration:none;itext-shadow:none;fill:#4d4d4d;fill-opacity:1;stroke-opacity:1;letter-spacing:0;stroke:none;stroke-width:0;space-before:.065;space-after:0;indent:.14;justification:left;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}.small-heading-accent{name:none;color:#d2b48a;fill-opacity:1;stroke-opacity:1}.floating-text{font-family:"Kaushan Script",sans-serif;font-size:30pt;font-weight:400;font-style:normal;icaps:no;text-decoration:none;itext-shadow:none;fill:#de1d3c;fill-opacity:1;stroke-opacity:1;letter-spacing:0;stroke:none;stroke-width:0;space-before:0;space-after:0;indent:0;justification:left;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}.alt-float{font-family:"Yesteryear",sans-serif;font-size:26pt;font-weight:400;font-style:normal;icaps:no;text-decoration:none;itext-shadow:none;fill:#4d4d4f;fill-opacity:1;stroke-opacity:1;letter-spacing:0;stroke:none;stroke-width:0;space-before:0;space-after:0;indent:0;justification:left;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}.name{font-family:"Open Sans",sans-serif;font-size:13pt;font-weight:600;font-style:normal;icaps:no;text-decoration:none;itext-shadow:none;fill:#4d4d4d;fill-opacity:1;stroke-opacity:1;letter-spacing:0;stroke:none;stroke-width:0;space-before:.115;space-after:0;indent:.14;justification:left;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}.description{font-family:"Open Sans",sans-serif;font-size:11pt;font-weight:400;font-style:normal;icaps:no;text-decoration:none;itext-shadow:none;fill:#4d4d4d;fill-opacity:1;stroke-opacity:1;letter-spacing:0;stroke:none;stroke-width:0;space-before:0;space-after:0;indent:.14;justification:left;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}.extras{font-family:"Open Sans",sans-serif;font-size:10pt;font-weight:400;font-style:italic;icaps:no;text-decoration:none;itext-shadow:none;fill:#4d4d4d;fill-opacity:1;stroke-opacity:1;letter-spacing:0;stroke:none;stroke-width:0;space-before:0;space-after:0;indent:.24;justification:left;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}.price{font-family:"Open Sans",sans-serif;font-size:13pt;font-weight:400;font-style:normal;icaps:no;text-decoration:none;itext-shadow:none;fill:#4d4d4d;fill-opacity:1;stroke-opacity:1;letter-spacing:0;stroke:none;stroke-width:0;space-before:0;space-after:0;indent:0;justification:right;white-space:pre;text-rendering:geometricPrecision;-moz-font-feature-settings:"kern" 1;-ms-font-feature-settings:"kern" 1;font-feature-settings:"kern" 1}