﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for GraphicMenusListView.xaml
    /// </summary>
    /// <MetaDataID>{a99abf7c-8578-4d56-8b90-8874d25539dc}</MetaDataID>
    public partial class GraphicMenusListView : UserControl
    {
        public GraphicMenusListView()
        {
            InitializeComponent();
        }
    }
}
