﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for HeadingAccentForm.xaml
    /// </summary>
    /// <MetaDataID>{f28441e1-cffb-4396-9ef7-99330dc96efd}</MetaDataID>
    public partial class HeadingAccentForm : StyleableWindow.Window
    {
        /// <MetaDataID>{d58a48dc-aee7-4667-a356-857cf95e2bd0}</MetaDataID>
        public HeadingAccentForm()
        {
            InitializeComponent();
        }

        private void Grid_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            //svg.Source
            this.GetObjectContext().RunUnderContextTransaction(new Action(() =>
            {
                this.GetDataContextObject<ViewModel.HeadingStyleAccentViewModel>().CanvasHeight = canvas.ActualHeight;
                this.GetDataContextObject<ViewModel.HeadingStyleAccentViewModel>().CanvasWidth = canvas.ActualWidth;
                //this.GetDataContextObject<ViewModel.HeadingStyleAccentViewModel>().Refresh();

            }));
        }
    }
}
