﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for CompanySettingsWindow.xaml
    /// </summary>
    /// <MetaDataID>{1aadc077-8ad2-48ad-a629-324e5a7408c4}</MetaDataID>
    public partial class CompanySettingsWindow : StyleableWindow.Window
    {
        public CompanySettingsWindow()
        {
            InitializeComponent();
        }
    }
}
