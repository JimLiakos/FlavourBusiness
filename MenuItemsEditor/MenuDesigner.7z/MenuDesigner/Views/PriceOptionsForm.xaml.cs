﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for PriceOptionsForm.xaml
    /// </summary>
    /// <MetaDataID>{1eedc2d3-8d4c-4e18-ad4e-0c8ca10bf3e1}</MetaDataID>
    public partial class PriceOptionsForm : StyleableWindow.Window
    {
        public PriceOptionsForm()
        {
            InitializeComponent();
        }
    }
}
