﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for LayoutOptionsForm.xaml
    /// </summary>
    /// <MetaDataID>{1ff874b2-bed9-4d4d-a303-4674320865c2}</MetaDataID>
    public partial class LayoutOptionsForm : StyleableWindow.Window
    {
        public LayoutOptionsForm()
        {
            InitializeComponent();
        }

       
    }
}
