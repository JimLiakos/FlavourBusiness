﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for SelectPreparationStationItemsWindow.xaml
    /// </summary>
    /// <MetaDataID>{6c59b84d-c64c-47a4-b74e-8e9f89f5d2ca}</MetaDataID>
    public partial class SelectPreparationStationItemsWindow : StyleableWindow.Window
    {
        public SelectPreparationStationItemsWindow()
        {
            InitializeComponent();
        }
    }
}
