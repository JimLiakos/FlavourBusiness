﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using GenWebBrowser;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for WebTestWindow.xaml
    /// </summary>
    public partial class WebTestWindow : Window
    {

        string url = "http://localhost:4300/";
     
        public WebBrowserOverlay Browser;
        public WebTestWindow()
        {
            InitializeComponent();
           // url = "http://localhost:4300/#/signintoolbar";
        }


     

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (!DesignerProperties.GetIsInDesignMode(this/*this user control*/))
            {
                Browser = new WebBrowserOverlay(WebBrowserHost, BrowserType.IE, true);
                Browser.SuppressScriptErrors = true;

                Browser.Navigate(new Uri(url));
            }
        }
    }
}
