﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for SelectHeadingsAccents.xaml
    /// </summary>
    /// <MetaDataID>{3db4cc6c-cf00-4e85-9e73-dbd3173926f0}</MetaDataID>
    public partial class SelectHeadingTypesAccents : StyleableWindow.Window
    {
        public SelectHeadingTypesAccents()
        {
            InitializeComponent();
        }
    }
}
