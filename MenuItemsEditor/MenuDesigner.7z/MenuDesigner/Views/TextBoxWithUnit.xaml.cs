﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for TextBoxWithUnit.xaml
    /// </summary>
    public partial class TextBoxNumberWithUnit : UserControl, INotifyPropertyChanged
    {
        public TextBoxNumberWithUnit()
        {
            InitializeComponent();
            UnitTextBox.DataContext = this;
        }

        public decimal Number
        {
            get
            {
                object value = GetValue(NumberProperty);
                if (value is decimal)
                    return (decimal)value;
                else
                    return default(decimal);
            }
            set
            {
                SetValue(NumberProperty, value);
            }
        }
        
        public static readonly DependencyProperty NumberProperty =
                    DependencyProperty.Register(
                    "Number",
                    typeof(decimal),
                    typeof(TextBoxNumberWithUnit),
                    new PropertyMetadata(default(decimal), new PropertyChangedCallback(NumberPropertyChangedCallback)));

        public event PropertyChangedEventHandler PropertyChanged;

        public static void NumberPropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

            if (d is TextBoxNumberWithUnit)
                (d as TextBoxNumberWithUnit).NumberPropertyChanged();
        }

        private void NumberPropertyChanged()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DisplayedValue)));
        }


        public string Unit
        {
            get
            {
                object value = GetValue(UnitProperty);
                return value as string;
            }
            set
            {
                SetValue(UnitProperty, value);
            }
        }
        /// <MetaDataID>{547e83a9-7d89-4737-8cb1-f343771e7a7c}</MetaDataID>
        public static readonly DependencyProperty UnitProperty =
                    DependencyProperty.Register(
                    "Unit",
                    typeof(string),
                    typeof(TextBoxNumberWithUnit),
                    new PropertyMetadata("", new PropertyChangedCallback(UnitPropertyChangedCallback)));


        public static void UnitPropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

            if (d is TextBoxNumberWithUnit)
                (d as TextBoxNumberWithUnit).UnitPropertyChanged();
        }

        private void UnitPropertyChanged()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DisplayedValue)));
        }

        public string DisplayeUnit
        {
            get
            {
                return Unit;
            }
            set
            {
                
            }
        }

        public decimal DisplayedValue
        {
            get
            {
                return Number;
            }
            set
            {
                Number = value;
            }
        }
    }
}
