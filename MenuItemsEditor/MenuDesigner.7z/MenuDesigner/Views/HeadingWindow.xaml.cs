﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MenuDesigner.Views
{
    /// <summary>
    /// Interaction logic for HeadingWindow.xaml
    /// </summary>
    /// <MetaDataID>{33df9669-07f2-4626-bd29-d24266fa7747}</MetaDataID>
    public partial class HeadingWindow : StyleableWindow.Window
    {
        public HeadingWindow()
        {
            InitializeComponent();
        }
    }
}
