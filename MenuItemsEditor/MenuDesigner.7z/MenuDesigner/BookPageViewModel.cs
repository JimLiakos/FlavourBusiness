﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Xml.Linq;
using System.Windows.Markup;
using System.Windows.Controls;
using System.Xml;
using System.Globalization;
using System.IO;
using MenuPresentationModel;

namespace MenuDesigner
{
    /// <MetaDataID>{f40bad5d-afee-408c-b2f8-e9e0c1ee271d}</MetaDataID>
    public class BookPageViewModel :MarshalByRefObject, INotifyPropertyChanged
    {
        /// <MetaDataID>{20619cc0-37c9-4fce-a235-8db0023ba6ed}</MetaDataID>
        internal XElement SerializeDesignerItems(IEnumerable<DesignerItem> designerItems)
        {
            XElement serializedItems = new XElement("DesignerItems",
                                       from item in designerItems
                                       let contentXaml = XamlWriter.Save(((DesignerItem)item).Content)
                                       select new XElement("DesignerItem",
                                                  new XElement("Left", Canvas.GetLeft(item)),
                                                  new XElement("Top", Canvas.GetTop(item)),
                                                  new XElement("Width", item.Width),
                                                  new XElement("Height", item.Height),
                                                  new XElement("ID", item.ID),
                                                  new XElement("zIndex", Canvas.GetZIndex(item)),
                                                  new XElement("IsGroup", item.IsGroup),
                                                  new XElement("ParentID", item.ParentID),
                                                  new XElement("Content", contentXaml)
                                              )
                                   );

            return serializedItems;
        }

        /// <MetaDataID>{515bce28-4163-4db0-bc43-5710ba2abaa5}</MetaDataID>
        public double PageWidth
        {
            get
            {
                if (BookViewModel != null && BookViewModel.SelectedMenuStyle != null)
                    return (BookViewModel.SelectedMenuStyle.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle).PageWidth;
                return 600;
            }
        }
        /// <MetaDataID>{ab5c103b-03bf-4f01-893c-c5f259fcc6a0}</MetaDataID>
        public double PageHeight
        {
            get
            {
                if (BookViewModel != null && BookViewModel.SelectedMenuStyle != null)
                    return (BookViewModel.SelectedMenuStyle.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle).PageHeigth;

                return 800;
            }
        }
        /// <exclude>Excluded</exclude>
        double _Border = 0;
        /// <MetaDataID>{42d63f98-8f66-4302-b70d-a3ece90f84a6}</MetaDataID>
        public double Border
        {
            get
            {
                return _Border;
            }
            set
            {
                _Border = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Border"));

            }
        }
        /// <exclude>Excluded</exclude>
        static BookPageViewModel _SelectedBookPage;
        /// <MetaDataID>{57fb1cca-1151-433c-9a8b-4a8258b550bb}</MetaDataID>
        public static BookPageViewModel SelectedBookPage
        {
            set
            {
                if (_SelectedBookPage != value)
                {
                    if (_SelectedBookPage != null)
                        _SelectedBookPage.Border = 0;
                    _SelectedBookPage = value;
                    if (_SelectedBookPage != null)
                        _SelectedBookPage.Border = 1;
                }

            }
        }

        /// <MetaDataID>{da3fbc6d-d330-499b-9e70-827201635877}</MetaDataID>
        internal void Select()
        {
            SelectedBookPage = this;

        }
        MenuPresentationModel.MenuPage _MenuPage;
        private BookViewModel BookViewModel;

        public MenuPresentationModel.MenuPage MenuPage
        {
            get
            {
                return _MenuPage;
            }
        }

        public String BorderUri
        {
            get
            {
                if(BookViewModel!=null&&BookViewModel.SelectedMenuStyle!=null)
                    return (BookViewModel.SelectedMenuStyle.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle).Border.Uri;
                return null;
            }
        }
        public String BackgroundUri
        {
            get
            {
                if (BookViewModel != null && BookViewModel.SelectedMenuStyle != null)
                    return (BookViewModel.SelectedMenuStyle.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle).Background.Uri;
                return null;
            }
        }

        public BookPageViewModel(MenuPresentationModel.MenuPage menuPage)
        {
            _MenuPage = menuPage;
        }
        /// <MetaDataID>{91c8ec2a-3fda-4180-a7d8-b34e4bcd5056}</MetaDataID>
        //public BookPageViewModel(XElement pageXML)
        //{

        //    IEnumerable<XElement> itemsXML = pageXML.Elements("DesignerItems").Elements("DesignerItem");
        //    foreach (XElement itemXML in itemsXML)
        //    {
        //        Guid id = new Guid(itemXML.Element("ID").Value);
        //        DesignerItem item = DeserializeDesignerItem(itemXML, id, 0, 0);
        //        DesignerItems.Add(item);
        //    }
        //}


        /// <MetaDataID>{2a5253bb-3fa4-41bb-8783-209b1f3386be}</MetaDataID>
        public BookPageViewModel()
        {

        }

        public BookPageViewModel(MenuPage menuPage, BookViewModel bookViewModel) : this(menuPage)
        {
            this.BookViewModel = bookViewModel;
            this.BookViewModel.PropertyChanged += BookViewModel_PropertyChanged;
        }

        private void BookViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if(e.PropertyName==nameof(BookViewModel.SelectedMenuStyle))
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(BorderUri)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(BackgroundUri)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PageWidth)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PageHeight)));

            }
        }


        /// <MetaDataID>{8c143893-ca7f-4732-bbd6-b6c496a4cee1}</MetaDataID>
        private static DesignerItem DeserializeDesignerItem(XElement itemXML, Guid id, double OffsetX, double OffsetY)
        {
            DesignerItem item = new DesignerItem(id,null);
            item.Width = Double.Parse(itemXML.Element("Width").Value, CultureInfo.InvariantCulture);
            item.Height = Double.Parse(itemXML.Element("Height").Value, CultureInfo.InvariantCulture);
            item.ParentID = new Guid(itemXML.Element("ParentID").Value);
            item.IsGroup = Boolean.Parse(itemXML.Element("IsGroup").Value);
            Canvas.SetLeft(item, Double.Parse(itemXML.Element("Left").Value, CultureInfo.InvariantCulture) + OffsetX);
            Canvas.SetTop(item, Double.Parse(itemXML.Element("Top").Value, CultureInfo.InvariantCulture) + OffsetY);
            Canvas.SetZIndex(item, Int32.Parse(itemXML.Element("zIndex").Value));
            Object content = XamlReader.Load(XmlReader.Create(new StringReader(itemXML.Element("Content").Value)));
            item.Content = content;
            return item;
        }
        public event PropertyChangedEventHandler PropertyChanged;

        ///// <MetaDataID>{1d279f8c-63c5-41a3-a22c-d6577aea723b}</MetaDataID>
        //internal List<DesignerItem> DesignerItems = new List<DesignerItem>();
        ///// <MetaDataID>{f117ce2f-5ff8-40e8-8fd6-8c31dd1bdac5}</MetaDataID>
        //internal void AddDesignerItem(DesignerItem designerItem)
        //{
        //    if (designerItem != null && !DesignerItems.Contains(designerItem))
        //        DesignerItems.Add(designerItem);
        //}
        ///// <MetaDataID>{cfffe366-2f41-4b62-b7b0-97ad3f2d0466}</MetaDataID>
        //internal void RemoveDesignerItem(DesignerItem designerItem)
        //{
        //    if (designerItem != null && DesignerItems.Contains(designerItem))
        //        DesignerItems.Add(designerItem);
        //}
    }
}
