using System;
using OOAdvantech;
using OOAdvantech.MetaDataRepository;
using OOAdvantech.PersistenceLayer;
using OOAdvantech.Transactions;
using System.Linq;
namespace MenuDesigner
{
    /// <MetaDataID>{d2560ed7-6c28-4e1d-8f49-98a4ef93784a}</MetaDataID>
    [BackwardCompatibilityID("{d2560ed7-6c28-4e1d-8f49-98a4ef93784a}")]
    [Persistent()]
    public class ApplicationSettings
    {
        /// <exclude>Excluded</exclude>
        ObjectStateManagerLink StateManagerLink;


     

        /// <exclude>Excluded</exclude>
        static ObjectStorage _AppSettingsStorage;
        /// <MetaDataID>{da878c84-7957-48fd-a7ac-fef703351615}</MetaDataID>
        public static ObjectStorage AppSettingsStorage
        {
            get
            {
                if (_AppSettingsStorage == null)
                {
                    string appDataPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\Microneme";
                    if (!System.IO.Directory.Exists(appDataPath))
                        System.IO.Directory.CreateDirectory(appDataPath);
                    appDataPath += "\\DontWaitWater";
                    if (!System.IO.Directory.Exists(appDataPath))
                        System.IO.Directory.CreateDirectory(appDataPath);
                    string storageLocation = appDataPath + "\\MenuDesignAppSettings.xml";

                    try
                    {
                        _AppSettingsStorage = OOAdvantech.PersistenceLayer.ObjectStorage.OpenStorage("MenuDesignAppSettings", storageLocation, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider");
                    }
                    catch (StorageException error)
                    {

                        if (error.Reason == StorageException.ExceptionReason.StorageDoesnotExist)
                        {
                            _AppSettingsStorage = OOAdvantech.PersistenceLayer.ObjectStorage.NewStorage("MenuDesignAppSettings",
                                                                    storageLocation,
                                                                    "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider");
                        }
                        else
                            throw error;
                    }
                    catch (Exception error)
                    {
                    }
                }
                return _AppSettingsStorage;
            }
        }



        /// <exclude>Excluded</exclude>
        static ApplicationSettings _Current;
        /// <MetaDataID>{82643791-08c8-4d09-a3db-c5e8de5e5061}</MetaDataID>
        public static ApplicationSettings Current
        {
            get
            {
                if (_Current == null)
                {

                    using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Suppress))
                    {
                        OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(AppSettingsStorage);
                        _Current = (from appSetting in storage.GetObjectCollection<ApplicationSettings>() select appSetting).FirstOrDefault();
                        if (_Current == null)
                        {
                            _Current = new ApplicationSettings();
                            AppSettingsStorage.CommitTransientObjectState(_Current);
                        }
                        stateTransition.Consistent = true;
                    }

                }
                return _Current;
            }
        }


        /// <exclude>Excluded</exclude>
        string _SignInUserName;
        /// <MetaDataID>{1aa6eeca-93e3-44f9-9f42-de763b037039}</MetaDataID>
        [PersistentMember("_SignInUserName"), BackwardCompatibilityID("+1")]
        public string SignInUserName
        {
            get
            {
                return _SignInUserName;
            }
            set
            {
                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _SignInUserName = value;
                    stateTransition.Consistent = true;
                }
            }
        }
        /// <exclude>Excluded</exclude>
        string _SignInUserIdentity;
        /// <MetaDataID>{4a51c48b-5fec-4309-9fbe-6b418094b292}</MetaDataID>
        [PersistentMember("_SignInUserIdentity"), BackwardCompatibilityID("+2")]
        public string SignInUserIdentity
        {
            get
            {
                return _SignInUserIdentity;
            }
            set
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _SignInUserIdentity = value;
                    stateTransition.Consistent = true;
                }
            }
        }


        /// <exclude>Excluded</exclude>
        string _SignInProvider;
        /// <MetaDataID>{dda41587-5296-4cce-85d4-a0c9567fee7b}</MetaDataID>
        [PersistentMember("_SignInProvider"), BackwardCompatibilityID("+3")]
        public string SignInProvider
        {
            get
            {
                return _SignInProvider;
            }
            set
            {
                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _SignInProvider = value;
                    stateTransition.Consistent = true;
                }
            }
        }

        /// <exclude>Excluded</exclude>
        string _FriendlyName;


        /// <MetaDataID>{d527686e-187a-4e4f-9128-7cc0d2275d63}</MetaDataID>
        [PersistentMember(nameof(_FriendlyName))]
        [BackwardCompatibilityID("+4")]
        public string FriendlyName
        {
            get
            {
                return _FriendlyName;
            }
            set
            {

                if (_FriendlyName != value)
                {
                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _FriendlyName = value;
                        stateTransition.Consistent = true;
                    }
                }
            }
        }

    }
}