﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MenuDesigner
{
    /// <summary>
    /// Interaction logic for MenuItemView.xaml
    /// </summary>
    /// <MetaDataID>{8e67f691-1759-4c87-ba21-016cd09d1d54}</MetaDataID>
    public partial class MenuItemView : ContentControl
    {
        public MenuItemView()
        {
           
            InitializeComponent();

        }



    }
}
