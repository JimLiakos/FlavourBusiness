﻿
namespace MenuDesigner
{
    // Common interface for items that can be selected
    // on the DesignerCanvas; used by DesignerItem and Connection
    /// <MetaDataID>{a2e90f4a-5f42-4645-9e07-52c0d1ef2d42}</MetaDataID>
    public interface ISelectable
    {
        /// <MetaDataID>{f09fa904-686c-4e8b-bbcc-96ef75b8e0ed}</MetaDataID>
        bool IsSelected { get; set; }
    }
}
