﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using MenuDesigner.Controls;
using OOAdvantech.Transactions;

using System.Linq;
using System.ComponentModel;

namespace MenuDesigner
{
    //These attributes identify the types of the named parts that are used for templating
    /// <MetaDataID>{a3134b2e-496b-402d-a37c-db8575f65ceb}</MetaDataID>
    [TemplatePart(Name = "PART_DragThumb", Type = typeof(DragThumb))]
    [TemplatePart(Name = "PART_ResizeDecorator", Type = typeof(Control))]
    [TemplatePart(Name = "PART_ConnectorDecorator", Type = typeof(Control))]
    [TemplatePart(Name = "PART_ContentPresenter", Type = typeof(ContentPresenter))]
    public class DesignerItem : ContentControl, ISelectable, IGroupable
    {
        #region ID
        /// <MetaDataID>{feb8ad99-38af-4f9f-bbfb-db0209d09399}</MetaDataID>
        private Guid id;
        /// <MetaDataID>{2eb81eb6-3454-40d3-a785-ad009a727809}</MetaDataID>
        public Guid ID
        {
            get { return id; }
        }
        #endregion

        #region ParentID
        /// <MetaDataID>{84d1ae0e-32f8-4f5d-9c76-60c423cff26d}</MetaDataID>
        public Guid ParentID
        {
            get
            {
                return (Guid)GetValue(ParentIDProperty);
            }
            set
            {
                //if (PresentationItem != null)
                //    PresentationItem.ParentID = value;

                SetValue(ParentIDProperty, value);
            }
        }
        /// <MetaDataID>{1ad723f1-eb0a-478c-b225-738e8828ec10}</MetaDataID>
        public static readonly DependencyProperty ParentIDProperty = DependencyProperty.Register("ParentID", typeof(Guid), typeof(DesignerItem));
        #endregion

        #region IsGroup
        /// <MetaDataID>{8ef60628-1387-46ad-a6cf-736d967f3efa}</MetaDataID>
        public bool IsGroup
        {
            get
            {
                return (bool)GetValue(IsGroupProperty);
            }
            set
            {
                //if (PresentationItem != null)
                //    PresentationItem.IsGroup = value;

                SetValue(IsGroupProperty, value);
            }
        }
        /// <MetaDataID>{4ef60e96-9714-4f08-bb90-28bbda8b66a8}</MetaDataID>
        public static readonly DependencyProperty IsGroupProperty =
            DependencyProperty.Register("IsGroup", typeof(bool), typeof(DesignerItem));
        #endregion

        #region IsSelected Property

        /// <MetaDataID>{21f52fff-03b2-4f0b-897a-efa4b95c3390}</MetaDataID>
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set
            {
                SetValue(IsSelectedProperty, value);
                DesignerCanvas designer = VisualTreeHelper.GetParent(this) as DesignerCanvas;

                // update selection
                if (designer != null)
                {
                    designer.ItemSelected();
                }
                PresentationItem.IsSelected = value;
            }
        }
        /// <MetaDataID>{d24af474-7f48-4366-a36b-bf3bb725c333}</MetaDataID>
        public static readonly DependencyProperty IsSelectedProperty =
          DependencyProperty.Register("IsSelected",
                                       typeof(bool),
                                       typeof(DesignerItem),
                                       new FrameworkPropertyMetadata(false));

        #endregion

        #region DragThumbTemplate Property

        // can be used to replace the default template for the DragThumb
        /// <MetaDataID>{8cffea8c-dbf7-42a3-bcfa-4f7e7b232189}</MetaDataID>
        public static readonly DependencyProperty DragThumbTemplateProperty =
            DependencyProperty.RegisterAttached("DragThumbTemplate", typeof(ControlTemplate), typeof(DesignerItem));

        /// <MetaDataID>{22bb9f70-745e-4324-a566-6d27fa2345a8}</MetaDataID>
        public static ControlTemplate GetDragThumbTemplate(UIElement element)
        {
            return (ControlTemplate)element.GetValue(DragThumbTemplateProperty);
        }

        /// <MetaDataID>{79668261-2267-4eca-8aab-7a32a353e675}</MetaDataID>
        public static void SetDragThumbTemplate(UIElement element, ControlTemplate value)
        {
            element.SetValue(DragThumbTemplateProperty, value);
        }

        #endregion

        #region ConnectorDecoratorTemplate Property

        //// can be used to replace the default template for the ConnectorDecorator
        //public static readonly DependencyProperty ConnectorDecoratorTemplateProperty =
        //    DependencyProperty.RegisterAttached("ConnectorDecoratorTemplate", typeof(ControlTemplate), typeof(DesignerItem));

        //public static ControlTemplate GetConnectorDecoratorTemplate(UIElement element)
        //{
        //    return (ControlTemplate)element.GetValue(ConnectorDecoratorTemplateProperty);
        //}

        //public static void SetConnectorDecoratorTemplate(UIElement element, ControlTemplate value)
        //{
        //    element.SetValue(ConnectorDecoratorTemplateProperty, value);
        //}

        #endregion

        #region IsDragConnectionOver

        // while drag connection procedure is ongoing and the mouse moves over 
        // this item this value is true; if true the ConnectorDecorator is triggered
        // to be visible, see template
        /// <MetaDataID>{c30dc218-67f9-43ef-a624-f885eca61a42}</MetaDataID>
        public bool IsDragConnectionOver
        {
            get { return (bool)GetValue(IsDragConnectionOverProperty); }
            set { SetValue(IsDragConnectionOverProperty, value); }
        }
        /// <MetaDataID>{fcd68d31-7bfe-49dd-8879-e6a3d4d7ff0d}</MetaDataID>
        public static readonly DependencyProperty IsDragConnectionOverProperty =
            DependencyProperty.Register("IsDragConnectionOver",
                                         typeof(bool),
                                         typeof(DesignerItem),
                                         new FrameworkPropertyMetadata(false));

        #endregion



        /// <MetaDataID>{6a03cc9c-4399-4b84-a669-335a586c2593}</MetaDataID>
        static DesignerItem()
        {
            // set the key to reference the style for this control
            FrameworkElement.DefaultStyleKeyProperty.OverrideMetadata(
                typeof(DesignerItem), new FrameworkPropertyMetadata(typeof(DesignerItem)));
        }
        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseUp(e);
            return;
            if (ParentID != Guid.Empty)
            {
                var objectContextConnection = this.GetObjectContextConnection();
                if (objectContextConnection.Transaction != null)
                {
                    using (SystemStateTransition stateTransition = new SystemStateTransition(objectContextConnection.Transaction))
                    {
                        (Parent as DesignerCanvas).GetDesignerItem(ParentID).UpdatePresentationItem();
                        stateTransition.Consistent = true;
                    }
                }
                else
                    (Parent as DesignerCanvas).GetDesignerItem(ParentID).UpdatePresentationItem();
            }
            else
            {
                var objectContextConnection = this.GetObjectContextConnection();
                if (objectContextConnection.Transaction != null)
                {
                    using (SystemStateTransition stateTransition = new SystemStateTransition(objectContextConnection.Transaction))
                    {
                        UpdatePresentationItem();
                        stateTransition.Consistent = true;
                    }
                }
                else
                    UpdatePresentationItem();
            }

            var a = 0;
        }


        internal MenuPresentationModel.PresentationItem PresentationItem;
        /// <MetaDataID>{1fb44dd5-8750-44f8-935c-fb8e2c2c7b32}</MetaDataID>
        public DesignerItem(Guid id, MenuPresentationModel.PresentationItem presentationItem)
        {
            this.id = id;
            this.Loaded += new RoutedEventHandler(DesignerItem_Loaded);
            SizeChanged += DesignerItem_SizeChanged;

            PresentationItem = presentationItem;
        }
        public void UpdatePresentationItem()
        {

            PresentationItem.Left = DesignerCanvas.GetLeft(this);
            PresentationItem.Top = DesignerCanvas.GetTop(this);
            PresentationItem.Width = Width;
            PresentationItem.Height = Height;
            PresentationItem.ID = ID;
            //PresentationItem.ParentID = ParentID;
            //PresentationItem.IsGroup = IsGroup;

            foreach (var designerItem in (from designerItem in (Parent as Canvas).Children.Cast<UIElement>().OfType<DesignerItem>()
                                          where designerItem.ParentID == ID
                                          select designerItem))
            {
                designerItem.UpdatePresentationItem();
            }
        }

        private void DesignerItem_SizeChanged(object sender, SizeChangedEventArgs e)
        {

        }

        /// <MetaDataID>{7a75f060-f605-4fc3-8ae6-4538104baf41}</MetaDataID>
        public DesignerItem(MenuPresentationModel.PresentationItem presentationItem)
            : this(Guid.NewGuid(), presentationItem)
        {
        }

      

        /// <MetaDataID>{2f23b2dd-2a28-467c-8518-22d51c57ea53}</MetaDataID>
        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseDown(e);

            DesignerCanvas designer = VisualTreeHelper.GetParent(this) as DesignerCanvas;
            bool isSelected = this.IsSelected;
            // update selection
            if (designer != null)
            {
                designer.ItemSelected();
                if ((Keyboard.Modifiers & (ModifierKeys.Shift | ModifierKeys.Control)) != ModifierKeys.None)
                    if (this.IsSelected)
                    {
                        designer.SelectionService.RemoveFromSelection(this);
                    }
                    else
                    {
                        designer.SelectionService.AddToSelection(this);
                    }
                else if (!this.IsSelected)
                {
                    designer.SelectionService.SelectItem(this);
                }
                Focus();
            }
            if (isSelected)
                e.Handled = false;
            else
                e.Handled = true;

        }

        /// <MetaDataID>{32921cc6-ee98-4508-8b62-d0804c612b99}</MetaDataID>
        void DesignerItem_Loaded(object sender, RoutedEventArgs e)
        {
            if (base.Template != null)
            {
                ContentPresenter contentPresenter =
                    this.Template.FindName("PART_ContentPresenter", this) as ContentPresenter;
                if (contentPresenter != null)
                {
                    var childrenCount = VisualTreeHelper.GetChildrenCount(contentPresenter);
                    if (childrenCount > 0)
                    {
                        UIElement contentVisual = VisualTreeHelper.GetChild(contentPresenter, 0) as UIElement;
                        if (contentVisual != null)
                        {
                            DragThumb thumb = this.Template.FindName("PART_DragThumb", this) as DragThumb;
                            if (thumb != null)
                            {
                                ControlTemplate template =
                                    DesignerItem.GetDragThumbTemplate(contentVisual) as ControlTemplate;
                                if (template != null)
                                    thumb.Template = template;
                            }
                        }
                    }
                }
            }

            var descriptor = DependencyPropertyDescriptor.FromProperty(Canvas.LeftProperty, typeof(DesignerItem));
            descriptor.AddValueChanged(this, OnCanvasLeftChanged);

            descriptor = DependencyPropertyDescriptor.FromProperty(Canvas.TopProperty, typeof(DesignerItem));
            descriptor.AddValueChanged(this, OnCanvasTopChanged);
        }

        void OnCanvasLeftChanged(object sender, EventArgs e)
        {

            var objectContextConnection = this.GetObjectContextConnection();
            if (objectContextConnection.Transaction != null)
            {
                using (SystemStateTransition stateTransition = new SystemStateTransition(objectContextConnection.Transaction))
                {
                    UpdatePresentationItem();
                    stateTransition.Consistent = true;
                }
            }
            else
                UpdatePresentationItem();

        }

        void OnCanvasTopChanged(object sender, EventArgs e)
        {
            var objectContextConnection = this.GetObjectContextConnection();
            if (objectContextConnection.Transaction != null)
            {
                using (SystemStateTransition stateTransition = new SystemStateTransition(objectContextConnection.Transaction))
                {
                    UpdatePresentationItem();
                    stateTransition.Consistent = true;
                }
            }
            else
                UpdatePresentationItem();
        }
    }
}
