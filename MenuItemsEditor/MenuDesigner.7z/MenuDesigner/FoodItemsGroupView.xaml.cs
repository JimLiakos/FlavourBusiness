﻿
using System;
using System.Windows;
using System.Windows.Controls;

using System.Windows.Input;
using System.Windows.Media;


namespace MenuDesigner
{
    /// <summary>
    /// Interaction logic for FoodItemsGroupView.xaml
    /// </summary>
    /// <MetaDataID>{a2c8c623-20ea-4f0f-9339-86a2df729ca7}</MetaDataID>
    public partial class FoodItemsGroupView : UserControl
    {
        public FoodItemsGroupView()
        {
            InitializeComponent();
            this.AllowDrop = true;
            DragEnter += FoodItemsGroupView_DragEnter;
        }

        private void FoodItemsGroupView_DragEnter(object sender, DragEventArgs e)
        {

        }

        public MenuPresentationModel.PresentationItemsGroup ItemsGroup
        {
            get;
            set;
        }

        public void AddMenuItem(MenuModel.IMenuItem menuItem)
        {

        }
        protected override void OnDragEnter(DragEventArgs e)
        {
            base.OnDragEnter(e);
        }

        protected override void OnDrop(DragEventArgs e)
        {
            e.Handled = true;


            base.OnDrop(e);
            DragObject dragObject = e.Data.GetData(typeof(DragObject)) as DragObject;
            if (dragObject.ToolboxItem != null && dragObject.ToolboxItem.GetDataContextObject() is MenuModel.MenuItem)
            {
                MenuModel.MenuItem menuItem = dragObject.ToolboxItem.GetDataContextObject<MenuModel.MenuItem>();
                var menuItemsPresentationViewModel = this.GetDataContextObject<MenuDesigner.MenuPresentetion.MenuItemsPresentationViewModel>();

                this.GetObjectContext().RunUnderContextTransaction(new Action(() =>
                {
                    menuItemsPresentationViewModel.AddMenuItem(new MenuPresentetion.MenuItemPresentationViewModel(menuItemsPresentationViewModel, menuItem));
                }));

            }
        }
        private Point elementStartPosition;
        private Point mouseStartPosition;
        private double dragAreaArrowYpos;
        MenuPresentetion.MenuItemPresentationViewModel dragMenuItem;
        private TranslateTransform transform = new TranslateTransform();
        private void Grid_MouseMove(object sender, MouseEventArgs e)
        {

            Grid dragArea = (sender as Grid).FindName("DragArea") as Grid;
            if (e.LeftButton == MouseButtonState.Pressed || dragArea.IsMouseCaptured)
            {
                Point mousetPosition = e.GetPosition(this);
                if (mousetPosition.Y > 0 && mousetPosition.Y < this.ActualHeight)
                {
                    Vector diff = e.GetPosition(this) - mouseStartPosition;
                    if (diff.Y > 3 || diff.Y < 3 || dragArea.IsMouseCaptured)
                    {
                        dragMenuItem = dragArea.GetDataContextObject<MenuPresentetion.MenuItemPresentationViewModel>();
                        if (!dragArea.IsMouseCaptured)
                        {
                            dragArea.Visibility = Visibility.Visible;
                            dragArea.RenderTransform = transform;
                            elementStartPosition = dragArea.TranslatePoint(new Point(0, 0), this);
                            mouseStartPosition = e.GetPosition(this);
                            dragArea.CaptureMouse();
                            UpdateLayout();
                            dragAreaArrowYpos = elementStartPosition.Y + (dragArea.ActualHeight / 2);
                        }

                        // transform.X = diff.X;
                        transform.Y = diff.Y;
                    }
                }
            }
        }



        private void Grid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Grid dragArea = (sender as Grid).FindName("DragArea") as Grid;
            if (dragArea.IsMouseCaptured)
            {
                dragArea.CaptureMouse();
                dragArea.Visibility = Visibility.Collapsed;
                dragAreaArrowYpos += transform.Y;
                int count = VisualTreeHelper.GetChildrenCount(MenuItemsControl);
                MenuPresentetion.MenuItemPresentationViewModel menuItem = null;
                foreach (var item in MenuItemsControl.Items)
                {
                    FrameworkElement uiElement = MenuItemsControl.ItemContainerGenerator.ContainerFromItem(item) as FrameworkElement;
                    Point itemControlPos = uiElement.TranslatePoint(new Point(0, 0), this);
                    double itemCenterY = itemControlPos.Y + (uiElement.ActualHeight / 2);
                    if (dragAreaArrowYpos > itemCenterY)
                        menuItem = uiElement.GetDataContextObject<MenuPresentetion.MenuItemPresentationViewModel>();
                }
                this.GetObjectContext().RunUnderContextTransaction(new Action(() =>
                {
                    dragMenuItem.MoveItemAfter(menuItem);
                }));
               
                e.Handled = true;
            }
        }


        private void RemoveBtn_Click(object sender, RoutedEventArgs e)
        {
            (sender as FrameworkElement).GetDataContextObject<MenuDesigner.MenuPresentetion.MenuItemPresentationViewModel>().Remove();
        }
        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.ClickCount == 1 && e.LeftButton == MouseButtonState.Released)
            {

                FrameworkElement senderElement = e.OriginalSource as FrameworkElement;
                var menuItemPresentationViewModel = senderElement.GetDataContextObject<MenuPresentetion.MenuItemPresentationViewModel>();
                bool? dialogResult;
                senderElement.GetObjectContext().RunUnderContextTransaction(new Action(() =>
                 {
                     if (menuItemPresentationViewModel != null)
                     {
                         System.Windows.Window win = System.Windows.Window.GetWindow(e.OriginalSource as System.Windows.DependencyObject);

                         MenuItemWindow menuItemWindow = new MenuItemWindow();
                         menuItemWindow.SetObjectContextInstance<MenuPresentetion.MenuItemPresentationViewModel>(menuItemPresentationViewModel);
                         menuItemWindow.Owner = win;
                         dialogResult = menuItemWindow.ShowDialog();
                     }

                 }));




            }

        }


    }



}
