﻿using System;

namespace MenuDesigner
{
    /// <MetaDataID>{f9bacf6d-30f8-4595-a469-db5a74264d57}</MetaDataID>
    public interface IGroupable
    {
        /// <MetaDataID>{bdbb2203-6a1b-419d-9541-70f71f1f8a64}</MetaDataID>
        Guid ID { get; }
        /// <MetaDataID>{224ce9e5-d13c-4e3a-8e86-fe412d45a87a}</MetaDataID>
        Guid ParentID { get; set; }
        /// <MetaDataID>{cca74328-fc5c-441c-9da8-d38b2c9b09cd}</MetaDataID>
        bool IsGroup { get; set; }
    }
}
