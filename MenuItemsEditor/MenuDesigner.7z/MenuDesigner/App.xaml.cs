﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Speech.Synthesis;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Xml.Linq;
using GenWebBrowser;
using OOAdvantech.Transactions;
using OOAdvantech.PersistenceLayer;
using FlavourBusinessManager;
using FlavourBusinessFacade;
using System.Diagnostics;
using OOAdvantech.Json;
using OOAdvantech.Remoting.RestApi;
using Newtonsoft.Json.Linq;
using OOAdvantech.Remoting.RestApi.Serialization;
using MenuModel;

namespace MenuDesigner
{

    /// <MetaDataID>{4cccb713-0284-418a-ba32-a1127428d2ff}</MetaDataID>
    public class FontFaceLineBulder
    {
        public static string GetFontFaceLine(FileInfo fileInfo)
        {
            try
            {
                System.Windows.Media.GlyphTypeface glyphTypeface = new System.Windows.Media.GlyphTypeface(new Uri(fileInfo.FullName));
                string fontWeight = GetFontWeight(glyphTypeface);
                string fontStyle = GetFontStyle(glyphTypeface);
                string fontUrl = fileInfo.FullName.Replace(@"C:\ProgramData\Microneme\DontWaitWater\Fonts\", "./").Replace(@"\", "/");
                string cssFondFace = "@font-face{" + string.Format("font-family:'{0}';font-style:{1};font-weight:{2};src:url({3}) format('truetype')", glyphTypeface.FamilyNames.ToArray()[0].Value, fontStyle, fontWeight, fontUrl) + "}";
                return cssFondFace;
            }
            catch (System.Exception error)
            {
                return null;
            }
        }

        private static string GetFontWeight(GlyphTypeface glyphTypeface)
        {
            return glyphTypeface.Weight.ToOpenTypeWeight().ToString();// "400";//normal
        }
        private static string GetFontStyle(GlyphTypeface glyphTypeface)
        {
            if (glyphTypeface.Style == FontStyles.Italic)
                return "italic";
            else
                return "normal";
        }
    }

    /// <MetaDataID>{9a8c377e-ffd8-4680-83f1-3582fca64e96}</MetaDataID>
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    /// <MetaDataID>{7f2f3f78-eaaf-47bc-a00b-861ba15bed51}</MetaDataID>
    public partial class App : Application
    {
        //fff069bc4ede44d9a1f08b5f998e02ad
        public Queue<System.Threading.Tasks.Task> Tasks = new Queue<System.Threading.Tasks.Task>();
        public bool Runs = true;
        public void RunAsync()
        {
            System.Threading.Tasks.Task.Run(() =>
            {
                while (Runs)
                {
                    if (Tasks.Count > 0)
                    {
                        var task = Tasks.Dequeue();
                        task.Start();
                        task.Wait();
                    }
                    else
                    {
                        System.Threading.Thread.Sleep(100);
                    }
                }
            });
        }

        public App()
        {
            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.UnhandledException += CurrentDomain_UnhandledException;
            OOAdvantech.PersistenceLayer.StorageServerInstanceLocator.AddStorageLocatorExtender(new StorageLocatorEx());
            OOAdvantech.Remoting.RestApi.RemotingServices.ServerPublicUrl = "http://192.168.2.12:8090/api/";



            //FlavourBusinessManager.EndUsers.FoodServiceClientSession foodServiceClientSessionA = null;
            //FlavourBusinessManager.EndUsers.FoodServiceClientSession foodServiceClientSessionB = null;
            //FlavourBusinessManager.EndUsers.FoodServiceClientSession foodServiceClientSessionG = null;
            //FlavourBusinessManager.EndUsers.FoodServiceClientSession foodServiceClientSessionD = null;
            //foodServiceClientSessionA = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\1f7c6d29-078d-4dde-aacf-1850daa24ff5") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;
            //foodServiceClientSessionB = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\57d66746-af59-4987-b4c4-c2ddc56c54d4") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;

            //OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(foodServiceClientSessionA));
            //var vitemPreparation = (from item in storage.GetObjectCollection<FlavourBusinessManager.RoomService.ItemPreparation>()
            //                       where item.uid == "550f9142e51b4145a1cb3d9fc6b2c7b5"
            //                       select item).FirstOrDefault();
            //var sItem = new FlavourBusinessManager.RoomService.ItemPreparation(vitemPreparation.uid, vitemPreparation.MenuItemUri, vitemPreparation.Name);
            //sItem.Update(vitemPreparation);
            //sItem.IsShared = true;

            //var sItem1 = new FlavourBusinessManager.RoomService.ItemPreparation(vitemPreparation.uid, vitemPreparation.MenuItemUri, vitemPreparation.Name);
            //sItem1.Update(vitemPreparation);
            //sItem1.IsShared = false;

            //var sItem2 = new FlavourBusinessManager.RoomService.ItemPreparation(vitemPreparation.uid, vitemPreparation.MenuItemUri, vitemPreparation.Name);
            //sItem2.Update(vitemPreparation);
            //sItem2.IsShared = true;

            //var sItem3 = new FlavourBusinessManager.RoomService.ItemPreparation(vitemPreparation.uid, vitemPreparation.MenuItemUri, vitemPreparation.Name);
            //sItem3.Update(vitemPreparation);
            //sItem3.IsShared = false;


            //var sItem4 = new FlavourBusinessManager.RoomService.ItemPreparation(vitemPreparation.uid, vitemPreparation.MenuItemUri, vitemPreparation.Name);
            //sItem4.Update(vitemPreparation);
            //sItem4.IsShared = true;



            //string phrase1 = "phrase1";
            //string phrase2 = "phrase2";
            //string phrase3 = "phrase3";
            //string phrase4 = "phrase4";
            //string phrase5 = "phrase5";


            //var task = new System.Threading.Tasks.Task(() =>
            //{
            //    //var itemPreparation = (from item in storage.GetObjectCollection<FlavourBusinessManager.RoomService.ItemPreparation>()
            //    //                       where item.uid == "550f9142e51b4145a1cb3d9fc6b2c7b5"
            //    //                       select item).FirstOrDefault();

            //    vitemPreparation.Update(sItem);
            //    foodServiceClientSessionA = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\1f7c6d29-078d-4dde-aacf-1850daa24ff5") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;
            //    foodServiceClientSessionB = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\57d66746-af59-4987-b4c4-c2ddc56c54d4") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;


            //    System.Diagnostics.Debug.WriteLine(phrase1);

            //});

            //var task2 = new System.Threading.Tasks.Task(() =>
            //{
            //    //var itemPreparation = (from item in storage.GetObjectCollection<FlavourBusinessManager.RoomService.ItemPreparation>()
            //    //                       where item.uid == "550f9142e51b4145a1cb3d9fc6b2c7b5"
            //    //                       select item).FirstOrDefault();

            //    vitemPreparation.Update(sItem1);
            //    foodServiceClientSessionG = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\1f7c6d29-078d-4dde-aacf-1850daa24ff5") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;
            //    foodServiceClientSessionD = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\57d66746-af59-4987-b4c4-c2ddc56c54d4") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;
            //    System.Diagnostics.Debug.WriteLine(phrase2);
            //});

            //var task3 = new System.Threading.Tasks.Task(() =>
            //{
            //    //var itemPreparation = (from item in storage.GetObjectCollection<FlavourBusinessManager.RoomService.ItemPreparation>()
            //    //                       where item.uid == "550f9142e51b4145a1cb3d9fc6b2c7b5"
            //    //                       select item).FirstOrDefault();

            //    vitemPreparation.Update(sItem3);
            //    foodServiceClientSessionG = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\1f7c6d29-078d-4dde-aacf-1850daa24ff5") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;
            //    foodServiceClientSessionD = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\57d66746-af59-4987-b4c4-c2ddc56c54d4") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;
            //    System.Diagnostics.Debug.WriteLine(phrase3);
            //});

            //var task4 = new System.Threading.Tasks.Task(() =>
            //{
            //    //var itemPreparation = (from item in storage.GetObjectCollection<FlavourBusinessManager.RoomService.ItemPreparation>()
            //    //                       where item.uid == "550f9142e51b4145a1cb3d9fc6b2c7b5"
            //    //                       select item).FirstOrDefault();

            //    vitemPreparation.Update(sItem4);

            //    foodServiceClientSessionG = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\1f7c6d29-078d-4dde-aacf-1850daa24ff5") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;
            //    foodServiceClientSessionD = ObjectStorage.GetObjectFromUri(@"3bdea2dc-3185-4331-bdb9-f17c535f2965\6\57d66746-af59-4987-b4c4-c2ddc56c54d4") as FlavourBusinessManager.EndUsers.FoodServiceClientSession;
            //    System.Diagnostics.Debug.WriteLine(phrase4);

            //});

            //task.Start();
            //task2.Start();
            //task3.Start();
            //task4.Start();

            //task.Wait();
            //task2.Wait();
            //task3.Wait();
            //task4.Wait();

            //Tasks.Enqueue(task);
            //Tasks.Enqueue(task2);
            //Tasks.Enqueue(task3);
            //Tasks.Enqueue(task4);
            //RunAsync();
            //var ss = foodServiceClientSessionA.MainSession.PartialClientSessions.ToArray();
            //var sss = foodServiceClientSessionB.MainSession.PartialClientSessions.ToArray();

            //if (ss.Length != 3 || sss.Length != 3)
            //{
            //    ss = sss;
            //}

            int teros = 0;


            //var task = System.Threading.Tasks.Task.Run(() =>
            //  {
            //      MetadataRepositoryTest();
            //  });
            //var task1 = System.Threading.Tasks.Task.Run(() =>
            //{
            //    MetadataRepositoryTest();
            //});

            //var task2 = System.Threading.Tasks.Task.Run(() =>
            //{
            //    MetadataRepositoryTest();
            //});

            //var task3 = System.Threading.Tasks.Task.Run(() =>
            //{
            //    MetadataRepositoryTest();
            //});

            //task.Wait();
            //task1.Wait();
            //task2.Wait();
            //task3.Wait();



        }

        private void MetadataRepositoryTest()
        {
            var _is = OOAdvantech.MetaDataRepository.Classifier.GetClassifier(typeof(MenuModel.ItemSelectorOption)).IsA(OOAdvantech.MetaDataRepository.Classifier.GetClassifier(typeof(MenuModel.IPreparationOption)));
            var feature = OOAdvantech.MetaDataRepository.Classifier.GetClassifier(typeof(MenuModel.PreparationScaledOption)).Features;
            var assosEnd = OOAdvantech.MetaDataRepository.Classifier.GetClassifier(typeof(IPreparationOption)).GetAssociateRoles(false).Where(x => x.Name == "Owner").FirstOrDefault();
            var cou = assosEnd.AssociationEndRealizations.Count;

        }

        public static void InformEventLog(System.Exception Error)
        {
#if !DeviceDotNet
            if (!System.Diagnostics.EventLog.SourceExists("MenuDesgner", "."))
            {
                System.Diagnostics.EventLog.CreateEventSource("MenuDesgner", "MenuDesgnerApp");
            }

            //TODO γεμισει με message το log file τοτε παράγει exception
            System.Diagnostics.EventLog myLog = new System.Diagnostics.EventLog();
            myLog.Source = "MenuDesgner";
            if (myLog.OverflowAction != System.Diagnostics.OverflowAction.OverwriteAsNeeded)
                myLog.ModifyOverflowPolicy(System.Diagnostics.OverflowAction.OverwriteAsNeeded, 0);

            System.Diagnostics.Debug.WriteLine(
                Error.Message + Error.StackTrace);
            myLog.WriteEntry(Error.Message + Error.StackTrace, System.Diagnostics.EventLogEntryType.Error);
            System.Exception InerError = Error.InnerException;
            while (InerError != null)
            {
                //TODO να διαχειρίζωμε σωστά το log file μηπως και κάνει overflow

                System.Diagnostics.Debug.WriteLine(
                    InerError.Message + InerError.StackTrace);
                myLog.WriteEntry(InerError.Message + InerError.StackTrace, System.Diagnostics.EventLogEntryType.Error);
                InerError = InerError.InnerException;
            }
#endif
        }


        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs args)
        {

            Exception e = (Exception)args.ExceptionObject;
            InformEventLog(e);
            Console.WriteLine("MyHandler caught : " + e.Message);
            Console.WriteLine("StackTrace caught : " + e.StackTrace);
            Console.WriteLine("Runtime terminating: {0}", args.IsTerminating);
            MessageBox.Show(e.Message + " " + e.StackTrace);
        }

        protected override void OnExit(ExitEventArgs e)
        {
            CefSharp.Cef.Shutdown();

            base.OnExit(e);
        }

        public static string SignInHtmlPath;
        void PrepareSigninhtml()
        {
            string curDir = System.IO.Directory.GetCurrentDirectory();
            string internetCache = System.Environment.GetFolderPath(System.Environment.SpecialFolder.InternetCache);
            string sourcePath = String.Format(@"{0}\SignInHtml", curDir);
            string destinationPath = String.Format(@"{0}\SignInHtml", internetCache);
            SignInHtmlPath = destinationPath;
            System.IO.Directory.Delete(destinationPath, true);
            Copy(sourcePath, destinationPath);
        }

        private static ObjectStorage OpenFlavourBusinessesStorage()
        {
            ObjectStorage storageSession = null;
            string storageName = "FlavourBusinesses";
            string storageLocation = "DevStorage";
            string storageType = "OOAdvantech.WindowsAzureTablesPersistenceRunTime.StorageProvider";

            try
            {
                storageSession = ObjectStorage.OpenStorage(storageName,
                                                            storageLocation,
                                                            storageType);
                // storageSession.StorageMetaData.RegisterComponent(typeof(Organization).Assembly.FullName);
            }
            catch (OOAdvantech.PersistenceLayer.StorageException Error)
            {
                if (Error.Reason == StorageException.ExceptionReason.StorageDoesnotExist)
                {
                    storageSession = ObjectStorage.NewStorage(storageName,
                                                            storageLocation,
                                                            storageType);
                }
                else
                    throw Error;
                try
                {
                    storageSession.StorageMetaData.RegisterComponent(typeof(Organization).Assembly.FullName);
                }
                catch (System.Exception Errore)
                {
                    int sdf = 0;
                }
            }
            catch (System.Exception Error)
            {
                int tt = 0;
            }

            return storageSession;
        }

        private void AddValuePrperties(JObject transformedObject, IEnumerable<JProperty> properties)
        {
            foreach (JProperty jProperty in properties)
            {
                if (jProperty.Value is JObject)
                {
                    if ((jProperty.Value as JObject)["$value"] is JValue)
                    {
                        transformedObject.Add(jProperty.Name, (jProperty.Value as JObject)["$value"]);
                    }
                    else
                    {
                        if (jProperty.Name == "$value")
                        {
                            AddValuePrperties(transformedObject, (jProperty.Value as JObject).Properties());
                        }
                        else
                        {
                            JObject properyObject = new JObject();
                            transformedObject.Add(jProperty.Name, properyObject);
                            AddValuePrperties(properyObject, (jProperty.Value as JObject).Properties());
                        }
                    }
                }
                else if (jProperty.Value is JArray)
                {
                    JArray transformedjArray = TransformArray(jProperty.Value as JArray);
                    transformedObject.Add(jProperty.Name, transformedjArray);
                }
                else
                    transformedObject.Add(jProperty.Name, jProperty.Value);
            }
        }

        private JArray TransformArray(JArray jArray)
        {
            JArray transformedjArray = new JArray();
            foreach (JToken item in jArray)
            {
                if (item is JObject)
                {
                    JObject properyObject = new JObject();
                    transformedjArray.Add(properyObject);
                    AddValuePrperties(properyObject, (item as JObject).Properties());
                }
                else if (item is JArray)
                {
                    transformedjArray.Add(TransformArray(item as JArray));
                }
                else
                    transformedjArray.Add(item.DeepClone());

            }
            return transformedjArray;

        }


        protected override void OnStartup(StartupEventArgs e)
        {

            try
            {

                var attribute= OOAdvantech.MetaDataRepository.Classifier.GetClassifier(typeof(MenuModel.IMenuItem)).Features.OfType<OOAdvantech.MetaDataRepository.Attribute>().Where(x => x.Name == "Description").FirstOrDefault();

                var IsMultilingual = (OOAdvantech.MetaDataRepository.Classifier.GetClassifier(typeof(MenuModel.MenuItem)) as OOAdvantech.MetaDataRepository.Class).IsMultilingual(attribute);




                string storageName = "FlavourBusinesses"; 
                //string storageLocation = "DevStorage";
                //string storageType = "OOAdvantech.WindowsAzureTablesPersistenceRunTime.StorageProvider";

                //var demoStorage = ObjectStorage.OpenStorage(storageName, storageLocation, storageType);
                //OOAdvantech.WindowsAzureTablesPersistenceRunTime.CloudBlockBlobArchive archive = new OOAdvantech.WindowsAzureTablesPersistenceRunTime.CloudBlockBlobArchive(string.Format(@"e:\backup\{0}.dat", storageName));
                //demoStorage.Backup(archive);

                //storageName = "FlavourBusinessesResources";
                //demoStorage = ObjectStorage.OpenStorage(storageName, storageLocation, storageType);
                //archive = new OOAdvantech.WindowsAzureTablesPersistenceRunTime.CloudBlockBlobArchive(string.Format(@"e:\backup\{0}.dat", storageName));
                //demoStorage.Backup(archive);

                //storageName = "jimliakosgmailcom";
                //demoStorage = ObjectStorage.OpenStorage(storageName, storageLocation, storageType);
                //archive = new OOAdvantech.WindowsAzureTablesPersistenceRunTime.CloudBlockBlobArchive(string.Format(@"e:\backup\{0}.dat", storageName));
                //demoStorage.Backup(archive);



                //using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
                //{
                //    foreach (var rtable in (demoStorage.StorageMetaData as OOAdvantech.MetaDataRepository.Namespace).OwnedElements.OfType<OOAdvantech.RDBMSMetaDataRepository.Table>())
                //    {
                //        var name = rtable.Name;
                //        var dname = rtable.DataBaseTableName;

                //        if (name.IndexOf("_")!=-1)
                //            continue;
                //        rtable.Name = name;
                //        rtable.DataBaseTableName = name;
                //    } 
                //    stateTransition.Consistent = true;
                //}


                //var id = demoStorage.StorageMetaData.StorageIdentity;


                //storageName = "jimliakosgmailcom";
                //try
                //{
                //    archive = new OOAdvantech.WindowsAzureTablesPersistenceRunTime.CloudBlockBlobArchive(string.Format(@"e:\backup\{0}.dat", storageName));
                //    ObjectStorage.Restore(archive, "jimliakosgmailcom", "DevStorage", "OOAdvantech.WindowsAzureTablesPersistenceRunTime.StorageProvider", false);

                //}
                //catch (Exception error)
                //{
                //}

                //try
                //{
                //    var demoStorage = ObjectStorage.OpenStorage(storageName, storageLocation, storageType);

                //    (demoStorage as OOAdvantech.WindowsAzureTablesPersistenceRunTime.ObjectStorage).ClearTemporaryFiles();

                //}
                //catch (Exception error)
                //{
                //    ObjectStorage.Repair( "jimliakosgmailcom", "DevStorage", "OOAdvantech.WindowsAzureTablesPersistenceRunTime.StorageProvider", false);

                //}


                //storageName = "FlavourBusinesses";
                //archive = new OOAdvantech.WindowsAzureTablesPersistenceRunTime.CloudBlockBlobArchive(string.Format(@"e:\backup\{0}.dat", storageName));
                //ObjectStorage.Restore(archive, storageName, "DevStorage", "OOAdvantech.WindowsAzureTablesPersistenceRunTime.StorageProvider", false);


                //storageName = "FlavourBusinessesResources";
                //archive = new OOAdvantech.WindowsAzureTablesPersistenceRunTime.CloudBlockBlobArchive(string.Format(@"e:\backup\{0}.dat", storageName));
                //ObjectStorage.Restore(archive, storageName, "DevStorage", "OOAdvantech.WindowsAzureTablesPersistenceRunTime.StorageProvider", false);



                //var objectStorage = ObjectStorage.OpenStorage(storageName,
                //                                           storageLocation,
                //                                           storageType);

                //objectStorage.Backup(atchive);





                // WebBrowserHelper.FixBrowserVersion();

                // string rtr= "9CAF873D-8193-4DDA-A712-0F4BADB1A25F".ToLower();

                var tt = OOAdvantech.Remoting.RemotingServices.Sessions;
                SerializationBinder.NamesTypesDictionary["Array"] = typeof(object[]);
                SerializationBinder.NamesTypesDictionary["String"] = typeof(string);
                SerializationBinder.NamesTypesDictionary["Number"] = typeof(double);
                SerializationBinder.NamesTypesDictionary["Date"] = typeof(DateTime);
                SerializationBinder.NamesTypesDictionary["Array"] = typeof(List<>);

                SerializationBinder.NamesTypesDictionary["Map"] = typeof(Dictionary<,>);


                SerializationBinder.TypesNamesDictionary[typeof(bool)] = "Boolean";
                SerializationBinder.TypesNamesDictionary[typeof(int)] = "Number";
                SerializationBinder.TypesNamesDictionary[typeof(double)] = "Number";
                SerializationBinder.TypesNamesDictionary[typeof(decimal)] = "Number";
                SerializationBinder.TypesNamesDictionary[typeof(float)] = "Number";
                SerializationBinder.TypesNamesDictionary[typeof(short)] = "Number";
                SerializationBinder.TypesNamesDictionary[typeof(long)] = "Number";
                SerializationBinder.TypesNamesDictionary[typeof(string)] = "String";
                SerializationBinder.TypesNamesDictionary[typeof(DateTime)] = "Date";
                SerializationBinder.TypesNamesDictionary[typeof(object[])] = "Array";
                SerializationBinder.TypesNamesDictionary[typeof(List<>)] = "Array";
                SerializationBinder.TypesNamesDictionary[typeof(System.Collections.ObjectModel.ReadOnlyCollection<>)] = "Array";
                SerializationBinder.TypesNamesDictionary[typeof(Dictionary<,>)] = "Map";

                Person person1 = new Person() { Age = 12, Name = "Losa" };
                Person person2 = new Person() { Age = 22, Name = "Susan" };
                Person person3 = new Person() { Age = 28, Name = "Madas" };


                //string jsonEx = System.IO.File.ReadAllText(@"C:\menu.txt");

                ////var jSetttings = new JsonSerializerSettings() { TypeNameHandling = TypeNameHandling.All, ContractResolver = new JsonContractResolver(JsonContractType.Deserialize, ChannelUri, InternalChannelUri, serverSessionPart, argsTypes, Web), Binder = new OOAdvantech.Remoting.RestApi.SerializationBinder(true) };
                //var jSetttings = new OOAdvantech.Remoting.RestApi.Serialization.JsonSerializerSettings(JsonContractType.Serialize, JsonSerializationFormat.NetTypedValuesJsonSerialization, null);

                //jsonEx = OOAdvantech.Json.JsonConvert.SerializeObject(new Temp(), jSetttings);
                //jSetttings = new OOAdvantech.Remoting.RestApi.Serialization.JsonSerializerSettings(JsonContractType.Deserialize, JsonSerializationFormat.NetTypedValuesJsonSerialization, null);
                //var sss = OOAdvantech.Json.JsonConvert.DeserializeObject<object>(jsonEx, jSetttings);

                //jsonEx = System.IO.File.ReadAllText(@"e:\objref.txt");

                //  var sss = OOAdvantech.Json.JsonConvert.DeserializeObject<object>(jsonEx, jSetttings);



                string JsonArgs = "{\"$type\":\"OOAdvantech.Json.Serialization.ObjectRefProperyValue, OOAdvantech.Json\",\"__type\":\"ObjectRefProperyValue\",\"$value\":{\"Value\":{\"$type\":\"OOAdvantech.Json.Serialization.Proxy, OOAdvantech.Json\",\"__type\":\"Proxy\",\"$value\":{\"RealObject\":{\"$type\":\"Flavour.Person\",\"__type\":\"Person\",\"$value\":{\"_Name\":{\"__type\":\"String\",\"$value\":\"Mitsos\"}}}}}}}";

                JsonArgs = "{\"__type\":\"Array\",\"$values\":[{\"__type\":\"String\",\"$value\":\"Δημήτρης Λιάκος\"}]}";

                JsonArgs = "{\"__type\":\"Array\",\"$values\":[{\"$type\":\"FlavourBusinessFacade.WorkerData, FlavourBusinessFacade\",\"__type\":\"WorkerData\",\"$value\":{\"Name\":{\"__type\":\"String\",\"$value\":\"liakos\"},\"Email\":{\"__type\":\"String\",\"$value\":\"swe @gmail\"}}}]}";

                WorkerData workerData = new WorkerData() { Name = "liakos", Email = "swe@gmail", Revision = 3 };

                WorkerData subworkerData = new WorkerData() { Name = "matas", Email = "matas@gmail", Revision = 1 };
                workerData.SubWorkerDataA = subworkerData;
                workerData.SubWorkerDataB = subworkerData;

                object[] args = new object[1] { workerData }; //,new Organization("123123")};
                //JsonArgs = TransforWebJson(JsonArgs);

                //JsonContractResolver contractResolver = new JsonContractResolver(JsonContractType.Deserialize, null, false);
                //jSetttings = new OOAdvantech.Json.JsonSerializerSettings() { TypeNameHandling = TypeNameHandling.All, ContractResolver = contractResolver, Binder = new OOAdvantech.Remoting.RestApi.SerializationBinder(JsonSerializationFormat.NetJsonSerialization) };
                ////var jSetttings = new JsonSerializerSettings() { TypeNameHandling = TypeNameHandling.All, ContractResolver = new JsonContractResolver(JsonContractType.Serialize, null, null, null) };

                ////var obArgs = (object[])JsonConvert.DeserializeObject(JsonArgs, jSetttings);

                //contractResolver = new JsonContractResolver(JsonContractType.Deserialize,  new ServerSessionPart(Guid.NewGuid(), "local_device", null, true), true);

                //contractResolver.CSharptoJsTypesDictionary[typeof(int)] = "Number";
                //contractResolver.CSharptoJsTypesDictionary[typeof(string)] = "String";
                //contractResolver.CSharptoJsTypesDictionary[typeof(object[])] = "Array";

                //contractResolver.JstoCSharpTypesDictionary["Number"] = typeof(double);
                //contractResolver.JstoCSharpTypesDictionary["String"] = typeof(string);
                //contractResolver.JstoCSharpTypesDictionary["Array"] = typeof(object[]);



                //Dictionary<int , Person> selena = new Dictionary<int, Person>();
                //selena[12] = person1;// "Liakos";
                //selena[13] = person2;// 2.3;
                //selena[14] = person1;// workerData.SubWorkerDataB;
                //args = new object[] { selena };
                //Type[] argTypes = new Type[] { args[0].GetType() };
                //contractResolver = new JsonContractResolver(JsonContractType.Deserialize, "local_device", null, new ServerSessionPart(Guid.NewGuid()), argTypes,true);

                //jSetttings = new JsonSerializerSettings() { TypeNameHandling = TypeNameHandling.All , ContractResolver = contractResolver, Binder = new OOAdvantech.Remoting.RestApi.SerializationBinder(true) };
                //var jso = JsonConvert.SerializeObject(args, jSetttings);


                //args =   JsonConvert.DeserializeObject<object[]>(jso, jSetttings) as object[];

                ////bool eq= selenas[12] == selenas[14];
                ////eq = selena[12] == selenas[14];

                ////var jso = JsonConvert.SerializeObject(args, jSetttings);

                //jso = "{\"__type\":\"Array\",\"$values\":[{\"$type\":\"FlavourBusinessFacade.WorkerData, FlavourBusinessFacade\",\"__type\":\"WorkerData\",\"$value\":{\"Name\":{\"__type\":\"String\",\"$value\":\"liakos\"},\"Email\":{\"__type\":\"String\",\"$value\":\"swe@gmail\"},\"Revision\":{\"__type\":\"Number\",\"$value\":3},\"SubWorkerDataA\":{\"$type\":\"FlavourBusinessFacade.WorkerData, FlavourBusinessFacade\",\"__type\":\"WorkerData\",\"$value\":{\"Name\":{\"__type\":\"String\",\"$value\":\"matas\"},\"Email\":{\"__type\":\"String\",\"$value\":\"matas@gmail\"},\"Revision\":{\"__type\":\"Number\",\"$value\":1}}},\"SubWorkerDataB\":{\"__type\":\"ref\",\"$value\":{\"$type\":\"FlavourBusinessFacade.WorkerData, FlavourBusinessFacade\",\"__type\":\"WorkerData\",\"index\":1}}}}]}";

                //var obj = JsonConvert.DeserializeObject(jso, jSetttings);
                ////object[] Args = new object[3] { \"ss\", 7, 7.5 };

                ////string jsonArgs = JsonConvert.SerializeObject(Args, jSetttings);

                int rr = 0;


                //using (var task = System.Threading.Tasks.Task.Delay(2000))
                //{
                //    task.Wait();
                //}

                //watch.Stop();
                //var objectStorage = OpenFlavourBusinessesStorage();


                //string pUri = @"34529076-927b-42c7-ab22-8277f67551ff\3\718f2827-42af-46bd-a3d8-0d36182455de";

                //object tre= objectStorage.GetObject(pUri);

                //int eer = 0;


                //using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
                //{
                //    Organization org = new Organization(Guid.NewGuid().ToString("N"));
                //    //org.GetStorage(OrganizationStorages.RestaurantMenus);

                //    var fbstorage = new FlavourBusinessStorage();
                //    objectStorage.CommitTransientObjectState(org);
                //    //objectStorage.CommitTransientObjectState(fbstorage);


                //    stateTransition.Consistent = true;
                //}





                //System.Diagnostics.Debug.WriteLine("Time elapsed: " + watch.Elapsed);


                MenuPresentationModel.MenuStyles.HeadingAccent.ResourcesRootPath = @"C:\ProgramData\Microneme\DontWaitWater\";

                MenuPresentationModel.MenuStyles.PageStyle.ResourcesRootPath = @"C:\ProgramData\Microneme\DontWaitWater\";

                string assemblyData = "FlavourBusinessManager, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null";
                string type = "FlavourBusinessManager.AuthFlavourBusiness";// typeof(FlavourBusinessManager.AuthFlavourBusiness).FullName;
                //AuthUser authUser = System.Runtime.Remoting.Messaging.CallContext.GetData("AutUser") as AuthUser;
                string serverUrl = "http://localhost/FlavourBusinessWebApiRole/api/";
                serverUrl = "http://localhost:8090/api/";

                Assembly assembly = typeof(FlavourBusinessFacade.IFlavoursServicesContext).Assembly;//  System.Reflection.Assembly.LoadFile(@"C:\Projects\OpenVersions\PersistenceLayer\DotNetPersistenceLayer\Xamarin\DontWaitApp\FlavourBusinessFacade\bin\Debug\XFlavourBusinessFacade.dll");

                //FacadeProxiesGenerator.ProxiesGenerator.GenerateProxies(assembly,FacadeProxiesGenerator.ProxiesOutput.CSharp, @"E:\MyWindowProfileData\Documents");
                //FacadeProxiesGenerator.ProxiesGenerator.GenerateProxiesAssembly(assembly, @"C:\Projects\OpenVersions\PersistenceLayer\DotNetPersistenceLayer\Xamarin\DontWaitApp\FlavourBusinessFacade");

                //System.Threading.Thread.Sleep(6000);
                //IAuthFlavourBusiness pAuthFlavourBusines = OOAdvantech.Remoting.RestApi.RemotingServices.CreateRemoteInstance(serverUrl, type, assemblyData) as IAuthFlavourBusiness;
                //string mor = "";
                //var organization = pAuthFlavourBusines.SignIn();
                //string mes = pAuthFlavourBusines.GetMessage("lias", 23, organization, out mor);

                //Organization.CurrentOrganization = organization;





                //ObjectStorage objectStorage = OpenFlavourBusinessesStorage();

                //string userId = authUser.User_ID;
                //OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(objectStorage);
                //var organization = (from _organization in storage.GetObjectCollection<Organization>()
                //                        //where _organization.Identity == userId
                //                    select _organization).FirstOrDefault();

                //var servicePoints = organization.ServicePoints;
                //if (servicePoints.Count > 0)
                //{
                //    var servicePoint = servicePoints[0];

                //    var ss = servicePoint.RunAtContext;
                //    using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
                //    {
                //        organization.DeleteServicePoint(servicePoint);
                //        stateTransition.Consistent = true;
                //    }
                //}
                //else
                //    organization.NewFlavoursServicePoint();



                // PrepareSigninhtml();

                //string fgf = Guid.NewGuid().ToString("N");
                //string fgf= Guid.NewGuid().ToString("N"); 
                //var svgDoc=XDocument.Load(@"C:\ProgramData\Microneme\DontWaitWater\AccentImages\Box_Arrow_3.svg");
                //var styleText = svgDoc.Root.Descendants("{http://www.w3.org/2000/svg}style").ToArray()[0].Nodes().OfType<System.Xml.Linq.XCData>().ToArray()[0].Value;
                //ExCSS.Parser parser = new ExCSS.Parser();

                //var styleSheet= parser.Parse(styleText);

                //var svgColorDefinitionStyle = (from styleRule in styleSheet.StyleRules
                //                            where styleRule.Value == ".st0"
                //                            select styleRule).FirstOrDefault();
                //var colorProperty = (from styleProperty in svgColorDefinitionStyle.Declarations.Properties
                //                     where styleProperty.Name== "fill"|| styleProperty.Name == "stroke"
                //                     select styleProperty).FirstOrDefault();
                //Color color = (Color) ColorConverter.ConvertFromString("#55260F");
                //colorProperty.Term = new ExCSS.HtmlColor(color.A, color.R, color.G, color.B);
                //svgDoc.Root.Descendants("{http://www.w3.org/2000/svg}style").ToArray()[0].Nodes().OfType<System.Xml.Linq.XCData>().ToArray()[0].Value = styleSheet.ToString();
                //svgDoc.Save(@"e:\mysvg.svg");
                //int eree = 0;


                //System.IO.DirectoryInfo dir = new DirectoryInfo(@"C:\ProgramData\Microneme\DontWaitWater\Fonts");
                //List<string> fontFaceLines = new List<string>();
                //foreach (var flieInfo in dir.GetFiles("*.ttf", SearchOption.AllDirectories))
                //{
                //    string cssFondFace = FontFaceLineBulder.GetFontFaceLine(flieInfo);
                //    if (cssFondFace != null)
                //    {
                //        fontFaceLines.Add(cssFondFace);
                //        System.Diagnostics.Debug.WriteLine(cssFondFace);
                //    }
                //}
                //System.IO.File.WriteAllLines(@"e:\Fonts.css", fontFaceLines.ToArray());


                //OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(DownloadStylesWindow.BordersStorage);

                //using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
                //{
                //    foreach (var image in (from theResource in storage.GetObjectCollection<MenuPresentationModel.MenuStyles.IImage>()
                //                           select theResource).ToList())
                //    {
                //        MenuPresentationModel.MenuStyles.PageImage pageImage = new MenuPresentationModel.MenuStyles.PageImage();

                //        pageImage.Name = image.Image.Name;
                //        pageImage.PortraitHeight = image.Width;
                //        pageImage.PortraitWidth = image.Height;
                //        pageImage.PortraitImage = image.Image;
                //        DownloadStylesWindow.BordersStorage.CommitTransientObjectState(pageImage);
                //    }
                //    stateTransition.Consistent = true;
                //}



                //foreach(var fInfo in dir.GetFiles())
                //{
                //    string fname= fInfo.Name;

                //    System.IO.File.Move(@"C:\ProgramData\Microneme\DontWaitWater\PageBorders\"+ fname, @"C:\ProgramData\Microneme\DontWaitWater\PageBorders\p_" + fname);
                //}
                //System.IO.File.Move("oldfilename", "newfilename");

                OOAdvantech.Remoting.RestApi.Authentication.InitializeFirebase("demomicroneme");

                var er = ModulePublisher.ClassRepository.TypeLoader;
                var ASS = System.Reflection.Assembly.Load("PersistenceLayerRunTime, Version = 4.0.0.0, Culture = neutral, PublicKeyToken = 95eeb2468d93212b");
                foreach (var _ref in ASS.GetReferencedAssemblies())
                {
                    var err = System.Reflection.Assembly.Load(_ref.FullName);
                    var sonss = err.GetTypes();
                }
                var types = ASS.GetTypes();
            }
            catch (ReflectionTypeLoadException ex)
            {
                StringBuilder sb = new StringBuilder();
                foreach (Exception exSub in ex.LoaderExceptions)
                {
                    sb.AppendLine(exSub.Message);
                    FileNotFoundException exFileNotFound = exSub as FileNotFoundException;
                    if (exFileNotFound != null)
                    {
                        if (!string.IsNullOrEmpty(exFileNotFound.FusionLog))
                        {
                            sb.AppendLine("Fusion Log:");
                            sb.AppendLine(exFileNotFound.FusionLog);
                        }
                    }
                    sb.AppendLine();
                }
                string errorMessage = sb.ToString();
                //Display or log the error based on your application.
            }
            StyleableWindow.FontDialog.InitFonts();
            List<string> mList = new List<string>() { "asd", "ASD" };
            int rt = mList.IndexOf(null);
            FrameworkElement.LanguageProperty.OverrideMetadata(
                                               typeof(FrameworkElement),
                                               new FrameworkPropertyMetadata(
                                                   XmlLanguage.GetLanguage(
                                                   CultureInfo.CurrentCulture.IetfLanguageTag)));


            EventManager.RegisterClassHandler(typeof(UIElement), Window.PreviewMouseDownEvent, new MouseButtonEventHandler(OnPreviewMouseDown));


            // CefSharp.Cef.Initialize();

            base.OnStartup(e);
            return;

            //824 1056
        }

        private string TransforWebJson(string JsonArgs)
        {
            JObject jArgs = JObject.Parse(JsonArgs);
            JObject jObject = new JObject();
            AddValuePrperties(jObject, jArgs.Properties());
            JsonArgs = jObject.ToString();
            return JsonArgs;
        }

        void Copy(string sourceDir, string targetDir)
        {
            Directory.CreateDirectory(targetDir);

            foreach (var file in Directory.GetFiles(sourceDir))
                File.Copy(file, Path.Combine(targetDir, Path.GetFileName(file)));

            foreach (var directory in Directory.GetDirectories(sourceDir))
                Copy(directory, Path.Combine(targetDir, Path.GetFileName(directory)));
        }
        static bool HelpMode = false;
        static void OnPreviewMouseDown(object sender, MouseButtonEventArgs e)
        {

            if (Views.SignInWindow.Current != null)
                Views.SignInWindow.Current.OnPreviewMouseDown(sender, e);

            UIElement uiElement = sender as UIElement;
            if (uiElement != null)
            {
                if (uiElement.Uid == "serma")
                {
                    if (HelpMode)
                        e.Handled = true;
                }
            }
        }

        public class CustomSearcher
        {
            public static List<string> GetDirectories(string path, string searchPattern = "*",
                SearchOption searchOption = SearchOption.TopDirectoryOnly)
            {
                if (searchOption == SearchOption.TopDirectoryOnly)
                    return Directory.GetDirectories(path, searchPattern).ToList();

                var directories = new List<string>(GetDirectories(path, searchPattern));

                for (var i = 0; i < directories.Count; i++)
                    directories.AddRange(GetDirectories(directories[i], searchPattern));

                return directories;
            }

            private static List<string> GetDirectories(string path, string searchPattern)
            {
                try
                {
                    return Directory.GetDirectories(path, searchPattern).ToList();
                }
                catch (UnauthorizedAccessException)
                {
                    return new List<string>();
                }
            }
        }

    }
    /// <MetaDataID>{413663dd-5f6b-4eed-8313-eece9de90988}</MetaDataID>
    class Temp
    {
        public string Name { get; set; } = "Lora";
        public decimal value { get; set; } = 4;

        public Type[] Types = new Type[] { typeof(int), typeof(double) };

        //public tmpVal Asan { get; set; } = new tmpVal();
        public IDictionary<string, object> Membber = new Dictionary<string, object>() { { "12", "Λιακος" }, { "13", (decimal)21088 }, { "14", new tmpVal() }, { "15", new List<string> { "Lora", "Nora" } } };
        public IList<object> MembberA = new List<object>() { "Λιακος", (decimal)21088, new tmpVal(), new Dictionary<int, string> { { 1, "sala" }, { 2, "karo" } } };
    }
    /// <MetaDataID>{59e864b0-da72-48c4-9b00-ee233ec3223b}</MetaDataID>
    class tmpVal
    {
        public int age { get; set; } = 3;
    }

    /// <MetaDataID>{2bcdc48e-ee9e-48ba-93bc-1777df053c8c}</MetaDataID>
    public class StorageLocatorEx : OOAdvantech.PersistenceLayer.IStorageLocatorEx
    {
        public OOAdvantech.MetaDataRepository.StorageMetaData GetSorageMetaData(string storageIdentity)
        {
            System.Net.Http.HttpClient httpClient = new System.Net.Http.HttpClient();
            string serverUrl = OOAdvantech.Remoting.RestApi.RemotingServices.ServerPublicUrl.Substring(0, OOAdvantech.Remoting.RestApi.RemotingServices.ServerPublicUrl.IndexOf("/api"));
            OOAdvantech.PersistenceLayer.StoragesClient storagesClient = new OOAdvantech.PersistenceLayer.StoragesClient(httpClient);

            storagesClient.BaseUrl = serverUrl;
            var task = storagesClient.GetAsync(storageIdentity);
            if (task.Wait(TimeSpan.FromSeconds(2)))
                return task.Result;
            else
                return new OOAdvantech.MetaDataRepository.StorageMetaData();
        }
    }
}
