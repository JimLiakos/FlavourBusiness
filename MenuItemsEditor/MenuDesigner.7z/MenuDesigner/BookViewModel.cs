﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using MenuPresentationModel;
using OOAdvantech.Transactions;

namespace MenuDesigner
{
    /// <MetaDataID>{fe45389d-e764-41a0-9cf1-c6476ffe25d2}</MetaDataID>
    public class BookViewModel : OOAdvantech.UserInterface.Runtime.PresentationObject<MenuPresentationModel.RestaurantMenu>, INotifyPropertyChanged
    {
        public BookViewModel():base(default(MenuPresentationModel.RestaurantMenu))
        {

        }
        public BookViewModel(MenuPresentationModel.RestaurantMenu menu)
            : base(menu)
        {
            if (MenuPresentationModel.MenuStyles.StyleSheet.StyleSheets.Count > 0)
                SelectedMenuStyle = MenuPresentationModel.MenuStyles.StyleSheet.StyleSheets[0];
                
            //Enum.GetValues(AbstractionsAndPersistency.OrderState)

        }
        public List<MenuPresentationModel.MenuStyles.IStyleSheet> MenuStyles
        {

            get
            {
                return MenuPresentationModel.MenuStyles.StyleSheet.StyleSheets;
            }
        }

        public BookViewModel(RestaurantMenu menu, XDocument restaurantMenuDoc) : this(menu)
        {
            this.RestaurantMenuDoc = restaurantMenuDoc;
        }
        public RestaurantMenu RestaurantMenu
        {
            get
            {
                return RealObject;
            }
        }

        public List<MenuModel.IMenuItem> MenuItems
        {
            get
            {
                if (RealObject == null)
                    return new List<MenuModel.IMenuItem>();
                return new List<MenuModel.IMenuItem>()
                {
                    new MenuModel.MenuItem() { Name = "Traxanas" },
                    new MenuModel.MenuItem() { Name = "Xilopites"},
                    new MenuModel.MenuItem() { Name = "Makaronia"},
                    new MenuModel.MenuItem() { Name = "Kotopoulo"},
                };
            }

        }
        public void Expander_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {

        }

        /// <exclude>Excluded</exclude>
        List<BookPageViewModel> _Pages;
        private XDocument RestaurantMenuDoc;

        /// <MetaDataID>{4a875097-2293-464d-be4d-dd45107e1543}</MetaDataID>
        public List<BookPageViewModel> Pages
        {
            get
            {
                if (_Pages == null)
                    _Pages = (from menuPage in RealObject.Pages select new BookPageViewModel(menuPage,this)).ToList();
                else
                {
                    var menuPageMap = (from bookPage in _Pages select bookPage).ToDictionary(bookPage => bookPage.MenuPage);
                    _Pages.Clear();
                    foreach (var menuPage in RealObject.Pages)
                    {
                        BookPageViewModel bookPageViewModel = null;
                        if (menuPageMap.TryGetValue(menuPage, out bookPageViewModel))
                            _Pages.Add(bookPageViewModel);
                        else
                            _Pages.Add(new BookPageViewModel(menuPage));
                    }
                }
                return _Pages;
            }
        }
        /// <exclude>Excluded</exclude>
        BookPageViewModel _SeletedPage;
        public BookPageViewModel SeletedPage
        {
            get
            {
                return _SeletedPage;
            }
            set
            {
                _SeletedPage = value;
            }
        }

        MenuPresentationModel.MenuStyles.IStyleSheet _SelectedMenuStyle;
        public MenuPresentationModel.MenuStyles.IStyleSheet SelectedMenuStyle
        {
            get
            {
                return _SelectedMenuStyle;
            }
            set
            {
                _SelectedMenuStyle = value;

                UpdateMenuPagesStyle();

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuStyle)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedStyleName)));
            }
        }

        private void UpdateMenuPagesStyle()
        {
            foreach(var page in Pages)
                page.MenuPage.Style = SelectedMenuStyle;
        }

        public string SelectedStyleName
        {
            get
            {
                if (_SelectedMenuStyle != null)
                    return _SelectedMenuStyle.Name;
                else
                    return "none";
            }
        }

        /// <MetaDataID>{a3bb9949-2a2a-4546-822b-5eeb01ee5d45}</MetaDataID>
        internal void AddPageAfter(BookPageViewModel page)
        {


            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
            {
                int pageIndex = RestaurantMenu.Pages.IndexOf(page.MenuPage);
                var menuPage = new MenuPage();
                var objectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(RestaurantMenu);
                objectStorage.CommitTransientObjectState(menuPage);
                RestaurantMenu.InsertPage(pageIndex, menuPage);
                stateTransition.Consistent = true;
            }
            UpdateMenuPagesStyle();

            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("Pages"));

        }

        public event PropertyChangedEventHandler PropertyChanged;

        /// <MetaDataID>{9496b7e3-63ea-41be-b3e7-6ea2fdf7a4f5}</MetaDataID>
        internal void MoveSelectedPageLeft(BookPageViewModel page)
        {


            if (RestaurantMenu.Pages.IndexOf(page.MenuPage) > 0)
            {
                int index = RestaurantMenu.Pages.IndexOf(page.MenuPage);

                RestaurantMenu.MovePage(index - 1, page.MenuPage);

                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Pages"));

            }

        }

        /// <MetaDataID>{28afd124-eb12-4ab2-ad20-a960f1370da1}</MetaDataID>
        internal void LoadMenu(System.Xml.Linq.XElement menu)
        {
            //_Pages = new ObservableCollection<BookPageViewModel>((from pageXml in menu.Element("MenuPages").Elements("Page")
            //          select new BookPageViewModel(pageXml)).ToList());

            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("Pages"));
        }

        static internal BookViewModel NewMenu(XDocument restaurantMenuDoc)
        {


            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
            {
                try
                {

                     
 
                    OOAdvantech.PersistenceLayer.ObjectStorage objectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.NewStorage("RestMenu", restaurantMenuDoc, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider");
                    MenuPresentationModel.RestaurantMenu restaurantMenu = new MenuPresentationModel.RestaurantMenu();
                    restaurantMenu.Name = "IMenu";


                    objectStorage.CommitTransientObjectState(restaurantMenu);
                    MenuPresentationModel.MenuPage firstPage = new MenuPage();
                    objectStorage.CommitTransientObjectState(firstPage);
                    restaurantMenu.AddPage(firstPage);

                    MenuPresentationModel.MenuCanvas.FoodItemsHeading titleHeading = new MenuPresentationModel.MenuCanvas.FoodItemsHeading();
                    objectStorage.CommitTransientObjectState(titleHeading);
                    titleHeading.Description = "Gatsby's";
                    titleHeading.HeadingType = MenuPresentationModel.MenuCanvas.HeadingType.Title;
                    firstPage.AddMenuItem(titleHeading);

                    MenuPresentationModel.MenuCanvas.FoodItemsHeading heading = new MenuPresentationModel.MenuCanvas.FoodItemsHeading();
                    objectStorage.CommitTransientObjectState(heading);
                    heading.Description = "Appetizers";
                    firstPage.AddMenuItem(heading);
                    
                    //firstPage.


                    return new BookViewModel(restaurantMenu, restaurantMenuDoc);
                }
                finally
                {
                    stateTransition.Consistent = true;
                }

            }


        }

        static internal BookViewModel OpenMenu(XDocument restaurantMenuDoc)
        {

            OOAdvantech.Linq.Storage  storage = new OOAdvantech.Linq.Storage( OOAdvantech.PersistenceLayer.ObjectStorage.OpenStorage("RestMenu", restaurantMenuDoc, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider"));

            MenuPresentationModel.RestaurantMenu restaurantMenu = (from menu in storage.GetObjectCollection<MenuPresentationModel.RestaurantMenu>()
                                                                   select menu).FirstOrDefault();
            return new BookViewModel(restaurantMenu, restaurantMenuDoc); 
        }


    }
}
