﻿using System.Windows;
using System.Windows.Controls;

namespace MenuDesigner
{
    // Implements ItemsControl for ToolboxItems    
    /// <MetaDataID>{9ce80383-bb15-4f1b-b6d9-00b08b8dd2f0}</MetaDataID>
    public class Toolbox : ItemsControl
    {
        // Defines the ItemHeight and ItemWidth properties of
        // the WrapPanel used for this Toolbox
        /// <MetaDataID>{921fddef-212a-4d0f-a28e-be5ca4d0be35}</MetaDataID>
        public Size ItemSize
        {
            get { return itemSize; }
            set { itemSize = value; }
        }
        /// <MetaDataID>{55c5118c-f5d7-4ef1-957e-cdd17c971386}</MetaDataID>
        private Size itemSize = new Size(50, 50);

        // Creates or identifies the element that is used to display the given item.        
        /// <MetaDataID>{741c85a4-9d64-4a7f-85a2-4aef154048af}</MetaDataID>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new ToolboxItem();
        }

        // Determines if the specified item is (or is eligible to be) its own container.        
        /// <MetaDataID>{4ba5803e-7386-454e-b127-b40df22f35ea}</MetaDataID>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return (item is ToolboxItem);
        }
    }
}
