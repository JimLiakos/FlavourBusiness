﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MenuDesigner
{
    /// <MetaDataID>{9f141d93-9f23-469c-9b6a-78413ae3fa2d}</MetaDataID>
    public class MenuItemsCollection:List<MenuModel.MenuItem> 
    {

    }
}
