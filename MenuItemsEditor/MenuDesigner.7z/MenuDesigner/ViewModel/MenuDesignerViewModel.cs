﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using FloorLayoutDesigner.ViewModel;
using MenuDesigner.Properties;
using OOAdvantech.Transactions;
using RestaurantHallLayoutModel;
using WPFUIElementObjectBind;

namespace MenuDesigner.ViewModel
{



    /// <MetaDataID>{9754d9d6-effc-4d7b-8aef-53d891afe61b}</MetaDataID>
    public class FlavourBusinessManagerViewModel : MarshalByRefObject, INotifyPropertyChanged
    {


        public RelayCommand DeleteCommand { get; protected set; }

        public RelayCommand Group { get; protected set; }
        public RelayCommand Ungroup { get; protected set; }
        public RelayCommand BringForward { get; protected set; }
        public RelayCommand BringToFront { get; protected set; }
        public RelayCommand SendBackward { get; protected set; }
        public RelayCommand SendToBack { get; protected set; }
        public RelayCommand AlignTop { get; protected set; }
        public RelayCommand AlignVerticalCenters { get; protected set; }
        public RelayCommand AlignBottom { get; protected set; }
        public RelayCommand AlignLeft { get; protected set; }
        public RelayCommand AlignHorizontalCenters { get; protected set; }
        public RelayCommand AlignRight { get; protected set; }
        public RelayCommand DistributeHorizontal { get; protected set; }
        public RelayCommand DistributeVertical { get; protected set; }
        public RelayCommand SelectAll { get; protected set; }
        public RelayCommand MoveToNextPage { get; protected set; }
        public RelayCommand MoveToPreviousPage { get; protected set; }
        public RelayCommand ShrinkLineSpace { get; protected set; }
        public RelayCommand ExpandLineSpace { get; protected set; }
        public RelayCommand ResetLineSpace { get; protected set; }
        public RelayCommand ShrinkPageFontsSizes { get; protected set; }
        public RelayCommand ExpandPageFontsSizes { get; protected set; }
        public RelayCommand ResetPageFontsSizes { get; protected set; }
        public RelayCommand TitleHeadingFonts { get; protected set; }
        public RelayCommand NormalHeadingFonts { get; protected set; }
        public RelayCommand SubHeadingFonts { get; protected set; }
        public RelayCommand DownloadStyleSheet { get; protected set; }
        public RelayCommand SignInSignUp { get; protected set; }
        public RelayCommand FoodItemNameFonts { get; protected set; }
        public RelayCommand FoodItemDescriptionFonts { get; protected set; }
        public RelayCommand FoodItemExtrasFonts { get; protected set; }
        public RelayCommand FoodItemPriceFonts { get; protected set; }
        public RelayCommand LayoutOptions { get; protected set; }
        public RelayCommand BorderSelection { get; protected set; }
        public RelayCommand BackgroundSelection { get; protected set; }
        public RelayCommand HeadingTypesAccents { get; protected set; }
        public RelayCommand StyleSelection { get; protected set; }

        public RelayCommand SameWidth { get; protected set; }
        public RelayCommand SameHeight { get; protected set; }
        public RelayCommand SameSize { get; protected set; }
        public RelayCommand Rotate { get; protected set; }

        public RelayCommand Undo { get; protected set; }

        public RelayCommand Redo { get; protected set; }


        public RelayCommand HallLayoutShapeLabelFont { get; protected set; }

        public bool RotatePopupIsOpen { get; protected set; }


        //private void AlignBottom_Executed(object sender, ExecutedRoutedEventArgs e)
        //{
        //    if (SelectionDesignerCanvas != null)
        //        SelectionDesignerCanvas.AlignBottom_Executed(sender, e);
        //}

        public static FlavourBusinessManagerViewModel Current;
        public FlavourBusinessManagerViewModel()
        {

            _SignInUserPopup = new SignInUserPopupViewModel(this);
            _SignInUserPopup.SignedIn += SignInUserPopup_SignedIn;
            _SignInUserPopup.SignedOut += SignInUserPopup_SignedOut;
            Current = this;
            InitCommands();


        }

        public FloorLayoutDesigner.DesignerCanvas HallLayoutCanvas
        {
            get
            {
                FloorLayoutDesigner.DesignerCanvas designerCanvas = null;
                if (Rotate.UserInterfaceObjectConnection != null)
                    designerCanvas = (Window.GetWindow(Rotate.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas;
                if (designerCanvas != null)
                    return designerCanvas;
                else
                    return null;
            }
        }

        public int RotationDeegrees
        {
            get
            {
                FloorLayoutDesigner.DesignerCanvas designerCanvas = null;
                if (Rotate.UserInterfaceObjectConnection != null)
                    designerCanvas = (Window.GetWindow(Rotate.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas;
                if (designerCanvas != null && designerCanvas.SelectedShape != null)
                    return designerCanvas.SelectedShape.RotationDeegrees;
                else
                    return 0;
            }
            set
            {
                FloorLayoutDesigner.DesignerCanvas designerCanvas = null;
                if (Rotate.UserInterfaceObjectConnection != null)
                    designerCanvas = (Window.GetWindow(Rotate.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas;
                if (designerCanvas != null && designerCanvas.SelectedShape != null)
                    designerCanvas.SelectedShape.RotationDeegrees = value;
            }
        }


        private void InitCommands()
        {

            AlignLeft = new RelayCommand((object sender) => (Window.GetWindow(AlignLeft.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.AlignLeft_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);


            AlignRight = new RelayCommand((object sender) => (Window.GetWindow(AlignRight.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.AlignRight_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

            AlignTop = new RelayCommand((object sender) => (Window.GetWindow(AlignTop.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.AlignTop_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

            AlignBottom = new RelayCommand((object sender) => (Window.GetWindow(AlignBottom.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.AlignBottom_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

            AlignHorizontalCenters = new RelayCommand((object sender) => (Window.GetWindow(AlignHorizontalCenters.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.AlignHorizontalCenters_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

            AlignVerticalCenters = new RelayCommand((object sender) => (Window.GetWindow(AlignVerticalCenters.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.AlignVerticalCenters_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

            DistributeHorizontal = new RelayCommand((object sender) => (Window.GetWindow(DistributeHorizontal.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.DistributeHorizontal_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

            DistributeVertical = new RelayCommand((object sender) => (Window.GetWindow(DistributeVertical.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.DistributeVertical_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);


            SameWidth = new RelayCommand((object sender) => (Window.GetWindow(AlignTop.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.SameWidth_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

            SameHeight = new RelayCommand((object sender) => (Window.GetWindow(AlignTop.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.SameHeight_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

            SameSize = new RelayCommand((object sender) => (Window.GetWindow(AlignTop.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.SameSize_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);


            HallLayoutShapeLabelFont = new RelayCommand((object sender) =>
             {

                 var win = Window.GetWindow(AlignTop.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow;

                 var hallLayoutPresentation = win.DesignerHost.GetDataContextObject<HallLayoutViewModel>();


                 using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
                 {
                     StyleableWindow.FontDialog fontDialog = new StyleableWindow.FontDialog();
                     //hallLayoutPresentation.
                     //new FontPresantation() { Font = menuItemStyle.Font }


                     fontDialog.GetObjectContext().SetContextInstance(hallLayoutPresentation.FontPresantation);
                     //// fontDialog.Font = (book.EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle).Font;
                     fontDialog.Owner = win;
                     if (fontDialog.ShowDialog().Value)
                         stateTransition.Consistent = true;
                 }



             });//, (object sesnder) => HallLayoutIsVisible );



            Rotate = new RelayCommand((object sender) =>
            {

                RotatePopupIsOpen = true;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(RotatePopupIsOpen)));

            }, (object sesnder) => HallLayoutIsVisible && (Window.GetWindow(Rotate.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.SelectedShape != null);


            Undo = new RelayCommand((object sender) => (Window.GetWindow(AlignTop.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.Undo_Executed(sender, null),
                (object sender) => HallLayoutIsVisible && (Window.GetWindow(Ungroup.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.Undo_Enabled(sender));


            Redo = new RelayCommand((object sender) => (Window.GetWindow(AlignTop.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.Redo_Executed(sender, null),
                (object sender) => HallLayoutIsVisible && (Window.GetWindow(Ungroup.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.Redo_Enabled(sender));



            Group = new RelayCommand((object sender) => (Window.GetWindow(Group.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.Group_Executed(sender, null),
              (object sender) => HallLayoutIsVisible && (Window.GetWindow(Group.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.Group_CanExecute(sender));

            Ungroup = new RelayCommand((object sender) => (Window.GetWindow(Ungroup.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.Ungroup_Executed(sender, null),
            (object sender) => HallLayoutIsVisible && (Window.GetWindow(Ungroup.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.Ungroup_CanExecute(sender));

            SendToBack = new RelayCommand((object sender) => (Window.GetWindow(DistributeVertical.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.SendToBack_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

            BringToFront = new RelayCommand((object sender) => (Window.GetWindow(DistributeVertical.UserInterfaceObjectConnection.ContainerControl as DependencyObject) as MainWindow).DesignerHost.Canvas.BringToFront_Executed(sender, null), (object sesnder) => HallLayoutIsVisible);

        }

        string _DesignAreaHeader = Resources.GraphicMenuTitle;
        public string DesignAreaHeader
        {
            get
            {
                return _DesignAreaHeader;
            }
            set
            {
                _DesignAreaHeader = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DesignAreaHeader)));
            }
        }

        FloorLayoutDesigner.ViewModel.HallLayoutViewModel _HallLayout;
        public FloorLayoutDesigner.ViewModel.HallLayoutViewModel HallLayout
        {
            get
            {
                return _HallLayout;
            }
            set
            {
                if (HallLayout != value)
                {
                    if (_HallLayout != null)
                        _HallLayout.PropertyChanged -= HallLayout_PropertyChanged;
                    _HallLayout = value;
                    if (_HallLayout != null)
                    {
                        _HallLayout.PropertyChanged += HallLayout_PropertyChanged;
                        DesignAreaHeader = _HallLayout.HallLayout.Name;
                    }
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayout)));
                }
            }
        }
        internal void ShowHallLayout(HallLayout restaurantHallLayout)
        {
            var mainWindow = System.Windows.Window.GetWindow(AlignLeft.UserInterfaceObjectConnection.ContainerControl as System.Windows.DependencyObject) as MainWindow;
            (AlignLeft.UserInterfaceObjectConnection.ContainerControl as System.Windows.FrameworkElement).GetObjectContext().RunUnderContextTransaction(new Action(() =>
            {
                if (restaurantHallLayout == null)
                    HallLayout = null;
                if (HallLayout == null || HallLayout.HallLayout != restaurantHallLayout)
                    HallLayout = new FloorLayoutDesigner.ViewModel.HallLayoutViewModel(restaurantHallLayout);

                HallLayoutVisibility = Visibility.Visible;
                MenuDesignerVisibility = Visibility.Hidden;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutCanvas)));
            }));
        }

        System.Windows.Visibility _MenuDesignerVisibility = System.Windows.Visibility.Visible;
        public System.Windows.Visibility MenuDesignerVisibility
        {
            get
            {
                return _MenuDesignerVisibility;
            }
            set
            {
                _MenuDesignerVisibility = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MenuDesignerVisibility)));
            }
        }

        public bool MenuDesignerIsVisible
        {
            get
            {
                return _MenuDesignerVisibility == Visibility.Visible;
            }
        }


        System.Windows.Visibility _HallLayoutVisibility = System.Windows.Visibility.Collapsed;
        public System.Windows.Visibility HallLayoutVisibility
        {
            get
            {
                return _HallLayoutVisibility;
            }
            set
            {
                _HallLayoutVisibility = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HallLayoutVisibility)));
            }
        }

        bool HallLayoutIsVisible
        {
            get
            {
                return _HallLayoutVisibility == System.Windows.Visibility.Visible;
            }
        }

        /// <exclude>Excluded</exclude>
        RestaurantMenuItemsPresentation _MenuData;
        public RestaurantMenuItemsPresentation MenuData
        {
            get
            {
                try
                {
                    //if (_MenuData == null)
                    //    _MenuData = new RestaurantMenuItemsPresentation((BookViewModel.RestaurantMenus.Members[0] as MenuItemsEditor.ViewModel.MenuViewModel).Menu, null);

                    return _MenuData;
                }
                catch (Exception error)
                {
                    throw;
                }
            }
            set
            {
                _MenuData = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MenuData)));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;

        /// <exclude>Excluded</exclude>
        BookViewModel _Menu;
        public BookViewModel Menu
        {
            get
            {
                return _Menu;
            }
            set
            {
                if (_Menu != value)
                {
                    if (_Menu != null)
                        _Menu.PropertyChanged -= Menu_PropertyChanged;

                    _Menu = value;
                    if (_Menu != null)
                        _Menu.PropertyChanged += Menu_PropertyChanged;


                    if (_Menu != null)
                        _MenuData.GraphicMenu = value.RealObject;
                    else
                        _MenuData.GraphicMenu = null;

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Menu)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentageLabel)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentage)));
                }

            }
        }

        private void Menu_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ZoomPercentage))
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentageLabel)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentage)));
            }

        }

        private void HallLayout_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ZoomPercentage))
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentageLabel)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentage)));
            }

        }

        public double ZoomPercentage
        {
            get
            {
                if (Menu != null && MenuDesignerIsVisible)
                    return Menu.ZoomPercentage;

                if (HallLayout != null && HallLayoutIsVisible)
                    return HallLayout.ZoomPercentage;

                return 0;
            }
            set
            {
                if (Menu != null && MenuDesignerIsVisible)
                    Menu.ZoomPercentage = value;

                if (HallLayout != null && HallLayoutIsVisible)
                    HallLayout.ZoomPercentage = value;

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentageLabel)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentage)));

            }
        }
        public string ZoomPercentageLabel
        {
            get
            {
                return ZoomPercentage.ToString("N2") + "%";
            }
        }


        /// <exclude>Excluded</exclude>
        SignInUserPopupViewModel _SignInUserPopup;
        public SignInUserPopupViewModel SignInUser
        {
            get
            {
                return _SignInUserPopup;
            }
            set
            {
                if (_SignInUserPopup != null)
                    _SignInUserPopup.SignedIn -= SignInUserPopup_SignedIn;
                _SignInUserPopup = value;

                if (_SignInUserPopup != null)
                    _SignInUserPopup.SignedIn += SignInUserPopup_SignedIn;
            }
        }

        private void SignInUserPopup_SignedIn(object sender, EventArgs e)
        {
            _BusinessResources = new FlavourBusinessResourcesPresentation(FlavourBusinessManager.Organization.CurrentOrganization, GraphicMenus);

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(BusinessResources)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Menu)));
        }

        private void SignInUserPopup_SignedOut(object sender, EventArgs e)
        {
            _BusinessResources?.SignOut();
            _BusinessResources = null;// new FlavourBusinessResourcesPresentation(FlavourBusinessManager.Organization.CurrentOrganization);

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(BusinessResources)));
        }
        GraphicMenusPresentation _GraphicMenus;
        public GraphicMenusPresentation GraphicMenus
        {
            get
            {

                if (_GraphicMenus == null && SignInUser.GraphicMenus != null)
                    _GraphicMenus = new GraphicMenusPresentation(SignInUser.GraphicMenus);

                return _GraphicMenus;
            }
        }


        FlavourBusinessResourcesPresentation _BusinessResources;
        public FlavourBusinessResourcesPresentation BusinessResources
        {
            get
            {
                //tax authority
                return _BusinessResources;
            }
        }

        public List<CultureInfo> Cultures
        {
            get
            {
                
                return CultureInfo.GetCultures(CultureTypes.AllCultures).ToList();
            }
        }

        public CultureInfo SelectedCulture
        {
            get
            {
                return OOAdvantech.CultureContext.CurrentCultureInfo;
            }
            set
            {
                OOAdvantech.CultureContext.CurrentCultureInfo=value;
            }
        }

    }
}
