﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using FlavourBusinessFacade;
using WPFUIElementObjectBind;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{ad48a862-f965-49f9-85c4-013d7583888d}</MetaDataID>
    public class MenusTreeNode :  FBResourceTreeNode
    {

        CompanyPresentation Company;

        Dictionary<string, GraphicMenuTreeNode> GraphicMenus = new Dictionary<string, GraphicMenuTreeNode>();

   
        public MenusTreeNode(CompanyPresentation company):base(company)
        {
            Company = company;
            foreach (var graphicMenu in Company.GraphicMenus)
                GraphicMenus[graphicMenu.StorageIdentity] = new GraphicMenuTreeNode(graphicMenu,this);
        }

        FlavoursServicesContextPresentation ServicesContext;
        public MenusTreeNode(FlavoursServicesContextPresentation servicesContext) : base(servicesContext)
        {
            ServicesContext = servicesContext;

            GraphicMenus = ServicesContext.GraphicMenus;

        }

        
        public override List<MenuComamnd> ContextMenuItems
        {
            get
            {
                return new List<MenuComamnd>();
            }
        }

     





        public override List<FBResourceTreeNode> Members
        {
            get
            {

                return this.GraphicMenus.Values.OfType<FBResourceTreeNode>().ToList();


            }
        }

        public override string Name
        {
            get
            {
                if(ServicesContext!=null)
                    return ServicesContext.Name+ " " + Properties.Resources.GraphicMenusTitle;
                else
                    return  Properties.Resources.GraphicMenusTitle;
            }

            set
            {
            
            }
        }


        public override List<MenuComamnd> SelectedItemContextMenuItems
        {
            get
            {
                if (IsSelected)
                    return null;
                else
                    foreach (var treeNode in Members)
                    {
                        var contextMenuItems = treeNode.SelectedItemContextMenuItems;
                        if (contextMenuItems != null)
                            return contextMenuItems;
                    }

                return null;
            }
        }

        public override ImageSource TreeImage
        {
            get
            {
                return new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/menusfolder.png"));
                //
            }
        }

        public override void SelectionChange()
        {
        }
    }
}
