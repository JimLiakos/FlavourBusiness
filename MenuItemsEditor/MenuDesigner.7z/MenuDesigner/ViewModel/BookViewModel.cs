﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using MenuPresentationModel;
using OOAdvantech.Transactions;
using OOAdvantech.PersistenceLayer;
using MenuPresentationModel.MenuCanvas;
using FlavourBusinessToolKit;

namespace MenuDesigner.ViewModel
{



    /// <MetaDataID>{fe45389d-e764-41a0-9cf1-c6476ffe25d2}</MetaDataID>
    public class BookViewModel : OOAdvantech.UserInterface.Runtime.PresentationObject<MenuPresentationModel.RestaurantMenu>, INotifyPropertyChanged
    {
        public BookViewModel() : base(default(MenuPresentationModel.RestaurantMenu))
        {
        }
        public BookViewModel(MenuPresentationModel.RestaurantMenu menu)
            : base(menu)
        {
            if (menu.Style != null)
            {
                var style = menu.Style;

                MenuStylesheet = style as MenuPresentationModel.MenuStyles.StyleSheet;
                RestaurantMenu.ConntextStyleSheet = MenuStylesheet;
                _SelectedMenuStyle = MenuStylesheet.OrgStyleSheet;

                if (MenuStylesheet != null && MenuStylesheet.Styles.ContainsKey("page"))
                    (MenuStylesheet.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle).PropertyChanged += PageStyle_PropertyChanged;
                if (MenuStylesheet != null && MenuStylesheet.Styles.ContainsKey("menu-item"))
                    (MenuStylesheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.MenuItemStyle).ObjectChangeState += MenuItemStyle_PropertyChanged;


                if (MenuStylesheet != null && MenuStylesheet.Styles.ContainsKey("layout"))
                    (MenuStylesheet.Styles["layout"] as MenuPresentationModel.MenuStyles.LayoutStyle).PropertyChanged += LayoutStyle_PropertyChanged;
                if (MenuStylesheet != null && MenuStylesheet.Styles.ContainsKey("price-options"))
                    (MenuStylesheet.Styles["price-options"] as MenuPresentationModel.MenuStyles.PriceStyle).ObjectChangeState += BookViewModel_PropertyChanged;


                RebuildAllPages();
                //foreach (var page in Pages)
                //    page.Refresh();
            }
            else
            {
                if (MenuPresentationModel.MenuStyles.StyleSheet.StyleSheets.Count > 0)
                    SelectedMenuStyle = MenuPresentationModel.MenuStyles.StyleSheet.StyleSheets[0];

            }
            menu.MenuCanvasItemChanged += MenuCanvasItemChanged;
            menu.ObjectChangeState += RestaurantMenuChangeState;
            //Enum.GetValues(AbstractionsAndPersistency.OrderState)

        }

        private void BookViewModel_ObjectChangeState(object _object, string member)
        {
            throw new NotImplementedException();
        }

        internal void RemoveMenuCanvasItem(IMenuCanvasItem menuCanvasItem, BookPageViewModel bookPageViewModel)
        {

            bookPageViewModel.MenuPage.RemoveMenuItem(menuCanvasItem);
            RestaurantMenu.RemoveMenuItem(menuCanvasItem);
            RebuildPageAndAllToTherRight(bookPageViewModel);
        }



        public BookViewModel(RestaurantMenu menu, RawStorageData restaurantMenuDoc) : this(menu)
        {
            this.RestaurantMenuDoc = restaurantMenuDoc.RawData as XDocument;// restaurantMenuDoc;
        }


        /// <exclude>Excluded</exclude>
        MenuHeadingsPresentation _MenuHeadings;
        public MenuHeadingsPresentation MenuHeadings
        {
            get
            {
                if (_MenuHeadings == null )
                    _MenuHeadings = new MenuHeadingsPresentation(RealObject);
                return _MenuHeadings;
            }
        }




        /// <summary>
        /// Informs restaurant menu viewmodel that a item has change its position on page
        /// </summary>
        /// <param name="bookPageViewModel">
        /// Defines the page where item is
        /// </param>
        internal void MenuItemMoveOnPage(BookPageViewModel bookPageViewModel)
        {
            RebuildPageAndAllToTherRight(bookPageViewModel);
        }

        private void RebuildPage(BookPageViewModel bookPageViewModel)
        {
            var menuCanvasItems = bookPageViewModel.MenuPage.MenuCanvasItems.ToList();
            bookPageViewModel.MenuPage.RenderMenuCanvasItems(menuCanvasItems);
            if (SeletedPage == bookPageViewModel)
                bookPageViewModel.UpdateCanvasItems();
        }

        private void RebuildPageAndAllToTherRight(BookPageViewModel bookPageViewModel)
        {
            List<IMenuCanvasItem> menuCanvasItems = new List<IMenuCanvasItem>();// bookPageViewModel.MenuPage.MenuCanvasItems.ToList();
            var allPages = AllPages;
            int npos = AllPages.IndexOf(bookPageViewModel);
            for (; npos < allPages.Count; npos++)
                menuCanvasItems.AddRange(allPages[npos].MenuPage.MenuCanvasItems);

            npos = AllPages.IndexOf(bookPageViewModel);
            for (; npos < allPages.Count; npos++)
            {
                int numOfPageMenuCanvasItems = allPages[npos].MenuPage.MenuCanvasItems.Count;
                if (menuCanvasItems.Count == 0)
                {
                    RestaurantMenu.RemovePage(allPages[npos].MenuPage);
                    // RestaurantMenu.ReBuildMenuPages();
                }
                else
                {
                    allPages[npos].MenuPage.RenderMenuCanvasItems(menuCanvasItems);
                    if (allPages[npos].MenuPage.MenuCanvasItems.Count == numOfPageMenuCanvasItems)
                        break;

                    while (npos == allPages.Count - 1 && menuCanvasItems.Count > 0)
                    {
                        var objectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(RestaurantMenu);
                        MenuPresentationModel.MenuPage newPage = new MenuPage();
                        objectStorage.CommitTransientObjectState(newPage);
                        RestaurantMenu.AddPage(newPage);
                        newPage.RenderMenuCanvasItems(menuCanvasItems);

                    }
                }
            }
            RestaurantMenu.RemoveBlankPages();
            if (SeletedPage == bookPageViewModel)
                bookPageViewModel.UpdateCanvasItems();
        }

        private void RebuildAllPages()
        {
            Transaction.ExecuteAsynch(new Action(() =>
             {
                 try
                 {
                     lock (this)
                     {
                         var menuCanvasItems = RestaurantMenu.MenuCanvasItems.ToList();
                         var itemsMultiplePriceHeadings = (from MenuCanvasFoodItem foodItem in menuCanvasItems.OfType<MenuCanvasFoodItem>()
                                                           where foodItem.MultiPriceHeading != null
                                                           select foodItem.MultiPriceHeading).Distinct().ToList();
                         //foreach (var itemMultiplePriceHeading in itemsMultiplePriceHeadings)
                         //    itemMultiplePriceHeading.ObjectChangeState -= MultiplePriceHeadingsChangeState;


                         menuCanvasItems.AddRange(itemsMultiplePriceHeadings);
                         List<MenuPage> allPages = RestaurantMenu.Pages.OfType<MenuPage>().ToList();
                         List<MenuPage> selectedPageAndAllToTheLeft = new List<MenuPage>();

                         foreach (var page in RestaurantMenu.Pages.OfType<MenuPage>())
                         {
                             selectedPageAndAllToTheLeft.Add(page);
                             allPages.Remove(page);
                             if (SeletedPage.MenuPage == page)
                                 break;
                         }
                         foreach (var page in selectedPageAndAllToTheLeft)
                             page.RenderMenuCanvasItems(menuCanvasItems);

                         if (SeletedPage.MenuPage.MenuCanvasItems.Count == 0 && RestaurantMenu.Pages.IndexOf(SeletedPage.MenuPage) != 0)
                             SeletedPage = AllPages[AllPages.IndexOf(SeletedPage) - 1];

                         foreach (var page in Pages)
                             page.UpdateCanvasItems();


                         while (menuCanvasItems.Count > 0)
                         {
                             if (allPages.Count == 0)
                             {
                                 var objectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(RestaurantMenu);
                                 MenuPresentationModel.MenuPage newPage = new MenuPage();
                                 objectStorage.CommitTransientObjectState(newPage);
                                 RestaurantMenu.AddPage(newPage);
                                 newPage.RenderMenuCanvasItems(menuCanvasItems);
                             }
                             else
                             {
                                 foreach (var page in allPages)
                                 {
                                     if (page.Menu != null)
                                         page.RenderMenuCanvasItems(menuCanvasItems);
                                     else
                                     {

                                     }
                                 }
                             }
                         }
                         RestaurantMenu.RemoveBlankPages();

                         foreach (var itemMultiplePriceHeading in itemsMultiplePriceHeadings)
                             itemMultiplePriceHeading.ObjectChangeState -= MultiplePriceHeadingsChangeState;

                         itemsMultiplePriceHeadings = (from MenuCanvasFoodItem foodItem in RestaurantMenu.MenuCanvasItems.OfType<MenuCanvasFoodItem>()
                                                       where foodItem.MultiPriceHeading != null
                                                       select foodItem.MultiPriceHeading).Distinct().ToList();
                         foreach (var itemMultiplePriceHeading in itemsMultiplePriceHeadings)
                         {
                             itemMultiplePriceHeading.ObjectChangeState -= MultiplePriceHeadingsChangeState;
                             itemMultiplePriceHeading.ObjectChangeState += MultiplePriceHeadingsChangeState;
                         }

                     }
                 }
                 catch (OOAdvantech.Transactions.TransactionException error)
                 {

                 }
                 catch (Exception error)
                 {

                     throw;
                 }
             }));
        }

        private void MultiplePriceHeadingsChangeState(object _object, string member)
        {
            MenuCanvasItemChanged(_object as IMenuCanvasItem, member);
        }

        internal void MenuItemDropOnPage(BookPageViewModel bookPageViewModel)
        {
            RebuildPageAndAllToTherRight(bookPageViewModel);
        }


        private void RestaurantMenuChangeState(object _object, string member)
        {
            if (member == nameof(MenuPresentationModel.RestaurantMenu.Pages))
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreviousPages)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NextPages)));

                if (!RestaurantMenu.Pages.Contains(SeletedPage.MenuPage))
                {
                    SeletedPage = AllPages.Last();
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Pages)));
                }
            }
        }

        private void MenuCanvasItemChanged(IMenuCanvasItem menuCanvasitem, string member)
        {

            if (member == nameof(IMenuCanvasFoodItem.Description) ||
              member == nameof(IMenuCanvasFoodItem.ExtraDescription) ||
              member == nameof(IMenuCanvasFoodItem.Extras) ||
              member == nameof(IMenuCanvasHeading.Accent) ||
              member == nameof(IMenuCanvasHeading.NextColumnOrPage) ||
              (menuCanvasitem is IItemMultiPriceHeading && member == nameof(IItemMultiPriceHeading.PriceHeadingsAngle)) ||
              (menuCanvasitem is IItemMultiPriceHeading && member == nameof(IItemMultiPriceHeading.PriceHeadingsBottomMargin)) ||
              (menuCanvasitem is IItemMultiPriceHeading && member == nameof(IItemMultiPriceHeading.PriceHeadingsTopMargin)) ||
              (menuCanvasitem is IItemMultiPriceHeading && member == nameof(IItemMultiPriceHeading.PriceHeadingsHorizontalPos)) ||
              (menuCanvasitem is IItemMultiPriceHeading && member == nameof(IItemMultiPriceHeading.TransformOrigin)) ||
              (menuCanvasitem is IItemMultiPriceHeading && member == null))
            {
                var menuCanvasItems = RestaurantMenu.MenuCanvasItems.ToList();
                var menuPageViewModel = (from bookPage in _Pages where bookPage.MenuPage == menuCanvasitem.Page select bookPage).FirstOrDefault();

                if (menuCanvasitem is IMenuCanvasHeading &&
                    member == nameof(IMenuCanvasHeading.NextColumnOrPage) &&
                    !(menuCanvasitem as IMenuCanvasHeading).NextColumnOrPage &&
                    AllPages.IndexOf(menuPageViewModel) > 0)
                {
                    menuPageViewModel = AllPages[AllPages.IndexOf(menuPageViewModel) - 1];
                }
                RebuildPageAndAllToTherRight(menuPageViewModel);
            }





        }

        public List<MenuPresentationModel.MenuStyles.IStyleSheet> MenuStyles
        {
            get
            {
                return MenuPresentationModel.MenuStyles.StyleSheet.StyleSheets;
            }
        }

        static MenuItemsEditor.RestaurantMenus _RestaurantMenus;
        public static MenuItemsEditor.RestaurantMenus RestaurantMenus
        {
            get
            {
                if (_RestaurantMenus == null)
                {
                    string appDataPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\Microneme";
                    if (!System.IO.Directory.Exists(appDataPath))
                        System.IO.Directory.CreateDirectory(appDataPath);
                    appDataPath += "\\DontWaitWater";
                    if (!System.IO.Directory.Exists(appDataPath))
                        System.IO.Directory.CreateDirectory(appDataPath);
                    string storageLocation = appDataPath + "\\RestaurantMenuData.xml";
                    RawStorageData rawStorageData = new RawStorageData(XDocument.Load(storageLocation), storageLocation, null, null);
                    _RestaurantMenus = new MenuItemsEditor.RestaurantMenus(rawStorageData);
                }
                return _RestaurantMenus;
            }

            set
            {
                _RestaurantMenus = value;
            }
        }



        public RestaurantMenu RestaurantMenu
        {
            get
            {
                return RealObject;
            }
        }
      

        /// <exclude>Excluded</exclude>
        List<BookPageViewModel> _Pages = new List<BookPageViewModel>();


        private XDocument RestaurantMenuDoc;


        /// <MetaDataID>{4a875097-2293-464d-be4d-dd45107e1543}</MetaDataID>
        public List<BookPageViewModel> Pages
        {
            get
            {
                if (SeletedPage != null)
                    return new List<BookPageViewModel>() { SeletedPage };
                else
                    return new List<BookPageViewModel>();
            }
        }

        public string PreviousPages
        {
            get
            {
                if (AllPages.IndexOf(SeletedPage) > 0)
                    return AllPages.IndexOf(SeletedPage).ToString();
                else
                    return "";
            }
        }

        public string NextPages
        {
            get
            {
                if (SeletedPage == null || AllPages.IndexOf(SeletedPage) == -1 || AllPages.IndexOf(SeletedPage) == AllPages.Count - 1)
                    return "";
                return ((AllPages.Count - 1) - AllPages.IndexOf(SeletedPage)).ToString();
            }
        }

        public List<BookPageViewModel> AllPages
        {
            get
            {
                lock (_Pages)
                {
                  

                        if (_Pages.Count == 0)
                            _Pages.AddRange((from menuPage in RealObject.Pages select new BookPageViewModel(menuPage, this)).ToList());
                        else
                        {
                            var menuPageMap = (from bookPage in _Pages select bookPage).ToDictionary(bookPage => bookPage.MenuPage);
                            _Pages.Clear();
                            foreach (var menuPage in RealObject.Pages.OfType<MenuPage>())
                            {
                                BookPageViewModel bookPageViewModel = null;
                                if (menuPageMap.TryGetValue(menuPage, out bookPageViewModel))
                                    _Pages.Add(bookPageViewModel);
                                else
                                    _Pages.Add(new BookPageViewModel(menuPage, this));
                            }
                        }
                }


                return _Pages.ToList();
            }
        }

        /// <exclude>Excluded</exclude>
        BookPageViewModel _SelectedPage;
        public BookPageViewModel SeletedPage
        {
            get
            {
                if (_SelectedPage == null)
                {
                    if (AllPages.Count > 0)
                        _SelectedPage = AllPages[0];
                }
                return _SelectedPage;
            }
            set
            {
                if (_SelectedPage != value)
                {
                    _SelectedPage = value;

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Pages)));
                }
            }
        }

        internal MenuPresentationModel.MenuStyles.IStyleSheet EditStyleSheet
        {
            get
            {
                if (MenuStylesheet != null)
                    return MenuStylesheet;
                else
                    return _SelectedMenuStyle;
            }
        }

        public MenuPresentationModel.MenuStyles.StyleSheet MenuStylesheet;

        MenuPresentationModel.MenuStyles.IStyleSheet _SelectedMenuStyle;
        public MenuPresentationModel.MenuStyles.IStyleSheet SelectedMenuStyle
        {
            get
            {
                return _SelectedMenuStyle;
            }
            set
            {

                SuspendUpdateFromStyleSheetChange = true;
                try
                {
                    if (_SelectedMenuStyle == null)
                    {
                        var objectStorage = ObjectStorage.GetStorageOfObject(RealObject);
                        _SelectedMenuStyle = value;
                        MenuStylesheet = (value as MenuPresentationModel.MenuStyles.StyleSheet).CreateDerivedStyleSheet();
                        MenuStylesheet.ObjectChangeState += MenuStylesheetChangeState;
                        RestaurantMenu.ConntextStyleSheet = MenuStylesheet;
                        RestaurantMenu.Style = MenuStylesheet;
                        if (MenuStylesheet != null && MenuStylesheet.Styles.ContainsKey("page"))
                            (MenuStylesheet.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle).PropertyChanged += PageStyle_PropertyChanged;

                        if (MenuStylesheet != null && MenuStylesheet.Styles.ContainsKey("menu-item"))
                            (MenuStylesheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.MenuItemStyle).ObjectChangeState += MenuItemStyle_PropertyChanged;

                        if (MenuStylesheet != null && MenuStylesheet.Styles.ContainsKey("layout"))
                            (MenuStylesheet.Styles["layout"] as MenuPresentationModel.MenuStyles.LayoutStyle).PropertyChanged += LayoutStyle_PropertyChanged;

                        if (MenuStylesheet != null && MenuStylesheet.Styles.ContainsKey("price-options"))
                            (MenuStylesheet.Styles["price-options"] as MenuPresentationModel.MenuStyles.PriceStyle).ObjectChangeState += BookViewModel_PropertyChanged;


                        objectStorage.CommitTransientObjectState(MenuStylesheet);
                    }
                    else
                    {
                        _SelectedMenuStyle = value;
                        MenuStylesheet.ChangeOrgStyle(value as MenuPresentationModel.MenuStyles.StyleSheet);
                    }
                }
                finally
                {
                    SuspendUpdateFromStyleSheetChange = false;
                }

                RebuildAllPages();


                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMenuStyle)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedStyleName)));
            }
        }

        private void BookViewModel_PropertyChanged(object _object, string member)
        {
            if (member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.Layout) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.Font) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.PriceHeadingTransformOrigin) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.PriceHeadingAngle) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.PriceHeadingHorizontalPos) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.PriceHeadingsBottomMargin) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.MultiPriceSpacing) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.PriceLeader) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.ShowMultiplePrices) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.DotsSpaceFromItem) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.DotsSpaceFromPrice) ||
                member == nameof(MenuPresentationModel.MenuStyles.IPriceStyle.BetweenDotsSpace))
            {
                RebuildAllPages();
            }
        }

        private void LayoutStyle_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(MenuPresentationModel.MenuStyles.ILayoutStyle.NameIndent) ||
                e.PropertyName == nameof(MenuPresentationModel.MenuStyles.ILayoutStyle.LineSpacing) ||
                e.PropertyName == nameof(MenuPresentationModel.MenuStyles.ILayoutStyle.DescLeftIndent) ||
                e.PropertyName == nameof(MenuPresentationModel.MenuStyles.ILayoutStyle.ExtrasSeparator) ||
                 e.PropertyName == nameof(MenuPresentationModel.MenuStyles.ILayoutStyle.SpaceBetweenColumns) ||
                 e.PropertyName == nameof(MenuPresentationModel.MenuStyles.ILayoutStyle.LineBetweenColumns) ||
                 e.PropertyName == nameof(MenuPresentationModel.MenuStyles.ILayoutStyle.SeparationLineThickness) ||
                 e.PropertyName == nameof(MenuPresentationModel.MenuStyles.ILayoutStyle.SeparationLineColor) ||
                 e.PropertyName == nameof(MenuPresentationModel.MenuStyles.ILayoutStyle.SeparationLineType))
            {
                RebuildAllPages();
            }
        }

        private void MenuItemStyle_PropertyChanged(object _object, string member)
        {
            if (member == nameof(MenuPresentationModel.MenuStyles.IMenuItemStyle.Indent) ||
                member == nameof(MenuPresentationModel.MenuStyles.IMenuItemStyle.NewLineForDescription) ||
                member == nameof(MenuPresentationModel.MenuStyles.IMenuItemStyle.Alignment) ||
                member == nameof(MenuPresentationModel.MenuStyles.IMenuItemStyle.Font))
            {
                RebuildAllPages();
            }
        }

        private void PageStyle_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {

            if (e.PropertyName == nameof(MenuPresentationModel.MenuStyles.IPageStyle.Border) ||
                e.PropertyName == nameof(MenuPresentationModel.MenuStyles.IPageStyle.BorderMargin) ||
                e.PropertyName == nameof(MenuPresentationModel.MenuStyles.IPageStyle.Background) ||
                e.PropertyName == nameof(MenuPresentationModel.MenuStyles.IPageStyle.BackgroundMargin) ||
                e.PropertyName == nameof(MenuPresentationModel.MenuStyles.IPageStyle.BackgroundStretch))
            {
                return;
            }
            else if (e.PropertyName == nameof(MenuPresentationModel.MenuStyles.IPageStyle.ColumnsUneven))
            {
                if (SeletedPage != null && SeletedPage.MenuPage.NumberofColumns > 1)
                    RebuildAllPages();
            }
            else
            {
                RebuildAllPages();
            }
        }


        private void MenuStylesheetChangeState(object _object, string member)
        {
            if (!SuspendUpdateFromStyleSheetChange)
                RebuildAllPages();
        }
        bool OnUpdateMenuPagesStyle;
        private void UpdateMenuPagesStyle()
        {
            if (OnUpdateMenuPagesStyle)
                return;

            OnUpdateMenuPagesStyle = true;
            try
            {
                RestaurantMenu.ConntextStyleSheet = MenuStylesheet;
                var menuCanvasItems = RestaurantMenu.MenuCanvasItems.ToList();
                foreach (var menuPage in RestaurantMenu.Pages.OfType<MenuPage>())
                    menuPage.RenderMenuCanvasItems(menuCanvasItems);
                foreach (var page in Pages)
                    page.UpdateCanvasItems();
            }
            finally
            {
                OnUpdateMenuPagesStyle = false;
            }
        }
        /// <exclude>Excluded</exclude>
        bool _PopUp;

        public bool ShowPopUpMessage
        {
            get
            {
                return _PopUp;
            }
            set
            {
                _PopUp = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ShowPopUpMessage)));
            }
        }
        public string SelectedStyleName
        {
            get
            {
                if (_SelectedMenuStyle != null)
                    return _SelectedMenuStyle.Name;
                else
                    return "none";
            }
        }

    
        /// <exclude>Excluded</exclude>
        double _ZoomPercentage;
        public double ZoomPercentage
        {
            get
            {
                return _ZoomPercentage;
            }
            set
            {
                _ZoomPercentage = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ZoomPercentage)));
            }
        }

        /// <MetaDataID>{a3bb9949-2a2a-4546-822b-5eeb01ee5d45}</MetaDataID>
        internal void AddPageAfter(BookPageViewModel page)
        {


            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
            {
                int pageIndex = RestaurantMenu.Pages.IndexOf(page.MenuPage);
                var menuPage = new MenuPage();
                var objectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(RestaurantMenu);
                objectStorage.CommitTransientObjectState(menuPage);
                RestaurantMenu.InsertPage(pageIndex, menuPage);
                stateTransition.Consistent = true;
            }
            UpdateMenuPagesStyle();

            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("Pages"));

        }

        public event PropertyChangedEventHandler PropertyChanged;

        /// <MetaDataID>{9496b7e3-63ea-41be-b3e7-6ea2fdf7a4f5}</MetaDataID>
        internal void MoveSelectedPageLeft(BookPageViewModel page)
        {


            if (RestaurantMenu.Pages.IndexOf(page.MenuPage) > 0)
            {
                int index = RestaurantMenu.Pages.IndexOf(page.MenuPage);

                RestaurantMenu.MovePage(index - 1, page.MenuPage);

                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Pages"));

            }

        }

        /// <MetaDataID>{28afd124-eb12-4ab2-ad20-a960f1370da1}</MetaDataID>
        internal void LoadMenu(System.Xml.Linq.XElement menu)
        {
            //_Pages = new ObservableCollection<BookPageViewModel>((from pageXml in menu.Element("MenuPages").Elements("Page")
            //          select new BookPageViewModel(pageXml)).ToList());

            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("Pages"));
        }

        static internal BookViewModel NewMenu(RawStorageData rawStorageData)
        {
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
            {
                try
                {
                    OOAdvantech.PersistenceLayer.ObjectStorage objectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.NewStorage("RestMenu", rawStorageData, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider");
                    MenuPresentationModel.RestaurantMenu restaurantMenu = new MenuPresentationModel.RestaurantMenu();
                    restaurantMenu.Name = "IMenu";


                    objectStorage.CommitTransientObjectState(restaurantMenu);
                    MenuPresentationModel.MenuPage firstPage = new MenuPage();
                    objectStorage.CommitTransientObjectState(firstPage);
                    restaurantMenu.AddPage(firstPage);

                    MenuPresentationModel.MenuCanvas.FoodItemsHeading titleHeading = new MenuPresentationModel.MenuCanvas.FoodItemsHeading();
                    objectStorage.CommitTransientObjectState(titleHeading);
                    titleHeading.Description = "Gatsby's";// Gatsby's";
                    titleHeading.HeadingType = MenuPresentationModel.MenuCanvas.HeadingType.Title;
                    //firstPage.AddMenuItem(titleHeading);
                    restaurantMenu.AddMenuItem(titleHeading);

                    //MenuPresentationModel.MenuCanvas.FoodItemsHeading heading = new MenuPresentationModel.MenuCanvas.FoodItemsHeading();
                    //objectStorage.CommitTransientObjectState(heading);
                    //heading.Description = "Appetizers";
                    ////firstPage.AddMenuItem(heading);
                    //restaurantMenu.AddMenuItem(heading);
                    //MenuPresentationModel.MenuCanvas.MenuCanvasFoodItem foodItem = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItem();
                    //foodItem.Description = "Samples - Click to Edit ";// - Click to Edit  Samples - Click to Edittt describe your food item";
                    //MenuPresentationModel.MenuCanvas.MenuCanvasFoodItemPrice foodItemPrice = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItemPrice();
                    //foodItemPrice.Price = 9.95m;
                    //foodItem.AddFoodItemPrice(foodItemPrice);
                    ////foodItem.ExtraDescription = "Description for the sample item. Use this to describe your food item";
                    //foodItem.ExtraDescription = "This item uses Market for price. The price field can be any number or text, and can even be multiplep prices(separate them with a semi - colon)";
                    //foodItem.Extras = "Bacon, Onions, Prosciutto";
                    //objectStorage.CommitTransientObjectState(foodItem);
                    ////firstPage.AddMenuItem(foodItem);
                    //restaurantMenu.AddMenuItem(foodItem);

                    //foodItem = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItem();
                    //foodItem.Description = "Pizza Napoletana ";// - Click to Edit  Samples - Click to Edittt describe your food item";
                    //foodItemPrice = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItemPrice();
                    //foodItemPrice.Price = 9.95m;
                    //foodItem.AddFoodItemPrice(foodItemPrice);
                    ////foodItem.ExtraDescription = "Description for the sample item. Use this to describe your food item";
                    //foodItem.ExtraDescription = "You can click to edit these sample items or delete them from the food item list";
                    //foodItem.Extras = "Bacon, Onions, Prosciutto";
                    //objectStorage.CommitTransientObjectState(foodItem);
                    ////firstPage.AddMenuItem(foodItem);
                    //restaurantMenu.AddMenuItem(foodItem);

                    //heading = new MenuPresentationModel.MenuCanvas.FoodItemsHeading();
                    //objectStorage.CommitTransientObjectState(heading);
                    //heading.Description = "Pasta Sample";
                    ////firstPage.AddMenuItem(heading);
                    //restaurantMenu.AddMenuItem(heading);

                    //foodItem = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItem();
                    //foodItem.Description = "Angel Chicken Pasta ";// - Click to Edit  Samples - Click to Edittt describe your food item";
                    //foodItemPrice = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItemPrice();
                    //foodItemPrice.Price = 9.95m;
                    //foodItem.AddFoodItemPrice(foodItemPrice);
                    ////foodItem.ExtraDescription = "Description for the sample item. Use this to describe your food item";
                    //foodItem.ExtraDescription = "You can click to edit these sample items or delete them from the food item list";
                    //foodItem.Extras = "Bacon, Onions, Prosciutto";
                    //objectStorage.CommitTransientObjectState(foodItem);
                    ////firstPage.AddMenuItem(foodItem);
                    //restaurantMenu.AddMenuItem(foodItem);

                    //foodItem = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItem();
                    //foodItem.Description = "Angel Chicken Pasta ";// - Click to Edit  Samples - Click to Edittt describe your food item";
                    //foodItemPrice = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItemPrice();
                    //foodItemPrice.Price = 9.95m;
                    //foodItem.AddFoodItemPrice(foodItemPrice);
                    ////foodItem.ExtraDescription = "Description for the sample item. Use this to describe your food item";
                    //foodItem.ExtraDescription = "You can click to edit these sample items or delete them from the food item list";
                    //foodItem.Extras = "Bacon, Onions, Prosciutto";
                    //objectStorage.CommitTransientObjectState(foodItem);
                    ////firstPage.AddMenuItem(foodItem);
                    //restaurantMenu.AddMenuItem(foodItem);

                    //foodItem = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItem();
                    //foodItem.Description = "Angel Chicken Pasta 1";// - Click to Edit  Samples - Click to Edittt describe your food item";
                    //foodItemPrice = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItemPrice();
                    //foodItemPrice.Price = 9.95m;
                    //foodItem.AddFoodItemPrice(foodItemPrice);
                    ////foodItem.ExtraDescription = "Description for the sample item. Use this to describe your food item";
                    //foodItem.ExtraDescription = "You can click to edit these sample items or delete them from the food item list";
                    //foodItem.Extras = "Bacon, Onions, Prosciutto";
                    //objectStorage.CommitTransientObjectState(foodItem);
                    ////firstPage.AddMenuItem(foodItem);
                    //restaurantMenu.AddMenuItem(foodItem);

                    //foodItem = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItem();
                    //foodItem.Description = "Angel Chicken Pasta 2";// - Click to Edit  Samples - Click to Edittt describe your food item";
                    //foodItemPrice = new MenuPresentationModel.MenuCanvas.MenuCanvasFoodItemPrice();
                    //foodItemPrice.Price = 9.95m;
                    //foodItem.AddFoodItemPrice(foodItemPrice);
                    ////foodItem.ExtraDescription = "Description for the sample item. Use this to describe your food item";
                    //foodItem.ExtraDescription = "You can click to edit these sample items or delete them from the food item list";
                    //foodItem.Extras = "Bacon, Onions, Prosciutto";
                    //objectStorage.CommitTransientObjectState(foodItem);
                    ////firstPage.AddMenuItem(foodItem);

                    //heading = new MenuPresentationModel.MenuCanvas.FoodItemsHeading();
                    //objectStorage.CommitTransientObjectState(heading);
                    //heading.Description = "Pasta Sample";
                    ////firstPage.AddMenuItem(heading);
                    //restaurantMenu.AddMenuItem(heading);

                    return new BookViewModel(restaurantMenu, rawStorageData);
                }
                finally
                {
                    stateTransition.Consistent = true;
                }

            }


        }

        internal void MoveToPreviousPage()
        {
            if (AllPages.IndexOf(SeletedPage) > 0)
            {
                SeletedPage = AllPages[AllPages.IndexOf(SeletedPage) - 1];


                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Pages)));

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NextPages)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreviousPages)));

                Transaction.ExecuteAsynch(new Action(() =>
                {
                    lock (this)
                    {
                        SeletedPage.UpdateCanvasItems();
                    }
                }));
            }
        }

        internal void MoveToNextPage()
        {
            if (AllPages.IndexOf(SeletedPage) != AllPages.Count - 1)
            {
                SeletedPage = AllPages[AllPages.IndexOf(SeletedPage) + 1];

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Pages)));

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NextPages)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreviousPages)));
                Transaction.ExecuteAsynch(new Action(() =>
                {
                    lock (this)
                    {
                        SeletedPage.UpdateCanvasItems();
                    }
                }));
            }
        }



        internal void ResetPageFontsSizes()
        {
            SuspendUpdateFromStyleSheetChange = true;
            try
            {
                var menuItemStyle = EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle;
                var priceStyle = EditStyleSheet.Styles["price-options"] as MenuPresentationModel.MenuStyles.IPriceStyle;
                var titleHeadingStyle = EditStyleSheet.Styles["title-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;
                var headingStyle = EditStyleSheet.Styles["heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;
                var smallHeadingStyle = EditStyleSheet.Styles["small-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;
                var altFontHeadingStyle = EditStyleSheet.Styles["alt-font-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;

                menuItemStyle.RestFont();
                priceStyle.RestFont();
                titleHeadingStyle.RestFont();
                headingStyle.RestFont();
            }
            finally
            {
                SuspendUpdateFromStyleSheetChange = false;
            }
            RebuildAllPages();

        }

        internal void ExpandPageFontsSizes()
        {
            SuspendUpdateFromStyleSheetChange = true;
            try
            {
                var menuItemStyle = EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle;
                var priceStyle = EditStyleSheet.Styles["price-options"] as MenuPresentationModel.MenuStyles.IPriceStyle;
                var titleHeadingStyle = EditStyleSheet.Styles["title-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;
                var headingStyle = EditStyleSheet.Styles["heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;
                var smallHeadingStyle = EditStyleSheet.Styles["small-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;
                var altFontHeadingStyle = EditStyleSheet.Styles["alt-font-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;

                var font = menuItemStyle.Font;
                font.FontSize = font.FontSize * 1.1;
                menuItemStyle.Font = font;

                font = menuItemStyle.ExtrasFont;
                font.FontSize = font.FontSize * 1.1;
                menuItemStyle.ExtrasFont = font;

                font = menuItemStyle.DescriptionFont;
                font.FontSize = font.FontSize * 1.1;
                menuItemStyle.DescriptionFont = font;

                font = menuItemStyle.ExtrasFont;
                font.FontSize = font.FontSize * 1.1;
                menuItemStyle.ExtrasFont = font;

                font = priceStyle.Font;
                font.FontSize = font.FontSize * 1.1;
                priceStyle.Font = font;

                font = titleHeadingStyle.Font;
                font.FontSize = font.FontSize * 1.1;
                titleHeadingStyle.Font = font;

                font = headingStyle.Font;
                font.FontSize = font.FontSize * 1.1;
                headingStyle.Font = font;
            }
            finally
            {
                SuspendUpdateFromStyleSheetChange = false;
            }
            RebuildAllPages();
        }

        bool SuspendUpdateFromStyleSheetChange;
        internal void ShrinkPageFontsSizes()
        {
            SuspendUpdateFromStyleSheetChange = true;
            try
            {
                var menuItemStyle = EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle;
                var priceStyle = EditStyleSheet.Styles["price-options"] as MenuPresentationModel.MenuStyles.IPriceStyle;
                var titleHeadingStyle = EditStyleSheet.Styles["title-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;
                var headingStyle = EditStyleSheet.Styles["heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;
                var smallHeadingStyle = EditStyleSheet.Styles["small-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;
                var altFontHeadingStyle = EditStyleSheet.Styles["alt-font-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle;

                var font = menuItemStyle.Font;
                font.FontSize = font.FontSize / 1.1;
                menuItemStyle.Font = font;

                font = menuItemStyle.ExtrasFont;
                font.FontSize = font.FontSize / 1.1;
                menuItemStyle.ExtrasFont = font;

                font = menuItemStyle.DescriptionFont;
                font.FontSize = font.FontSize / 1.1;
                menuItemStyle.DescriptionFont = font;

                font = menuItemStyle.ExtrasFont;
                font.FontSize = font.FontSize / 1.1;
                menuItemStyle.ExtrasFont = font;

                font = priceStyle.Font;
                font.FontSize = font.FontSize / 1.1;
                priceStyle.Font = font;

                font = titleHeadingStyle.Font;
                font.FontSize = font.FontSize / 1.1;
                titleHeadingStyle.Font = font;

                font = headingStyle.Font;
                font.FontSize = font.FontSize / 1.1;
                headingStyle.Font = font;

            }
            finally
            {
                SuspendUpdateFromStyleSheetChange = false;
            }
            RebuildAllPages();
        }

        internal void ExpandLineSpace()
        {
            (EditStyleSheet.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle).LineSpacing += 5;
            UpdateMenuPagesStyle();
        }

        internal void ShrinkLineSpace()
        {

            (EditStyleSheet.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle).LineSpacing -= 5;
            UpdateMenuPagesStyle();
        }

        internal void ResetLineSpace()
        {
            (EditStyleSheet.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle).ResetLineSpacing();
            UpdateMenuPagesStyle();
        }

        static internal BookViewModel OpenMenu(RawStorageData restaurantMenuDoc)
        {

            OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(OOAdvantech.PersistenceLayer.ObjectStorage.OpenStorage("RestMenu", restaurantMenuDoc, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider"));

            MenuPresentationModel.RestaurantMenu restaurantMenu = (from menu in storage.GetObjectCollection<MenuPresentationModel.RestaurantMenu>()
                                                                   select menu).FirstOrDefault();
            return new BookViewModel(restaurantMenu, restaurantMenuDoc);
        }


    }
}
