﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media.Imaging;
using MenuItemsEditor;
using OOAdvantech.PersistenceLayer;
using OOAdvantech.Transactions;
using WPFUIElementObjectBind;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{9714df9f-8db5-4d27-8ed2-a3a0952a786a}</MetaDataID>
    public class MenuHeadingsPresentation : MarshalByRefObject, INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;

   
        MenuPresentationModel.RestaurantMenu RestaurantMenu;

        public MenuHeadingsPresentation(MenuPresentationModel.RestaurantMenu restaurantMenu)
        {


            RestaurantMenu = restaurantMenu;
            var objectStorage= OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(RestaurantMenu);

            if (objectStorage != null)
            {
                OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(objectStorage);

                var headings = (from heading in storage.GetObjectCollection<MenuPresentationModel.MenuCanvas.IMenuCanvasHeading>()
                                select heading).ToList();

                _Headings = (from heading in headings
                             select new ListMenuHeadingPresentation(restaurantMenu, heading)).ToList();

            }
            else
                _Headings = new List<ListMenuHeadingPresentation>();
            //(from page in RestaurantMenu.Pages
            // from heading in page.MenuCanvasItems.OfType<MenuPresentationModel.MenuCanvas.IMenuCanvasHeading>()
            // select new MenuHeadingPresentation(restaurantMenu, heading)).ToList();

            DeleteMenuCommand = new RelayCommand((object sender) =>
            {
                if (_SelectedHeading.Heading != null&& _SelectedHeading.Heading.Page==null)
                {
                    OOAdvantech.PersistenceLayer.ObjectStorage.DeleteObject(_SelectedHeading.Heading, DeleteOptions.TryToDelete);
                    _Headings.Remove(_SelectedHeading);
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Headings)));
                }
                //Delete();
            }, (object sender) => CanDelete(sender));

            EditHeadingCommand = new RelayCommand((object sender) =>
            {
                System.Windows.Window win = System.Windows.Window.GetWindow(EditHeadingCommand.UserInterfaceObjectConnection.ContainerControl as System.Windows.DependencyObject);
                using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
                {
                    var menuItemWindow = new Views.HeadingWindow();
                    menuItemWindow.Owner = win;
                    MenuHeadingViewModel menuHeadingViewModel = new MenuHeadingViewModel(SelectedHeading.Heading, RestaurantMenu);
                    menuItemWindow.GetObjectContext().SetContextInstance(menuHeadingViewModel);
                    if (menuItemWindow.ShowDialog().Value)
                        stateTransition.Consistent = true;
                }

            }, (object sender) => CanEdit(sender));

            NewHeadingCommand = new RelayCommand((object sender) =>
            {
                MenuPresentationModel.MenuCanvas.FoodItemsHeading foodItemsHeading = new MenuPresentationModel.MenuCanvas.FoodItemsHeading();
                OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(RestaurantMenu).CommitTransientObjectState(foodItemsHeading);
                var headingPresentation = new ViewModel.ListMenuHeadingPresentation(RestaurantMenu, foodItemsHeading);
                headingPresentation.EditMode();
                _Headings.Add(headingPresentation);

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Headings)));
            });

            RenameCommand = new RelayCommand((object sender) =>
            {
                SelectedHeading.EditMode();
                //Delete();
            }, (object sender) => CanRename(sender));
        }

        private bool CanEdit(object sender)
        {
            if (SelectedHeading != null)
                return true;
            else
                return false;
        }

        private bool CanRename(object sender)
        {
            if (_SelectedHeading != null)
                return true;
            else
                return false;
        }
        private bool CanDelete(object sender)
        {
            if (SelectedHeading != null && SelectedHeading.Heading.Page == null)
                return true;
            return false;
        }

        public WPFUIElementObjectBind.RelayCommand RenameCommand { get; protected set; }
        public WPFUIElementObjectBind.RelayCommand DeleteMenuCommand { get; protected set; }
        public WPFUIElementObjectBind.RelayCommand NewHeadingCommand { get; protected set; }

        public WPFUIElementObjectBind.RelayCommand EditHeadingCommand { get; protected set; }

        /// <exclude>Excluded</exclude>
        ListMenuHeadingPresentation _SelectedHeading;
        public ListMenuHeadingPresentation SelectedHeading
        {
            get
            {
                return _SelectedHeading;
            }
            set
            {
                //if (_SelectedHeading != null&& _SelectedHeading!=value)
                //    _SelectedHeading.IsEditing = false;

                _SelectedHeading = value;
            }
        }


        /// <exclude>Excluded</exclude>
        List<WPFUIElementObjectBind.MenuComamnd> _ContextMenuItems;
        public List<WPFUIElementObjectBind.MenuComamnd> ContextMenuItems
        {
            get
            {
                //return null;
                if (_ContextMenuItems == null)
                {

                    _ContextMenuItems = new List<MenuComamnd>();


                    var imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/Delete.png"));
                    MenuComamnd menuItem = new MenuComamnd();
                    menuItem.Header = Properties.Resources.DeleteMenuItemHeader;
                    menuItem.Icon = new Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = DeleteMenuCommand;
                    _ContextMenuItems.Add(menuItem);

                    menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/Rename16.png"));
                    menuItem.Header = Properties.Resources.RenameMenuIHeadingHeader;
                    menuItem.Icon = new Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = RenameCommand;

                    _ContextMenuItems.Add(menuItem);

                    menuItem = new WPFUIElementObjectBind.MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/Edit16.png"));
                    menuItem.Header = Properties.Resources.EditMenuItemHeader;
                    menuItem.Icon = new Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = EditHeadingCommand;

                    _ContextMenuItems.Add(menuItem);

                    _ContextMenuItems.Add(null);



                    menuItem = new WPFUIElementObjectBind.MenuComamnd(); ;
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/DocumentHeaderAdd.png"));
                    menuItem.Header = Properties.Resources.NewMenuIHeadingHeader;
                    menuItem.Icon = new Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = NewHeadingCommand;

                    _ContextMenuItems.Add(menuItem);


                }
                return _ContextMenuItems;
            }
        }

        /// <exclude>Excluded</exclude>
        List<ListMenuHeadingPresentation> _Headings;
        public List<ListMenuHeadingPresentation> Headings
        {
            get
            {
                return _Headings;
            }
        }
    }
}
