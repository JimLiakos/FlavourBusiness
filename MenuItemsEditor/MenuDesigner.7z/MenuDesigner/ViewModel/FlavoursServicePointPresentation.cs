﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using FlavourBusinessFacade;
using OOAdvantech.Transactions;
using WPFUIElementObjectBind;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{0d1d707a-9f9c-473c-a556-daedf99c71b2}</MetaDataID>
    public class FlavoursServicesContextPresentation : FBResourceTreeNode, INotifyPropertyChanged, IDragDropTarget
    {

        FBResourceTreeNode Company;
        public readonly IFlavoursServicesContext ServicesContext;
        public FlavoursServicesContextPresentation(IFlavoursServicesContext servicesContext, FBResourceTreeNode company)
        {
            ServicesContext = servicesContext;
            Company = company;

            RenameCommand = new RelayCommand((object sender) =>
            {
                EditMode();
            });

            DeleteCommand = new RelayCommand((object sender) =>
            {
                Delete();
            });


            AddServiceAreaCommand = new RelayCommand((object sender) =>
            {
                AddServiceArea();
            });
        }

        private void AddServiceArea()
        {

            //ServicesContext.NewServiceArea();
        }

        private void Delete()
        {
            (Company as CompanyPresentation).RemoveServicePoint(this);

        }

        public void EditMode()
        {
            if (_Edit == true)
            {
                _Edit = !_Edit;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Edit)));
            }
            _Edit = true;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Edit)));
        }


        public RelayCommand RenameCommand { get; protected set; }

        public RelayCommand AddServiceAreaCommand { get; protected set; }



        public RelayCommand DeleteCommand { get; protected set; }

        /// <exclude>Excluded</exclude>
        List<MenuComamnd> _ContextMenuItems;
        public override List<MenuComamnd> ContextMenuItems
        {
            get
            {

                if (_ContextMenuItems == null)
                {

                    _ContextMenuItems = new List<MenuComamnd>();

                    var imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Empty.png"));
                    var emptyImage = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };

                    MenuComamnd menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Rename16.png"));
                    menuItem.Header = MenuItemsEditor.Properties.Resources.TreeNodeRenameMenuItemHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = RenameCommand;
                    _ContextMenuItems.Add(menuItem);


                    _ContextMenuItems.Add(null);

                    menuItem = new MenuComamnd(); ;
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/ServicePoint.png"));
                    menuItem.Header = Properties.Resources.AddServiceAreaHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    //menuItem.Command = NewMenuItemCommand;

                    _ContextMenuItems.Add(menuItem);

                    menuItem = new MenuComamnd(); 
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/delete.png"));
                    menuItem.Header = Properties.Resources.RemoveServicesContextHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = DeleteCommand;

                    _ContextMenuItems.Add(menuItem);



                }
                //if (_ContextMenuItems == null)
                //{
                //    _ContextMenuItems = new List<MenuComamnd>();
                //}
                return _ContextMenuItems;
            }
        }





        public override bool IsEditable
        {
            get
            {
                return true;
            }
        }




        public override List<FBResourceTreeNode> Members
        {
            get
            {
                return new List<FBResourceTreeNode>();
            }
        }

        public override string Name
        {
            get
            {
                return this.ServicesContext.Description;
            }

            set
            {
                using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
                {
                    this.ServicesContext.Description = value; 
                    stateTransition.Consistent = true;
                }
            }
        }

        public override FBResourceTreeNode Parent
        {
            get
            {
                return Company;
            }

            set
            {
            }
        }
        public virtual bool HasContextMenu
        {
            get
            {
                return true;
            }
        }
        public override List<MenuComamnd> SelectedItemContextMenuItems
        {
            get
            {
                if (IsSelected)
                    return ContextMenuItems;
                else
                    foreach (var treeNode in Members)
                    {
                        var contextMenuItems = treeNode.SelectedItemContextMenuItems;
                        if (contextMenuItems != null)
                            return contextMenuItems;
                    }

                return null;
            }
        }

        public override ImageSource TreeImage
        {
            get
            {
                return new System.Windows.Media.Imaging.BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/Restaurant16.png"));

            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void DragEnter(object sender, DragEventArgs e)
        {

            ViewModel.GraphicMenuTreeNode graphicMenuTreeNode = e.Data.GetData(typeof(ViewModel.GraphicMenuTreeNode)) as ViewModel.GraphicMenuTreeNode;
            if (graphicMenuTreeNode == null)
                e.Effects = DragDropEffects.None;

        }

        public void DragLeave(object sender, DragEventArgs e)
        {
            ViewModel.GraphicMenuTreeNode graphicMenuTreeNode = e.Data.GetData(typeof(ViewModel.GraphicMenuTreeNode)) as ViewModel.GraphicMenuTreeNode;
            if (graphicMenuTreeNode == null)
                e.Effects = DragDropEffects.None;

        }

        public void DragOver(object sender, DragEventArgs e)
        {
            ViewModel.GraphicMenuTreeNode graphicMenuTreeNode = e.Data.GetData(typeof(ViewModel.GraphicMenuTreeNode)) as ViewModel.GraphicMenuTreeNode;
            if (graphicMenuTreeNode == null)
                e.Effects = DragDropEffects.None;

        }

        public void Drop(object sender, DragEventArgs e)
        {
            ViewModel.GraphicMenuTreeNode graphicMenuTreeNode = e.Data.GetData(typeof(ViewModel.GraphicMenuTreeNode)) as ViewModel.GraphicMenuTreeNode;
            if (graphicMenuTreeNode == null)
                e.Effects = DragDropEffects.None;
            else
            {
                var servicePointRunTime = ServicesContext.GetRunTime();
            }

        }

        public override void SelectionChange()
        {
        }
    }
}
