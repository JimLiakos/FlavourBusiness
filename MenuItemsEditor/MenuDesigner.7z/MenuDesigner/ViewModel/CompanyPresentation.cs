﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using FlavourBusinessFacade;
using WPFUIElementObjectBind;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{7151c406-5113-431d-b326-a5f9e0955550}</MetaDataID>
    public class CompanyPresentation :  FBResourceTreeNode, INotifyPropertyChanged, IDragDropTarget
    {


        public event EventHandler CompanySignedOut;
            
        public override void SelectionChange()
        {

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ContextMenuItems)));
            
        }

        internal Dictionary<string, List<GraphicMenuTreeNode>> GraphicStorageReferences = new Dictionary<string, List<GraphicMenuTreeNode>>();

        public RelayCommand RenameCommand { get; protected set; }


        public RelayCommand SettingsCommand { get; protected set; }

        public RelayCommand AddFlavoursServicePointCommand { get; protected set; }

        private IOrganization Organization;

        public List<OrganizationStorageRef> GraphicMenus;

        MenusTreeNode Menus;
        GraphicMenusPresentation GraphicMenusPresentation;
        public CompanyPresentation(IOrganization organization, FBResourceTreeNode parent, GraphicMenusPresentation graphicMenusPresentation) :base(parent)
        {

            IsNodeExpanded = true;
            GraphicMenusPresentation = graphicMenusPresentation;
            this.Organization = organization;


            GraphicMenus = (Organization as IResourceManager).GraphicMenus;

            //if (GraphicMenus.Count > 0)
                Menus = new MenusTreeNode(this);

            RenameCommand = new RelayCommand((object sender) =>
            {
                EditMode();
            });

            SettingsCommand = new RelayCommand((object sender) =>
            {

                var businessResources = App.Current.MainWindow.GetDataContextObject<FlavourBusinessManagerViewModel>().BusinessResources;
                Views.CompanySettingsWindow companySettings = new Views.CompanySettingsWindow();
                companySettings.SetObjectContextInstance<FlavourBusinessResourcesPresentation>(businessResources);

                //businessResources.SignOut

                System.Windows.Window win = App.Current.MainWindow;//System.Windows.Window.GetWindow(e.OriginalSource as System.Windows.DependencyObject);
                companySettings.Owner = win;
                companySettings.ShowDialog();

            });
            AddFlavoursServicePointCommand = new RelayCommand((object sender) =>
            {
                AddServicesContextPoint();
            });

            Task.Run(() =>
            {
                foreach (var ServicePoint in Organization.ServicesContexts)
                {
                    ServicesContexts.Add(ServicePoint, new FlavoursServicesContextPresentation(ServicePoint, this));
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Members)));
            });
        }

        public void SignOut()
        {
            CompanySignedOut?.Invoke(this, EventArgs.Empty);
        }

        internal void RemoveServicesContext(FlavoursServicesContextPresentation flavoursServicePointPresentation)
        {

            Task.Run(() =>
            {
                Organization.DeleteServicesContext(flavoursServicePointPresentation.ServicesContext);
                ServicesContexts.Remove(flavoursServicePointPresentation.ServicesContext);
                foreach (var ServicePoint in Organization.ServicesContexts)
                {
                    if (!ServicesContexts.ContainsKey(ServicePoint))
                        ServicesContexts.Add(ServicePoint, new FlavoursServicesContextPresentation(ServicePoint, this));
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Members)));
            });


        }

        Dictionary<IFlavoursServicesContext, FlavoursServicesContextPresentation> ServicesContexts = new Dictionary<IFlavoursServicesContext, FlavoursServicesContextPresentation>();

        private async void AddServicesContextPoint()
        {
             await Task.Run(() =>
            {
                var newFlavoursServicePoint = Organization.NewFlavoursServicesContext();
                //foreach (var ServicePoint in Organization.ServicePoints)
                ServicesContexts.Add(newFlavoursServicePoint, new FlavoursServicesContextPresentation(newFlavoursServicePoint, this));

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Members)));
            });
        }

        public void EditMode()
        {
            if (_Edit == true)
            {
                _Edit = !_Edit;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Edit)));
            }
            _Edit = true;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Edit)));
        }

        public void DragEnter(object sender, DragEventArgs e)
        {
            
        }

        public void DragLeave(object sender, DragEventArgs e)
        {
            
        }

        public void DragOver(object sender, DragEventArgs e)
        {
            
        }

        public void Drop(object sender, DragEventArgs e)
        {
            
        }

        /// <exclude>Excluded</exclude>
        List<MenuComamnd> _ContextMenuItems;
        public override List<MenuComamnd>  ContextMenuItems
        {
            get
            {

                if (_ContextMenuItems == null)
                {

                    _ContextMenuItems = new List<MenuComamnd>();

                    var imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Empty.png"));
                    var emptyImage = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };

                    //imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Delete.png"));
                    //MenuComamnd menuItem = new MenuComamnd();
                    //menuItem.Header = Properties.Resources.DeleteMenuItemHeader;
                    //menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    ////menuItem.Command = DeleteMenuCommand;
                    //_ContextMenuItems.Add(menuItem);

                    MenuComamnd menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Rename16.png"));
                    menuItem.Header = MenuItemsEditor.Properties.Resources.TreeNodeRenameMenuItemHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = RenameCommand;

                    _ContextMenuItems.Add(menuItem);


                    

                    //menuItem = new MenuComamnd();
                    //imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Rename16.png"));
                    ////menuItem.Header = Properties.Resources.TreeNodeRenameMenuItemHeader;
                    //menuItem.Icon = new Image() { Source = imageSource, Width = 16, Height = 16 };
                    //menuItem.Command = RenameCommand;

                    _ContextMenuItems.Add(null);


                    //menuItem = new MenuComamnd();
                    //imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/cafe16.png"));
                    //menuItem.Header = Properties.Resources.AddServicePointHeader;
                    //menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    //menuItem.Command = AddFlavoursServicePointCommand;

                    //_ContextMenuItems.Add(menuItem);
                    
                    menuItem = new MenuComamnd(); 
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/Restaurant16.png"));
                    menuItem.Header = Properties.Resources.AddServicesContextHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = AddFlavoursServicePointCommand;

                    _ContextMenuItems.Add(menuItem);


                    menuItem = new MenuComamnd(); 
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/settings16.png"));
                    menuItem.Header = Properties.Resources.SettingsMenuPrompt;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = SettingsCommand;

                    _ContextMenuItems.Add(menuItem);


                    

                    //menuItem = new MenuComamnd(); ;
                    //imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/delete.png"));
                    //menuItem.Header = Properties.Resources.RemoveServicesContextHeader;
                    //menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    ////menuItem.Command = NewMenuItemCommand;

                    //_ContextMenuItems.Add(menuItem);

                    //menuItem = new MenuComamnd();
                    //imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Type16.png"));
                    //menuItem.Header = MenuItemsEditor.Properties.Resources.ShowCategoryOptionTypesMenuItemHeader;
                    //menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    ////menuItem.Command = EditOptionsTypesCommand;

                    //_ContextMenuItems.Add(menuItem);

                }
                return _ContextMenuItems;
            }
        }

    

        public virtual bool HasContextMenu
        {
            get
            {
                return true;
            }
        }

        public virtual bool IsEditable
        {
            get
            {
                return true;
            }
        }


        
  
        public override List<FBResourceTreeNode> Members
        {
            get
            {
                var members=  ServicesContexts.Values.OfType<FBResourceTreeNode>().ToList();
                if (Menus != null)
                    members.Add(Menus);

                return members;

            }
        }

        public override string Name
        {
            get
            {
                return this.Organization.Name;
            }

            set
            {
            }
        }


        FBResourceTreeNode _Parent;
        public FBResourceTreeNode Parent
        {
            get
            {
                return _Parent;
            }

            set
            {
                _Parent = value;
            }
        }

        public override List<MenuComamnd> SelectedItemContextMenuItems
        {
            get
            {
                if (IsSelected)
                    return null;
                else
                    foreach(var treeNode in Members )
                    {
                        var contextMenuItems = treeNode.SelectedItemContextMenuItems;
                        if (contextMenuItems != null)
                            return contextMenuItems;
                    }

                return null;
            }
        }

        public override ImageSource TreeImage
        {
            get
            {
                return new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/FlavourBusiness.png"));
                
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
