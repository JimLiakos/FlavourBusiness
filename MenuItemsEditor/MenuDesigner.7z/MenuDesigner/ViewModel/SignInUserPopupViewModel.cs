﻿using FlavourBusinessFacade;
using FlavourBusinessManager;
using OOAdvantech.Remoting.RestApi;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Net.Http;
using System.Xml.Linq;
using FlavourBusinessToolKit;
using OOAdvantech.Transactions;
using System.Net.WebSockets;
using System.Threading;
using System.ServiceModel;

namespace MenuDesigner.ViewModel
{



    public delegate void NewMessmateHandler(SignInUserPopupViewModel flavoursOrderServer, string messmateName);


    /// <MetaDataID>{796fc987-8b06-477a-976e-e9ff817ae3c8}</MetaDataID>
    public class SignInUserPopupViewModel : MarshalByRefObject, INotifyPropertyChanged, IUser, OOAdvantech.Remoting.IExtMarshalByRefObject
    {

        [OOAdvantech.MetaDataRepository.HttpVisible]
        public event NewMessmateHandler MessmateAdded;

        [OOAdvantech.MetaDataRepository.HttpVisible]
        public event OOAdvantech.ObjectChangeStateHandle ObjectChanged;

        public event EventHandler SwitchOnOffPopupView;

        FlavourBusinessManagerViewModel MenuDesignerViewModel;
        public SignInUserPopupViewModel(FlavourBusinessManagerViewModel menuDesignerViewModel)
        {
            MenuDesignerViewModel = menuDesignerViewModel;

            _PopupWitdh = 510;
            _PopupHeight = 540;

            MessmateAdded += SignInUserPopupViewModel_MessmateAdded;
        }

        private void SignInUserPopupViewModel_MessmateAdded(SignInUserPopupViewModel flavoursOrderServer, string messmateName)
        {

        }

        string _Path;
        public string PathPoints
        {
            get
            {
                //PathGeometry path = new PathGeometry();
                //System.Windows.Size size = new System.Windows.Size(PopupHeight, PopupWitdh);
                //int arrowPos = (int)(size.Width * 0.82);


                //PathGeometry pathGeometry = new PathGeometry();
                //pathGeometry.FillRule = FillRule.Nonzero;
                //PathFigure pathFigure = new PathFigure();
                //pathFigure.StartPoint = new Point(0, 10);
                //pathFigure.IsClosed = true;
                //pathGeometry.Figures.Add(pathFigure);
                //LineSegment lineSegment = new LineSegment();
                //lineSegment.Point = new Point(arrowPos, 10);
                //pathFigure.Segments.Add(lineSegment);
                //lineSegment = new LineSegment();
                //lineSegment.Point = new Point(arrowPos + 10, 0);
                //pathFigure.Segments.Add(lineSegment);
                //lineSegment = new LineSegment();
                //lineSegment.Point = new Point(arrowPos + 20, 10);
                //pathFigure.Segments.Add(lineSegment);
                //lineSegment = new LineSegment();
                //lineSegment.Point = new Point(size.Width, 10);
                //pathFigure.Segments.Add(lineSegment);
                //lineSegment = new LineSegment();
                //lineSegment.Point = new Point(size.Width, size.Height);
                //pathFigure.Segments.Add(lineSegment);
                //lineSegment = new LineSegment();
                //lineSegment.Point = new Point(0, size.Height);
                //pathFigure.Segments.Add(lineSegment);

                ////return pathGeometry;


                //if (_Path == null)
                //    _Path = string.Format(new System.Globalization.CultureInfo(1033), "M0,10 {2},10 {3},0 {4},10 L{0},10 {0}, {1}  0, {1} z", size.Width, size.Height, arrowPos, arrowPos + 10, arrowPos + 20);
                return _Path;
            }
        }


        internal void SetHostWindowSize(Size size)
        {
            int arrowPos = (int)(size.Width * 0.82);
            _Path = string.Format(new System.Globalization.CultureInfo(1033), "M0,10 {2},10 {3},0 {4},10 L{0},10 {0}, {1}  0, {1} z", size.Width, size.Height, arrowPos, arrowPos + 10, arrowPos + 20);
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PathPoints)));
        }

        public double HorizontalOffset
        {
            get
            {
                int arrowPos = -(int)(PopupWitdh * 0.82) - 30;
                return arrowPos;

            }
        }
        /// <exclude>Excluded</exclude>
        double _PopupWitdh;
        public double PopupWitdh
        {
            get
            {

                return _PopupWitdh;
            }
            set
            {
                if (_PopupWitdh != value)
                {
                    //_PopupWitdh = value;
                    //_Path = null;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PathPoints)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PopupWitdh)));
                }
            }
        }

        /// <exclude>Excluded</exclude>
        double _PopupHeight;
        public double PopupHeight
        {
            get
            {
                return _PopupHeight;
            }
            set
            {
                if (_PopupHeight != value)
                {
                    //_PopupHeight = value;
                    //_Path = null;
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PathPoints)));
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PopupHeight)));
                }
            }
        }


        //private StateEnum _State;
        //public StateEnum State
        //{
        //    get
        //    {
        //        return _State;
        //    }
        //    set
        //    {
        //        var oldValue = State;
        //        _State = value;
        //        if (oldValue != value)
        //        {

        //            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(State)));
        //        }
        //    }
        //}

        public delegate void PageSizeChangedHandle(object sender, Size newSize);
        public event EventHandler PageLoaded;
        public event PropertyChangedEventHandler PropertyChanged;

        public event PageSizeChangedHandle PageSizeChanged;

        public event EventHandler SignedIn;
        public event EventHandler SignedOut;

        [OOAdvantech.MetaDataRepository.HttpVisible]
        public void OnPageLoaded()
        {
            PageLoaded?.Invoke(this, EventArgs.Empty);
        }

        bool cancelResize = false;

        [OOAdvantech.MetaDataRepository.HttpVisible]
        public void OnPageSizeChanged(double width, double height)
        {
            if (cancelResize)
                return;
            Task.Run(() =>
            {

                Size newSize = new Size(width, height);
                _PopupWitdh = width;
                _PopupHeight = height;
                //_Path=null;
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PathPoints)));
                if (!OnSignIn)
                    PageSizeChanged?.Invoke(this, newSize);
            });
        }

        class MessageData
        {
            public string Message;
        }
        ClientWebSocket webSocket = null;
        [OOAdvantech.MetaDataRepository.HttpVisible]
        public async void TogglePopupView()
        {
            SwitchOnOffPopupView?.Invoke(this, EventArgs.Empty);

            OnPageLoaded();



            MessmateAdded?.Invoke(this, "Liakos");


        }

        [OOAdvantech.MetaDataRepository.HttpVisible]
        public string GetValue(int age)
        {
            return "232K " + age.ToString();
        }

        [OOAdvantech.MetaDataRepository.HttpVisible]
        public void SetMessage(string message)
        {

        }



        string _ConfirmPassword;

        public string ConfirmPassword
        {
            get
            {
                return _ConfirmPassword;
            }

            set
            {
                _ConfirmPassword = value;
            }
        }

        string _Email;
        public string Email
        {
            get
            {
                return _Email;
            }

            set
            {
                _Email = value;
            }
        }

        string _FullName;
        public string FullName
        {
            get
            {
                return _FullName;
            }

            set
            {
                _FullName = value;
            }
        }

        string _Password;
        public string Password
        {
            get
            {
                return _Password;
            }

            set
            {
                _Password = value;
            }
        }

        string _Address;
        [OOAdvantech.MetaDataRepository.HttpVisible]
        public string Address
        {
            get
            {
                return _Address;
            }

            set
            {
                _Address = value;
            }
        }
        string _PhoneNumber;
        [OOAdvantech.MetaDataRepository.HttpVisible]
        public string PhoneNumber
        {
            get
            {
                return _PhoneNumber;
            }
            set
            {
                _PhoneNumber = value;
            }
        }

        public List<OrganizationStorageRef> GraphicMenus;

        public void GetOrgenizationRestMenus(IResourceManager organization)
        {

            GraphicMenus = organization.GraphicMenus;

            OrganizationStorageRef storageRef = organization.GetStorage(OrganizationStorages.RestaurantMenus);
            string appDataPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\Microneme";
            if (!System.IO.Directory.Exists(appDataPath))
                System.IO.Directory.CreateDirectory(appDataPath);
            appDataPath += "\\DontWaitWater";
            if (!System.IO.Directory.Exists(appDataPath))
                System.IO.Directory.CreateDirectory(appDataPath);
            string temporaryStorageLocation = appDataPath + string.Format("\\{0}RestaurantMenuData.xml", storageRef.StorageIdentity.Replace("-", ""));
            HttpClient httpClient = new HttpClient();
            var dataStreamTask = httpClient.GetStreamAsync(storageRef.StorageUrl);
            dataStreamTask.Wait();
            var dataStream = dataStreamTask.Result;
            RawStorageData storageData = new RawStorageData(XDocument.Load(dataStream), temporaryStorageLocation, storageRef, organization as IUploadService);

            BookViewModel.RestaurantMenus = new MenuItemsEditor.RestaurantMenus(storageData);

            MenuDesignerViewModel.MenuData=new RestaurantMenuItemsPresentation((BookViewModel.RestaurantMenus.Members[0] as MenuItemsEditor.ViewModel.MenuViewModel).Menu, null);

            OrganizationStorageRef styleSeetStorageRef = organization.GetStorage(OrganizationStorages.StyleSheets);
            temporaryStorageLocation = appDataPath + "\\StyleSheets.xml";
            RawStorageData styleSeetStorageData = new RawStorageData(temporaryStorageLocation, styleSeetStorageRef, null);
            var styleSeetObjectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.OpenStorage("StyleSheets", styleSeetStorageData, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider");
            MenuPresentationModel.MenuStyles.StyleSheet.ObjectStorage = styleSeetObjectStorage;


            OrganizationStorageRef backgroundImagesStorageRef = organization.GetStorage(OrganizationStorages.BackgroundImages);
            temporaryStorageLocation = appDataPath + "\\BackgroundImages.xml";
            RawStorageData backgroundImagesStorageData = new RawStorageData(temporaryStorageLocation, backgroundImagesStorageRef, null);
            var backgroundImagesObjectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.OpenStorage("BackgroundImages", backgroundImagesStorageData, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider");

            DateTime dateTimeNow = DateTime.UtcNow;

            MenuDesigner.ViewModel.BackgroundSelectionViewModel.BackgroundImagesStorage = backgroundImagesObjectStorage;

            OrganizationStorageRef bordersStorageRef = organization.GetStorage(OrganizationStorages.Borders);
            temporaryStorageLocation = appDataPath + "\\Borders.xml";
            RawStorageData bordersStorageData = new RawStorageData(temporaryStorageLocation, bordersStorageRef, null);
            var BordersObjectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.OpenStorage("Borders", bordersStorageData, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider");


            MenuDesigner.ViewModel.BorderSelectionViewModel.BordersStorage = BordersObjectStorage;


            OrganizationStorageRef headingAccentsStorageRef = organization.GetStorage(OrganizationStorages.HeadingAccents);
            temporaryStorageLocation = appDataPath + "\\HeadingAccents.xml";
            RawStorageData headingAccentsStorageData = new RawStorageData(temporaryStorageLocation, headingAccentsStorageRef, null);
            var headingAccentsObjectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.OpenStorage("HeadingAccents", headingAccentsStorageData, "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider");

            OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(headingAccentsObjectStorage);

            //using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
            //{
            //    foreach (var pageImage in (from pageImage in storage.GetObjectCollection<MenuPresentationModel.MenuStyles.MenuImage>()
            //                               select pageImage))
            //    {
            //        pageImage.Image = new MenuPresentationModel.MenuStyles.Resource() { Name = pageImage.Image.Name, Uri = pageImage.Image.Uri, TimeStamp = dateTimeNow };
            //        //  pageImage.PortraitImage = new MenuPresentationModel.MenuStyles.Resource() { Name = pageImage.PortraitImage.Name, Uri = pageImage.PortraitImage.Uri, TimeStamp = dateTimeNow };
            //    }
            //    stateTransition.Consistent = true;
            //}
            MenuDesigner.ViewModel.HeadingTypesAccentsViewModel.HeadingAccentStorage = headingAccentsObjectStorage;






            //MenuDesigner.ViewModel.HeadingTypesAccentsViewModel
            //HeadingAccents


        }
        [OOAdvantech.MetaDataRepository.HttpVisible]
        public void SignOut()
        {

            SignedOut?.Invoke(this, EventArgs.Empty);
        }

        //static string _AzureServerUrl = "http://localhost:8090/api/";
        //static string _AzureServerUrl = "http://192.168.2.4:8090/api/";
        //static string _AzureServerUrl = "http://192.168.2.15:8090/api/";
        //static string _AzureServerUrl = "http://10.0.0.14:8090/api/";
        static string _AzureServerUrl = "http://192.168.2.12:8090/api/";
        //static string _AzureServerUrl = "http://192.168.2.12:8090/api/";

        static string AzureServerUrl
        {
            get
            {
                string azureStorageUrl = OOAdvantech.Remoting.RestApi.RemotingServices.GetLocalIPAddress();
                if (azureStorageUrl == null)
                    azureStorageUrl = _AzureServerUrl;
                else
                    azureStorageUrl = "http://" + azureStorageUrl + ":8090/api/";

                return azureStorageUrl;
            }
        }


        [OOAdvantech.MetaDataRepository.HttpVisible]
        public IUser GetObj()
        {
            return this;
        }


        [OOAdvantech.MetaDataRepository.HttpVisible]
        public void SetObj(IUser user, IUser user2)
        {

        }

        public bool OnSignIn;
        [OOAdvantech.MetaDataRepository.HttpVisible]
        public async Task<bool> SignIn()
        {
            System.Diagnostics.Debug.WriteLine("public async Task< bool> SignIn()");
            AuthUser authUser = System.Runtime.Remoting.Messaging.CallContext.GetData("AutUser") as AuthUser;
            if (authUser == null)
            {

            }
            if (DeviceAuthentication.AuthUser == null)
            {

            }

            return await Task<bool>.Run(async () =>
             {
                 OnSignIn = true;
                 try
                 {

                     string assemblyData = "FlavourBusinessManager, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null";
                     string type = "FlavourBusinessManager.AuthFlavourBusiness";// typeof(FlavourBusinessManager.AuthFlavourBusiness).FullName;
                     System.Runtime.Remoting.Messaging.CallContext.SetData("AutUser", authUser);
                     string serverUrl = "http://localhost/FlavourBusinessWebApiRole/api/";
                     serverUrl = "http://localhost:8090/api/";
                     serverUrl = AzureServerUrl;
                     IAuthFlavourBusiness pAuthFlavourBusines = null;

                     try
                     {
                         pAuthFlavourBusines = OOAdvantech.Remoting.RestApi.RemotingServices.CreateRemoteInstance(serverUrl, type, assemblyData) as IAuthFlavourBusiness;
                     }
                     catch (System.Net.WebException error)
                     {
                         throw;
                     }
                     catch (Exception error)
                     {
                         throw;
                     }
                     WSHttpBinding sds = new WSHttpBinding();

                     //sds.SendTimeout
                     //OOAdvantech.Remoting.RestApi.RemotingServices.T

                     if (DeviceAuthentication.AuthUser == null)
                     {

                     }
                     var organization = pAuthFlavourBusines.SignIn();
                     Organization.CurrentOrganization = organization;

                     // organization.ObjectChangeState += Organization_ObjectChangeState;


                     if (organization == null)
                         return false;
                     else
                     {
                         _Address = organization.Address;
                         _PhoneNumber = organization.PhoneNumber;
                         await Task.Run(() =>
                        {
                            if (DeviceAuthentication.AuthUser == null)
                            {

                            }
                            //   organization.Address= _Address;
                            GetOrgenizationRestMenus(organization as IResourceManager);
                        });
                         OnSignIn = false;

                         SignedIn?.Invoke(this, EventArgs.Empty);
                         OnPageSizeChanged(_PopupWitdh, _PopupHeight);
                         return true;
                     }
                 }
                 catch (Exception error)
                 {

                     throw;
                 }
                 finally
                 {
                     OnSignIn = false;
                 }
             });

            //pAuthFlavourBusines.SignUpOwner(new OrganizationData() { Email = "jim.liakos@gmail.com", Name = "jim", Trademark = "Liakos" });




        }

        private void Organization_ObjectChangeState(object _object, string member)
        {
            if (_object is IOrganization)
            {
                var adr = (_object as IOrganization).Address;
            }

        }

        [OOAdvantech.MetaDataRepository.HttpVisible]
        public bool SignUp()
        {
            string assemblyData = "FlavourBusinessManager, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null";
            string type = "FlavourBusinessManager.AuthFlavourBusiness";// typeof(FlavourBusinessManager.AuthFlavourBusiness).FullName;
            AuthUser authUser = System.Runtime.Remoting.Messaging.CallContext.GetData("AutUser") as AuthUser;
            string serverUrl = "http://localhost/FlavourBusinessWebApiRole/api/";
            serverUrl = "http://localhost:8090/api/";
            serverUrl = AzureServerUrl;
            IAuthFlavourBusiness pAuthFlavourBusines = OOAdvantech.Remoting.RestApi.RemotingServices.CreateRemoteInstance(serverUrl, type, assemblyData) as IAuthFlavourBusiness;
            var organization = pAuthFlavourBusines.SignUpOwner(new OrganizationData() { Email = this.Email, FullName = this.FullName, Address = this.Address, PhoneNumber = this.PhoneNumber });
            Organization.CurrentOrganization = organization;
            return organization != null;

        }
        [OOAdvantech.MetaDataRepository.HttpVisible]
        public void SaveUserProfile()
        {
            Task<bool>.Run(() =>
            {
                string assemblyData = "FlavourBusinessManager, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null";
                string type = "FlavourBusinessManager.AuthFlavourBusiness";// typeof(FlavourBusinessManager.AuthFlavourBusiness).FullName;
                AuthUser authUser = System.Runtime.Remoting.Messaging.CallContext.GetData("AutUser") as AuthUser;
                string serverUrl = "http://localhost/FlavourBusinessWebApiRole/api/";
                serverUrl = "http://localhost:8090/api/";
                serverUrl = AzureServerUrl;
                IAuthFlavourBusiness pAuthFlavourBusines = OOAdvantech.Remoting.RestApi.RemotingServices.CreateRemoteInstance(serverUrl, type, assemblyData) as IAuthFlavourBusiness;
                pAuthFlavourBusines.UpdateUserProfile(new OrganizationData() { Email = this.Email, FullName = this.FullName, Address = this.Address, PhoneNumber = this.PhoneNumber });
            });
            //SwitchOnOffPopupView?.Invoke(this, EventArgs.Empty);

        }




        public string UserName
        {
            get
            {
                return ApplicationSettings.Current.SignInUserName;
            }
            set
            {
                ApplicationSettings.Current.SignInUserName = value;
            }
        }
        [OOAdvantech.MetaDataRepository.HttpVisible]
        public string UserIdentity
        {
            get
            {
                return ApplicationSettings.Current.SignInUserIdentity;
            }
            set
            {
                ApplicationSettings.Current.SignInUserIdentity = value;
            }
        }

        [OOAdvantech.MetaDataRepository.HttpVisible]
        public string SignInProvider
        {
            get
            {
                return ApplicationSettings.Current.SignInProvider;
            }
            set
            {
                ApplicationSettings.Current.SignInProvider = value;
            }
        }

        public Point ArrowOffset
        {
            get
            {
                System.Windows.Size size = new System.Windows.Size(PopupWitdh, PopupHeight);
                int xPos = (int)(size.Width * 0.82) + 10;

                return new Point(xPos, 0);
            }
        }

    }
}
