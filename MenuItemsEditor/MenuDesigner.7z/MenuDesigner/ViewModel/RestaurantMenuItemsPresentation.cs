﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MenuDesigner.ViewModel;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{4442d7e1-c1d6-4fca-abb7-5d89f7ca9d2c}</MetaDataID>
    public class RestaurantMenuItemsPresentation : MarshalByRefObject, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        MenuModel.IMenu Menu;

        /// <exclude>Excluded</exclude>
        MenuPresentationModel.RestaurantMenu _GraphicMenu;
        internal MenuPresentationModel.RestaurantMenu GraphicMenu
        {
            get
            {
                return _GraphicMenu;
            }
            set
            {
                _GraphicMenu = value;
                RootCategory.GraphicMenu = value;
            }
        }
        MenuDesigner.ViewModel.ItemsCategoryViewModel RootCategory;
        public RestaurantMenuItemsPresentation(MenuModel.IMenu menu, MenuPresentationModel.RestaurantMenu graphicMenu)
        {
            _GraphicMenu = graphicMenu;
            Menu = menu;
            RootCategory = new ItemsCategoryViewModel(Menu.RootCategory, null, graphicMenu);
            RootCategory.IsNodeExpanded = true;
            foreach (MenuItemsEditor.IMenusTreeNode treeNode in RootCategory.Members)
                treeNode.IsNodeExpanded = true;

            SelectedCommand = new WPFUIElementObjectBind.RelayCommand((object sender) =>
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ContextMenuItems)));
            });
        }
        public WPFUIElementObjectBind.RelayCommand SelectedCommand { get; protected set; }


        public List<MenuItemsEditor.IMenusTreeNode> MenuItems
        {
            get
            {
                return RootCategory.Members;
            }
        }

        List<WPFUIElementObjectBind.MenuComamnd> _ContextMenuItems;
        public List<WPFUIElementObjectBind.MenuComamnd> ContextMenuItems
        {
            get
            {
                var selectedItemContextMenuItems = RootCategory.SelectedItemContextMenuItems;
                if (selectedItemContextMenuItems != null)
                    return selectedItemContextMenuItems;
                else
                    return RootCategory.ContextMenuItems;
            }
        }
    }
}
