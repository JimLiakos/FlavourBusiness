﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using MenuPresentationModel;
using MenuPresentationModel.MenuCanvas;
using MenuPresentationModel.MenuStyles;
using OOAdvantech.Transactions;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{66b4d6f1-3f62-4582-bf36-ea366dd044e9}</MetaDataID>
    public class MenuHeadingViewModel : MarshalByRefObject
    {
        public readonly IMenuCanvasHeading MenuCanvasHeading;
        public readonly RestaurantMenu RestaurantMenu;

        public MenuHeadingViewModel(IMenuCanvasHeading menuCanvasHeading, RestaurantMenu restaurantMenu)
        {
            this.MenuCanvasHeading = menuCanvasHeading;
            this.RestaurantMenu = restaurantMenu;

            OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(DownloadStylesWindow.HeadingAccentStorage);
            var HeadingAccents = (from accent in storage.GetObjectCollection<MenuPresentationModel.MenuStyles.HeadingAccent>() select accent).ToList();

            _AccentImages = (from accent in HeadingAccents select new AccentViewModel(accent)).ToList();

            //using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
            //{
            //    foreach (var accentImage in _AccentImages)
            //    {
            //        var headingAccent = (from accent in storage.GetObjectCollection<MenuPresentationModel.MenuStyles.HeadingAccent>()
            //                             where accent.Name == accentImage.AccentImage.Image.Name
            //                             select accent).FirstOrDefault();
            //        if (headingAccent != null)
            //            headingAccent.SelectionAccentImageUri = accentImage.Uri;
            //        else
            //        {

            //        }

            //    } 
            //    stateTransition.Consistent = true;
            //}

            _AccentImages.Insert(0, new AccentViewModel(AccentViewModel.AccentViewModelType.StyleSheet));
            _AccentImages.Insert(0, new AccentViewModel(AccentViewModel.AccentViewModelType.None));
                _SelectedAccent = _AccentImages[1];



        }


        AccentViewModel _SelectedAccent;
       public AccentViewModel SelectedAccent
        {
            get
            {
                
                return _SelectedAccent;
            }
            set
            {
                _SelectedAccent = value;
            }
        }
        public string HeadingTitle
        {
            get
            {
                return MenuCanvasHeading.Description;
            }
            set
            {
                MenuCanvasHeading.Description = value; 

            }
        }

        List<AccentViewModel> _AccentImages;
        public List<AccentViewModel> AccentImages
        {
            get
            {
                return _AccentImages;
            }
        }

        public Uri ImageUri
        {
            get
            {
                if (MenuCanvasHeading.Page != null)
                    return new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/DocumentHeader.png");
                else
                    return new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/DocumentHeaderAdd.png");
            }
        }
    }

    public class AccentViewModel:MarshalByRefObject
    {
        public enum AccentViewModelType
        {
            None,
            StyleSheet,
            Image
        }

        AccentViewModelType AccentType;

       public readonly IHeadingAccent AccentImage;
        public AccentViewModel(IHeadingAccent accentImage)
        {
            AccentImage = accentImage;
            if(accentImage.AccentImages.Count>0)
                AccentType = AccentViewModelType.Image;
            else
                AccentType = AccentViewModelType.None;

        }
        public AccentViewModel(AccentViewModelType accentViewModelType)
        {
            if (accentViewModelType == AccentViewModelType.StyleSheet)
            {
                AccentType = AccentViewModelType.StyleSheet;
                _Description = "(Style)";
            }
            else
            {
                _Description = "(None)";
                AccentType = AccentViewModelType.None;
            }


            
        }

        /// <exclude>Excluded</exclude>
        string _Description;
        public string Description
        {
            get
            {
                return _Description;
            }
        }

        public Visibility  ImageVisibility
        {
            get
            {
                if (AccentType == AccentViewModelType.Image)
                    return Visibility.Visible;
                else
                    return Visibility.Collapsed;
            }
        }
        public Visibility TextVisibility
        {
            get
            {
                if (AccentType == AccentViewModelType.Image)
                    return Visibility.Collapsed;
                else
                    return Visibility.Visible;
            }
        }

        public string Uri
        {
            get
            {
                if (AccentImage != null)
                    return AccentImage.SelectionAccentImageUri;
                else
                    return "";
            }
        }
    }

}
