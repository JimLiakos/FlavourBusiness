﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using MenuPresentationModel;
using MenuPresentationModel.MenuCanvas;
using OOAdvantech.Transactions;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{a0b00e06-a3ba-4803-9098-95d6f4382670}</MetaDataID>
    public class FoodItemViewModel:MarshalByRefObject
    {
        private IMenuCanvasFoodItem MenuCanvasFoodItem;
        private RestaurantMenu GraphicMenu;

        public WPFUIElementObjectBind.RelayCommand MenuItemDetailsCommand { get; protected set; }

        public FoodItemViewModel(IMenuCanvasFoodItem menuCanvasFoodItem, RestaurantMenu graphicMenu)
        {
            MenuCanvasFoodItem = menuCanvasFoodItem;
            GraphicMenu = graphicMenu;


            MenuItemDetailsCommand = new WPFUIElementObjectBind.RelayCommand((object sender) =>
            {
                Window owner = System.Windows.Window.GetWindow(MenuItemDetailsCommand.UserInterfaceObjectConnection.ContainerControl as System.Windows.DependencyObject);

                using (SystemStateTransition suppressStateTransition = new SystemStateTransition(TransactionOption.Suppress))
                {
                    using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Required))
                    {
                    
                        var menuItemWindow = new MenuItemsEditor.Views.MenuItemWindow();
                        menuItemWindow.Owner = owner;


                        MenuItemsEditor.ViewModel.MenuItemViewModel menuItemViewModel = new MenuItemsEditor.ViewModel.MenuItemViewModel(MenuCanvasFoodItem.MenuItem);
                        menuItemWindow.GetObjectContext().SetContextInstance(menuItemViewModel);
                        if (menuItemWindow.ShowDialog().Value)
                            stateTransition.Consistent = true;
                    }
                }

                //if (SelectedMenuType != MenuItem.DedicatedType)
                //    MenuItem.RemoveType(SelectedMenuType);
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MenuItemTypes)));
            });

        }
        public string Title
        {
            get
            {
                return MenuCanvasFoodItem.Description;
            }
            set
            {
                if (MenuCanvasFoodItem.Description != value)
                {
                    MenuCanvasFoodItem.Description = value;
                    CommitTransientMenuCanvasFoodItem();
                }
            }
        }

        private void CommitTransientMenuCanvasFoodItem()
        {
            var objectStorage = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(MenuCanvasFoodItem);
            if(objectStorage==null)
                objectStorage.CommitTransientObjectState(MenuCanvasFoodItem);
        }

        public string Description
        {
            get
            {
                return MenuCanvasFoodItem.ExtraDescription;
            }
            set
            {
                if (MenuCanvasFoodItem.ExtraDescription != value)
                {
                    MenuCanvasFoodItem.ExtraDescription = value;
                    CommitTransientMenuCanvasFoodItem();
                }
            }
        }

        public string Extras
        {
            get
            {
                return MenuCanvasFoodItem.Extras;
            }
            set
            {
                if (MenuCanvasFoodItem.Extras != value)
                {
                    MenuCanvasFoodItem.Extras = value;
                    CommitTransientMenuCanvasFoodItem();
                }
            }
        }
    }
}
