﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Linq;
using FlavourBusinessFacade;
using FlavourBusinessToolKit;
using OOAdvantech.Transactions;
using WPFUIElementObjectBind;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{053cbc90-bd7f-4bd7-af0e-104817d2b971}</MetaDataID>
    class GraphicMenuTreeNode : FBResourceTreeNode, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public readonly OrganizationStorageRef GraphicMenuStorageRef;

        public GraphicMenuTreeNode(OrganizationStorageRef graphicMenuStorageRef, FBResourceTreeNode parent) : base(parent)
        {

            GraphicMenuStorageRef = graphicMenuStorageRef;
            DeleteCommand = new RelayCommand((object sender) =>
            {
                Delete();
            });
            RenameCommand = new RelayCommand((object sender) =>
            {
                EditMode();

                //Delete();
            });


            DesigneCommand = new RelayCommand((object sender) =>
            {
                SowOnGrpaphicMenuDesigner();

                //Delete();
            });
            if (HeaderNode is CompanyPresentation)
            {
                List<GraphicMenuTreeNode> graphicStorageReferences = null;
                if (!(HeaderNode as CompanyPresentation).GraphicStorageReferences.TryGetValue(GraphicMenuStorageRef.StorageIdentity, out graphicStorageReferences))
                {
                    graphicStorageReferences = new List<GraphicMenuTreeNode>();
                    graphicStorageReferences.Add(this);
                    (HeaderNode as CompanyPresentation).GraphicStorageReferences[GraphicMenuStorageRef.StorageIdentity] = graphicStorageReferences;
                }
                else
                {
                    graphicStorageReferences.Add(this);
                }

            }
        }

        private async void SowOnGrpaphicMenuDesigner()
        {

            if (FlavourBusinessManagerViewModel.Current != null)
            {
                FlavourBusinessManagerViewModel.Current.HallLayoutVisibility = Visibility.Hidden;
                FlavourBusinessManagerViewModel.Current.MenuDesignerVisibility = Visibility.Visible;

                string storageIdentity = null;
                if(FlavourBusinessManagerViewModel.Current.Menu!=null&& FlavourBusinessManagerViewModel.Current.Menu.RealObject!=null)
                {
                    if (OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(FlavourBusinessManagerViewModel.Current.Menu.RealObject) != null)
                        storageIdentity = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(FlavourBusinessManagerViewModel.Current.Menu.RealObject).StorageMetaData.StorageIdentity;
                }
                if (storageIdentity != GraphicMenuStorageRef.StorageIdentity)
                {
                    string appDataPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\Microneme";
                    if (!System.IO.Directory.Exists(appDataPath))
                        System.IO.Directory.CreateDirectory(appDataPath);
                    appDataPath += "\\DontWaitWater";
                    if (!System.IO.Directory.Exists(appDataPath))
                        System.IO.Directory.CreateDirectory(appDataPath);
                    string temporaryStorageLocation = appDataPath + string.Format("\\{0}RestaurantMenuData.xml", GraphicMenuStorageRef.StorageIdentity.Replace("-", ""));
                    HttpClient httpClient = new HttpClient();
                    var transaction = OOAdvantech.Transactions.Transaction.Current;

                    var dataStream = await httpClient.GetStreamAsync(GraphicMenuStorageRef.StorageUrl);
                    using (SystemStateTransition stateTransition = new SystemStateTransition(transaction))
                    {
                        RawStorageData storageData = new RawStorageData(XDocument.Load(dataStream), temporaryStorageLocation, GraphicMenuStorageRef, FlavourBusinessManager.Organization.CurrentOrganization as FlavourBusinessFacade.IUploadService);
                        FlavourBusinessManagerViewModel.Current.Menu = BookViewModel.OpenMenu(storageData);
                        stateTransition.Consistent = true;
                    }
                }
            }

        }

        public override bool IsEditable
        {
            get
            {
                if (this.Parent.Parent is CompanyPresentation)
                    return true;
                return false;

            }
        }
        public void EditMode()
        {
            if (_Edit == true)
            {
                _Edit = !_Edit;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Edit)));
            }
            _Edit = true;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Edit)));
        }


        private void Delete()
        {

            List<GraphicMenuTreeNode> graphicStorageReferences = null;
            if ((HeaderNode as CompanyPresentation).GraphicStorageReferences.TryGetValue(GraphicMenuStorageRef.StorageIdentity, out graphicStorageReferences))
                graphicStorageReferences.Remove(this);


                if (Parent is FlavoursServicesContextPresentation)
                (Parent as FlavoursServicesContextPresentation).RemoveGraphicMenu(GraphicMenuStorageRef);

            if (Parent != null && Parent.Parent is FlavoursServicesContextPresentation)
                (Parent.Parent as FlavoursServicesContextPresentation).RemoveGraphicMenu(GraphicMenuStorageRef);


        }
        public RelayCommand RenameCommand { get; protected set; }

        public RelayCommand DeleteCommand { get; protected set; }

        public RelayCommand DesigneCommand { get; protected set; }

        /// <exclude>Excluded</exclude>
        List<MenuComamnd> _ContextMenuItems;
        public override List<MenuComamnd> ContextMenuItems
        {
            get
            {

                if (_ContextMenuItems == null)
                {

                    _ContextMenuItems = new List<MenuComamnd>();

                    var imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Empty.png"));
                    var emptyImage = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };

                    MenuComamnd menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Rename16.png"));
                    menuItem.Header = MenuItemsEditor.Properties.Resources.TreeNodeRenameMenuItemHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = RenameCommand;
                    _ContextMenuItems.Add(menuItem);


                    //_ContextMenuItems.Add(null);



                    menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/sketch16.png"));
                    menuItem.Header = Properties.Resources.DesignGraphicMenuContextHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = DesigneCommand;
                    _ContextMenuItems.Add(menuItem);

                    _ContextMenuItems.Add(null);

                    menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/delete.png"));
                    menuItem.Header = Properties.Resources.RemoveGraphicMenuContextHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = DeleteCommand;

                    if (!(this.Parent.Parent is CompanyPresentation))
                        _ContextMenuItems.Add(menuItem);






                }

                return _ContextMenuItems;
            }
        }



        public override bool HasContextMenu
        {
            get
            {


                return true;
            }
        }




        public override List<FBResourceTreeNode> Members
        {
            get
            {
                return new List<FBResourceTreeNode>();
            }
        }

        public override string Name
        {
            get
            {
                return GraphicMenuStorageRef.Name;
            }

            set
            {
                if (GraphicMenuStorageRef.Name != value)
                {
                    string oldName = GraphicMenuStorageRef.Name;

                    GraphicMenuStorageRef.Name = value;
                    SetOtherGraphicTreeNodesName(value);
                    if (this.Parent.Parent is CompanyPresentation)
                    {
                        OrganizationStorageRef storageRef = null;
                        try
                        {
                            storageRef = (FlavourBusinessManager.Organization.CurrentOrganization as FlavourBusinessFacade.IResourceManager).UpdateStorage(GraphicMenuStorageRef.Name, GraphicMenuStorageRef.Description, GraphicMenuStorageRef.StorageIdentity);
                        }
                        catch (Exception error)
                        {
                            Task.Run(() =>
                            {
                                GraphicMenuStorageRef.Name = oldName;
                                SetOtherGraphicTreeNodesName(oldName);
                                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Name)));
                            });
                            return;
                        }

                        GraphicMenuStorageRef.StorageUrl = storageRef.StorageUrl;
                        GraphicMenuStorageRef.Name = storageRef.Name;
                        GraphicMenuStorageRef.TimeStamp = storageRef.TimeStamp;
                        GraphicMenuStorageRef.StorageIdentity = storageRef.StorageIdentity;
                        GraphicMenuStorageRef.Name = storageRef.Name;
                    }
                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Name)));

                }
            }
        }

        private void SetOtherGraphicTreeNodesName(string name)
        {
            if (HeaderNode is CompanyPresentation)
            {
                List<GraphicMenuTreeNode> graphicStorageReferences = null;
                if ((HeaderNode as CompanyPresentation).GraphicStorageReferences.TryGetValue(GraphicMenuStorageRef.StorageIdentity, out graphicStorageReferences))
                {
                    foreach (GraphicMenuTreeNode graphicMenuTreeNode in graphicStorageReferences)
                    {
                        if (graphicMenuTreeNode != this)
                            graphicMenuTreeNode.Name = name;
                    }
                }
            }
        }

        public override List<MenuComamnd> SelectedItemContextMenuItems
        {
            get
            {
                if (IsSelected)
                    return ContextMenuItems;
                else
                    foreach (var treeNode in Members)
                    {
                        var contextMenuItems = treeNode.SelectedItemContextMenuItems;
                        if (contextMenuItems != null)
                            return contextMenuItems;
                    }

                return null;
            }
        }

        public override ImageSource TreeImage
        {
            get
            {
                return new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/Menu.png"));
            }
        }

        public override void SelectionChange()
        {
        }
    }
}
