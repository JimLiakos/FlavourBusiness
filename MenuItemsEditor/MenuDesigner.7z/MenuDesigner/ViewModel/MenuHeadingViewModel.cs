﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using MenuPresentationModel;
using MenuPresentationModel.MenuCanvas;
using MenuPresentationModel.MenuStyles;
using OOAdvantech.Transactions;
using SharpVectors.Converters;
using SharpVectors.Renderers.Wpf;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{66b4d6f1-3f62-4582-bf36-ea366dd044e9}</MetaDataID>
    public class MenuHeadingViewModel : MarshalByRefObject
    {
        public readonly IMenuCanvasHeading MenuCanvasHeading;
        public readonly RestaurantMenu RestaurantMenu;

        public MenuHeadingViewModel(IMenuCanvasHeading menuCanvasHeading, RestaurantMenu restaurantMenu)
        {
            this.MenuCanvasHeading = menuCanvasHeading;
            this.RestaurantMenu = restaurantMenu;

            OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(DownloadStylesWindow.HeadingAccentStorage);
            var HeadingAccents = (from accent in storage.GetObjectCollection<MenuPresentationModel.MenuStyles.HeadingAccent>() select accent).ToList();


            //AccentImage
            _AccentImages = (from accent in HeadingAccents select new AccentViewModel(accent)).ToList();

            //using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiresNew))
            //{
            //    foreach (var accentImage in MenuPresentationModel.MenuStyles.AccentImage.AvailableAccents)
            //    {
            //        var headingAccent = (from accent in storage.GetObjectCollection<MenuPresentationModel.MenuStyles.HeadingAccent>()
            //                             where accent.Name == accentImage.Image.Name
            //                             select accent).FirstOrDefault();
            //        if (headingAccent != null)
            //            headingAccent.SelectionAccentImageUri = accentImage.Uri;
            //        else
            //        {

            //        }

            //    }
            //    stateTransition.Consistent = true;
            //}

            _AccentImages.Insert(0, new AccentViewModel(AccentViewModel.AccentViewModelType.StyleSheet));
            _AccentImages.Insert(0, new AccentViewModel(AccentViewModel.AccentViewModelType.None));
            _SelectedAccent = _AccentImages[1];
        }


        AccentViewModel _SelectedAccent;
        public AccentViewModel SelectedAccent
        {
            get
            {

                return _SelectedAccent;
            }
            set
            {
                _SelectedAccent = value;
                MenuCanvasHeading.Accent = new MenuCanvasHeadingAccent(MenuCanvasHeading, value.Accent);
            }
        }
        public string HeadingTitle
        {
            get
            {
                return MenuCanvasHeading.Description;
            }
            set
            {
                MenuCanvasHeading.Description = value;

            }
        }

        List<AccentViewModel> _AccentImages;
        public List<AccentViewModel> AccentImages
        {
            get
            {
                return _AccentImages;
            }
        }

        public Uri ImageUri
        {
            get
            {
                if (MenuCanvasHeading.Page != null)
                    return new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/DocumentHeader.png");
                else
                    return new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/DocumentHeaderAdd.png");
            }
        }


        public bool NextColumnOrPage
        {
            get
            {
                return MenuCanvasHeading.NextColumnOrPage;
            }
            set
            {
                MenuCanvasHeading.NextColumnOrPage = value;
            }
        }

        /// <exclude>Excluded</exclude>
        List<int> _ColumnsNums = new List<int>() { 1, 2, 3, 4, 5, 6, 7 };
        public List<int> ColumnsNums
        {
            get
            {
                return _ColumnsNums;
            }
        }

        /// <exclude>Excluded</exclude>
        int _SelectedNumOfColumns = 1;

        public int SelectedNumOfColumns
        {
            get
            {
                return MenuCanvasHeading.NumberOfFoodColumns;
            }
            set
            {
                MenuCanvasHeading.NumberOfFoodColumns = value;
               // UpdateColumnsWidths();
            }
        }

    }

    /// <MetaDataID>{60394389-e18b-4ab8-8f34-eaf5fb06df0b}</MetaDataID>
    public class AccentViewModel : MarshalByRefObject
    {
        public enum AccentViewModelType
        {
            None,
            StyleSheet,
            Image
        }

        AccentViewModelType AccentType;
        public AccentViewModel()
        {

        }


        public readonly IHeadingAccent Accent;
        public AccentViewModel(IHeadingAccent accent)
        {
            Accent = accent;
            if (accent.AccentImages.Count > 0)
                AccentType = AccentViewModelType.Image;
            else
                AccentType = AccentViewModelType.None;

        }
        public AccentViewModel(AccentViewModelType accentViewModelType)
        {
            if (accentViewModelType == AccentViewModelType.StyleSheet)
            {
                AccentType = AccentViewModelType.StyleSheet;
                _Description = "(Style)";
            }
            else
            {
                _Description = "(None)";
                AccentType = AccentViewModelType.None;
            }



        }



        /// <exclude>Excluded</exclude>
        string _Description;
        public string Description
        {
            get
            {
                return _Description;
            }
        }

        public Visibility ImageVisibility
        {
            get
            {
                if (AccentType == AccentViewModelType.Image)
                    return Visibility.Visible;
                else
                    return Visibility.Collapsed;
            }
        }
        public Visibility TextVisibility
        {
            get
            {
                if (AccentType == AccentViewModelType.Image)
                    return Visibility.Collapsed;
                else
                    return Visibility.Visible;
            }
        }

        public string Uri
        {
            get
            {
                if (Accent != null)
                    return Accent.SelectionAccentImageUri;
                else
                    return "";
            }
        }

        static Dictionary<string, byte[]> SvgStreams = new Dictionary<string, byte[]>();
        static Dictionary<string, DrawingGroup> SvgDrawings = new Dictionary<string, DrawingGroup>();

        public Stream Stream
        {
            get
            {
                if (Accent == null || string.IsNullOrWhiteSpace(Accent.SelectionAccentImageUri))
                    return null;


                byte[] bytes = null;
                if (!SvgStreams.TryGetValue(Accent.SelectionAccentImageUri, out bytes))
                {
                    MemoryStream ms = new MemoryStream();
                    using (FileStream file = new FileStream(HeadingAccent.ResourcesRootPath+Accent.SelectionAccentImageUri, FileMode.Open, System.IO.FileAccess.Read))
                    {
                        bytes = new byte[file.Length];
                        file.Read(bytes, 0, (int)file.Length);
                        SvgStreams[Accent.SelectionAccentImageUri] = bytes;
                        ms.Write(bytes, 0, (int)file.Length);
                        ms.Position = 0;
                        return ms;
                    }
                }
                else
                {
                    MemoryStream ms = new MemoryStream();
                    ms.Write(bytes, 0, (int)bytes.Length);
                    ms.Position = 0;
                    return ms;
                }

            }
        }


        public DrawingGroup Drawing
        {
            get
            {
                if (Accent == null || string.IsNullOrWhiteSpace(Accent.SelectionAccentImageUri))
                    return null;


                DrawingGroup drawing = null;
                if (!SvgDrawings.TryGetValue(Accent.SelectionAccentImageUri, out drawing))
                {
                    MemoryStream ms = new MemoryStream();
                    using (FileStream file = new FileStream(MenuPresentationModel.MenuStyles.HeadingAccent.ResourcesRootPath+ Accent.SelectionAccentImageUri, FileMode.Open, System.IO.FileAccess.Read))
                    {
                        byte[] bytes = new byte[file.Length];
                        file.Read(bytes, 0, (int)file.Length);
                        SvgStreams[Accent.SelectionAccentImageUri] = bytes;
                        ms.Write(bytes, 0, (int)file.Length);
                        ms.Position = 0;

                    }

                    bool _textAsGeometry = false;
                    bool _includeRuntime = true;
                    bool _optimizePath = true;

                    WpfDrawingSettings settings = new WpfDrawingSettings();
                    settings.IncludeRuntime = _includeRuntime;
                    settings.TextAsGeometry = _textAsGeometry;
                    settings.OptimizePath = _optimizePath;
                    ////  if (_culture != null)
                    //      settings.CultureInfo = _culture;

                    using (FileSvgReader reader =
                              new FileSvgReader(settings))
                    {
                        drawing = reader.Read(ms);
                    }
                    SvgDrawings[Accent.SelectionAccentImageUri] = drawing;

                }
                return drawing;
            }
        }

    }
}


