﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using MenuPresentationModel.MenuCanvas;
using OOAdvantech.Transactions;
using UIBaseEx;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{dc87d504-e2a8-4e94-b400-fdf9a6ff7027}</MetaDataID>
    [Transactional]
    public class MenuCanvasItemViewModel : MarshalByRefObject, ICanvasItem, INotifyPropertyChanged
    {
        /// <MetaDataID>{312c21d3-16f3-4493-af7f-ffe6692500df}</MetaDataID>
        internal IMenuCanvasItem MenuCanvasItem;

        public event PropertyChangedEventHandler PropertyChanged;

        Visibility _Visibility;
        public Visibility Visibility
        {
            get
            {
                return _Visibility;
            }
            set
            {
                if (_Visibility != value)
                {

                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _Visibility = value; 
                        stateTransition.Consistent = true;
                    }

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Visibility)));
                }
            }
        }

        ///// <exclude>Excluded</exclude>
        //bool _DragDropOn;
        //public bool DragDropOn
        //{
        //    get
        //    {
        //        return _DragDropOn;
        //    }
        //    set
        //    {
        //        _DragDropOn = value;
        //        IsHitTestVisible = !_DragDropOn;
        //    }
        //}

        public System.Windows.HorizontalAlignment MenuItemAlignment
        {
            get
            {
                if (MenuCanvasItem is MenuPresentationModel.MenuCanvas.IMenuCanvasHeading)
                {
                    if ((MenuCanvasItem as MenuPresentationModel.MenuCanvas.IMenuCanvasHeading).Style.Alignment == MenuPresentationModel.MenuStyles.Alignment.Center)
                        return System.Windows.HorizontalAlignment.Center;

                    if ((MenuCanvasItem as MenuPresentationModel.MenuCanvas.IMenuCanvasHeading).Style.Alignment == MenuPresentationModel.MenuStyles.Alignment.Left)
                        return System.Windows.HorizontalAlignment.Left;

                    if ((MenuCanvasItem as MenuPresentationModel.MenuCanvas.IMenuCanvasHeading).Style.Alignment == MenuPresentationModel.MenuStyles.Alignment.Right)
                        return System.Windows.HorizontalAlignment.Right;
                }

                return System.Windows.HorizontalAlignment.Center;
            }
        }

        ///// <exclude>Excluded</exclude>
        //bool _IsHitTestVisible;
        //public bool IsHitTestVisible
        //{
        //    get
        //    {
        //        return _IsHitTestVisible;
        //    }
        //    set
        //    {
        //        _IsHitTestVisible = value;
        //        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsHitTestVisible)));
        //    }
        //}


        /// <MetaDataID>{bad63ab7-e239-4689-a8a5-f60978a4d0f8}</MetaDataID>
        public MenuCanvasItemViewModel(MenuPresentationModel.MenuCanvas.IMenuCanvasItem menuCanvasItem)
        {
            MenuCanvasItem = menuCanvasItem;
            Visibility = Visibility.Visible;
            UpdateCanvasItemValues();
            if (MenuCanvasItem is MenuCanvasFoodItem)
                (MenuCanvasItem as MenuCanvasFoodItem).ObjectChangeState += ObjectChangeState;

        }

        private void ObjectChangeState(object _object, string member)
        {

            if (member == nameof(IMenuCanvasItem.Description))
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Text)));
        }

        CanvasFrameViewModel _MenuCanvasItemFrame;
        public CanvasFrameViewModel MenuCanvasItemFrame
        {
            get
            {
                //if (_MenuCanvasItemFrame == null)
                //    _MenuCanvasItemFrame = new CanvasFrameViewModel(MenuCanvasItem);

                return _MenuCanvasItemFrame;
            }
        }
        public void ChangeCanvasItem(MenuPresentationModel.MenuCanvas.IMenuCanvasItem menuCanvasItem)
        {
            if (MenuCanvasItem != menuCanvasItem)
            {
                if (MenuCanvasItem is MenuCanvasFoodItem)
                    (MenuCanvasItem as MenuCanvasFoodItem).ObjectChangeState -= ObjectChangeState;

                MenuCanvasItem = menuCanvasItem;
                if (MenuCanvasItem is MenuCanvasFoodItem)
                    (MenuCanvasItem as MenuCanvasFoodItem).ObjectChangeState += ObjectChangeState;

                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Visibility)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Text)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Left)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Top)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Height)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Width)));
                ////PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Font)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Foreground)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontFamily)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontStyle)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontWeight)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(StrokeThickness)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(AllCaps)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(StrokeFill)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DropShadowEffect)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Overline)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Underline)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontSize)));
                //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontSpacing)));

                UpdateCanvasItemValues();
            }

        }

        private void UpdateCanvasItemValues()
        {
            if (_Top != this.MenuCanvasItem.YPos)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _Top = this.MenuCanvasItem.YPos; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Top)));
            }
            if (_Left != MenuCanvasItem.XPos)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _Left = MenuCanvasItem.XPos; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Left)));
            }

            if (MenuCanvasItem.Font.AllCaps)
            {
                if (_Text != MenuCanvasItem.Description.ToUpper())
                {

                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _Text = MenuCanvasItem.Description.ToUpper(); 
                        stateTransition.Consistent = true;
                    }

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Text)));
                }
            }
            else
            {
                if (_Text != MenuCanvasItem.Description)
                {

                    using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                    {
                        _Text = MenuCanvasItem.Description; 
                        stateTransition.Consistent = true;
                    }

                    PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Text)));
                }
            }

            FontFamily fontFamily = null;
            if (Font != null)
                fontFamily = FontData.FontFamilies[Font.Value.FontFamilyName];
            else
                fontFamily = null;

            if (fontFamily != _FontFamily)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontFamily = fontFamily; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontFamily)));
            }

            FontStyle fontStyle = default(FontStyle);

            if (Font != null)
                fontStyle = (FontStyle)new FontStyleConverter().ConvertFromString(Font.Value.FontStyle);
            else
                fontStyle = default(FontStyle);
            if (fontStyle != _FontStyle)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontStyle = fontStyle; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontStyle)));
            }

            FontWeight fontWeight = default(FontWeight);
            if (Font != null)
                fontWeight = (FontWeight)new FontWeightConverter().ConvertFromString(Font.Value.FontWeight);
            else
                fontWeight = default(FontWeight);

            if (fontWeight != _FontWeight)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontWeight = fontWeight; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontWeight)));

            }

            double strokeThickness = 0;
            if (Font != null && Font.Value.Stroke)
                strokeThickness = Font.Value.StrokeThickness;
            else
                strokeThickness = 0;

            if (strokeThickness != _StrokeThickness)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _StrokeThickness = strokeThickness; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(StrokeThickness)));
            }

            bool allCaps = false;
            if (Font != null)
                allCaps = Font.Value.AllCaps;
            else
                allCaps = false;

            if(allCaps!=_AllCaps)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _AllCaps = allCaps; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(AllCaps)));
            }

            Color strokeFill = default(Color);

            if (Font != null)
            {
                if (Font.Value.StrokeFill != null && Font.Value.Stroke)
                    strokeFill = (Color)ColorConverter.ConvertFromString(Font.Value.StrokeFill);
                else
                    strokeFill = _Foreground;
            }
            else
                strokeFill = _Foreground;

            if (strokeFill!=_StrokeFill)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _StrokeFill = strokeFill; 
                    stateTransition.Consistent = true;
                }

                _StrokeFillBrush =new SolidColorBrush( strokeFill);
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(StrokeFill)));
            }


            System.Windows.Media.Effects.DropShadowEffect dropShadowEffect = null;

            if (Font != null)
            {
                double deltaX = Font.Value.ShadowXOffset;
                double deltaY = Font.Value.ShadowXOffset;

                if (Font.Value.ShadowColor == null && deltaX == 0 && deltaY == 0)
                    dropShadowEffect = null;
                else
                {

                    deltaY = -deltaY;
                    var rad = Math.Atan2(deltaY, deltaX);

                    var deg = rad * (180 / Math.PI);

                    if (deg < 0)
                        deg = 360 + deg;

                    double a = deltaX;
                    double b = deltaY;
                    if (a < 0)
                        a = -a;
                    if (b < 0)
                        b = -b;
                    double depth = Math.Sqrt(a * a + b * b);

                    var shaddow = new System.Windows.Media.Effects.DropShadowEffect();
                    shaddow.Direction = deg;
                    shaddow.ShadowDepth = depth;

                    shaddow.Opacity = 1;
                    shaddow.BlurRadius = Font.Value.BlurRadius;
                    shaddow.Color = (Color)ColorConverter.ConvertFromString(Font.Value.ShadowColor);
                    dropShadowEffect = shaddow;
                }
            }
            else
                dropShadowEffect = null;

            if(dropShadowEffect!=_DropShadowEffect)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _DropShadowEffect = dropShadowEffect; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DropShadowEffect)));
            }

            Color foreground = default(Color);

            if (Font != null)
                foreground = (Color)ColorConverter.ConvertFromString(Font.Value.Foreground);
            else
                foreground = default(Color);

            if(foreground!=_Foreground)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _Foreground = foreground;
                    _ForegroundBrush = new SolidColorBrush(foreground);

                    stateTransition.Consistent = true;
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Foreground)));
            }

            double fontSize = 0;
            if (Font != null)
                fontSize = Font.Value.FontSize;
            else
                fontSize = 0;

            if (fontSize!=_FontSize)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontSize = fontSize; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontSize)));
            }

            double fontSpacing = 0;
            if (Font != null)
                fontSpacing = Font.Value.FontSpacing;
            else
                fontSpacing = 0;

            if (fontSpacing!=_FontSpacing)
            {

                using (ObjectStateTransition stateTransition = new ObjectStateTransition(this))
                {
                    _FontSpacing = fontSpacing; 
                    stateTransition.Consistent = true;
                }

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FontSpacing)));
            }
        }

        /// <exclude>Excluded</exclude>
        double _Top;
        /// <MetaDataID>{fdf0ff7d-ec50-402d-967e-ed9699e53281}</MetaDataID>
        public double Top
        {
            get
            {
                return _Top;
            }
        }
        /// <exclude>Excluded</exclude>
        double _Left;
        /// <MetaDataID>{c591ecc0-f544-4fcf-9440-8176db2484ba}</MetaDataID>
        public double Left
        {
            get
            {
                return _Left;
            }
        }
        /// <exclude>Excluded</exclude> 
        string _Text;
        /// <MetaDataID>{09379650-7810-4b92-bdd1-c4b6a0e287db}</MetaDataID>
        public string Text
        {
            get
            {
                return _Text;
            }
        }

        /// <exclude>Excluded</exclude>
        System.Windows.Media.FontFamily _FontFamily;
        /// <MetaDataID>{55ca289c-24b5-4ace-843c-ef0199a69411}</MetaDataID>
        public System.Windows.Media.FontFamily FontFamily
        {
            get
            {
                return _FontFamily;

            }
        }

        /// <exclude>Excluded</exclude>
        FontStyle _FontStyle;
        /// <MetaDataID>{b9f2f208-7f90-4a42-9bc5-c8a8c780147e}</MetaDataID>
        public FontStyle FontStyle
        {
            get
            {
                return _FontStyle;

            }
        }

        /// <exclude>Excluded</exclude>
        FontWeight _FontWeight;
        /// <MetaDataID>{c88a77b9-fcbe-4bb6-9f4b-bf81f2fe6b3e}</MetaDataID>
        public FontWeight FontWeight
        {
            get
            {
                return _FontWeight;
            }
        }
        /// <exclude>Excluded</exclude>
        double _StrokeThickness;
        public double StrokeThickness
        {
            get
            {
                return _StrokeThickness;
            }
        }
        /// <exclude>Excluded</exclude>
        bool _AllCaps;
        public bool AllCaps
        {
            get
            {
                return _AllCaps;
            }
        }

        /// <exclude>Excluded</exclude>
        Color _StrokeFill;
        Brush _StrokeFillBrush;
        public Brush StrokeFill
        {
            get
            {
                return _StrokeFillBrush;
            }
        }

        public FontData? Font
        {
            get
            {
                return MenuCanvasItem.Font;
                //if (MenuCanvasItem is IMenuCanvasHeading)
                //    return (MenuCanvasItem as IMenuCanvasHeading).Font;
                //if (MenuCanvasItem is IMenuCanvasFoodItem)
                //    return (MenuCanvasItem as IMenuCanvasFoodItem).Font;
                //if (MenuCanvasItem is IMenuCanvasFoodItemPrice)
                //    return (MenuCanvasItem as IMenuCanvasFoodItemPrice).Font;

                //if (MenuCanvasItem is IMenuCanvasPriceLeader )
                //    return (MenuCanvasItem as IMenuCanvasPriceLeader).Font;


                //return null;
            }
        }

        /// <exclude>Excluded</exclude>
        System.Windows.Media.Effects.DropShadowEffect _DropShadowEffect;
        public System.Windows.Media.Effects.DropShadowEffect DropShadowEffect
        {
            get
            {
                return _DropShadowEffect;
            }
        }

        /// <exclude>Excluded</exclude>
        Color _Foreground;

        /// <exclude>Excluded</exclude>
        Brush _ForegroundBrush;

        /// <MetaDataID>{47626bc6-45e7-4c24-ba13-ac1112bc0345}</MetaDataID>
        public Brush Foreground
        {
            get
            {
                return _ForegroundBrush;
            }
        }

        public bool Overline
        {
            get
            {
                return false;
            }
        }
        public bool Underline
        {
            get
            {
                return false;
            }
        }

        /// <exclude>Excluded</exclude>
        double _FontSize;
        /// <MetaDataID>{e6273d48-ed55-4313-9ee7-8803ba40ecd1}</MetaDataID>
        public double FontSize
        {
            get
            {
                return _FontSize;

            }
        }

        /// <exclude>Excluded</exclude>
        double _FontSpacing;
        public double FontSpacing
        {
            get
            {
                return _FontSpacing;
            }
        }

        public double Height
        {
            get
            {
                return 0;
            }
        }

        public double Width
        {
            get
            {
                return 0;
            }
        }

        internal void Refresh()
        {
            UpdateCanvasItemValues();
        }

        public void Release()
        {

        }
    }
}
