﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using FlavourBusinessFacade.ServicesContextResources;
using MenuModel;
using OOAdvantech.Remoting.RestApi.Serialization;
using OOAdvantech.Transactions;
using WPFUIElementObjectBind;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{8c2727a3-6d5f-4ad3-b771-0cfd38a663a8}</MetaDataID>
    public class PreparationStationPresentation : FBResourceTreeNode, INotifyPropertyChanged, IDragDropTarget
    {


        public void IncludeItems(MenuModel.IItemsCategory itemsCategory)
        {

            var itemsPreparationInfos = (from itemsInfo in ItemsPreparationInfos
                                         select new
                                         {
                                             @object = OOAdvantech.PersistenceLayer.ObjectStorage.GetObjectFromUri(itemsInfo.ItemsInfoObjectUri),
                                             ItemsPreparationInfo = itemsInfo
                                         }).ToList();

            var excludedItemsPreparationInfo = (from itemsInfoEntry in itemsPreparationInfos
                                                where itemsInfoEntry.@object == itemsCategory && itemsInfoEntry.ItemsPreparationInfo.Exclude
                                                select itemsInfoEntry.ItemsPreparationInfo).FirstOrDefault();
            if (excludedItemsPreparationInfo != null)
            {
                PreparationStation.RemovePreparationInfo(excludedItemsPreparationInfo);
                ItemsPreparationInfos.Remove(excludedItemsPreparationInfo);

            }

            if (!StationPrepareItems(itemsCategory))
            {
                string uri = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(itemsCategory).GetPersistentObjectUri(itemsCategory);

                var itemsPreparationInfo = this.PreparationStation.NewPreparationInfo(uri);

                this.ItemsPreparationInfos = this.PreparationStation.ItemsPreparationInfos.ToList();
            }

            List<IItemsPreparationInfo> uselessDescendantItemsPreparationInfos = GetUselessDescendantItemsPreparationInfos(itemsCategory);
            if (uselessDescendantItemsPreparationInfos.Count > 0)
            {
                // the item preparation infos which refer to items or category which contained in included category and are useless must be removed
                PreparationStation.RemovePreparationInfos(uselessDescendantItemsPreparationInfos);
                ItemsPreparationInfos = PreparationStation.ItemsPreparationInfos.ToList();
            }
            foreach (var itemsPreparationInfoPresentation in ItemsToChoose.OfType<ItemsPreparationInfoPresentation>())
                itemsPreparationInfoPresentation.Refresh();

            // updates infrastacture vew 

            if (PreparationStationItems != null)
                PreparationStationItems.Refresh();
            RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Members)));
        }

        private List<IItemsPreparationInfo> GetUselessDescendantItemsPreparationInfos(IItemsCategory itemsCategory)
        {

            List<IItemsPreparationInfo> itemsPreparationInfos = new List<IItemsPreparationInfo>();

            var itemsPreparationInfosEntry = (from itemsInfo in ItemsPreparationInfos
                                              select new
                                              {
                                                  @object = OOAdvantech.PersistenceLayer.ObjectStorage.GetObjectFromUri(itemsInfo.ItemsInfoObjectUri),
                                                  ItemsPreparationInfo = itemsInfo
                                              }).ToList();

            foreach (var itemsPreparationInfo in itemsPreparationInfosEntry)
            {
                if (!itemsPreparationInfo.ItemsPreparationInfo.Exclude)
                {
                    if (itemsPreparationInfo.@object is IItemsCategory)
                        if (IsDescendantOfCategory(itemsCategory, itemsPreparationInfo.@object as IItemsCategory))
                        {
                            itemsPreparationInfos.Add(itemsPreparationInfo.ItemsPreparationInfo);
                        }

                    if (itemsPreparationInfo.@object is IMenuItem)
                        if (((itemsPreparationInfo.@object as MenuItem).Class == itemsCategory ||
                            IsDescendantOfCategory(itemsCategory, (itemsPreparationInfo.@object as MenuItem).Class as IItemsCategory)))
                        {
                            itemsPreparationInfos.Add(itemsPreparationInfo.ItemsPreparationInfo);
                        }
                }

            }
            return itemsPreparationInfos;
        }


        private bool IsDescendantOfCategory(IItemsCategory itemsCategory, IItemsCategory descendantItemsCategory)
        {
            //if (itemsCategory != null && itemsCategory == descendantItemsCategory)
            //    return true;

            descendantItemsCategory = descendantItemsCategory.Class as ItemsCategory;
            while (descendantItemsCategory != null && descendantItemsCategory != itemsCategory)
            {
                descendantItemsCategory = descendantItemsCategory.Class as ItemsCategory;
                if (descendantItemsCategory == itemsCategory)
                    return true;
            }
            return false;
        }


        public void IncludeItem(MenuModel.IMenuItem menuItem)
        {

            var itemsPreparationInfos = (from itemsInfo in ItemsPreparationInfos
                                         select new
                                         {
                                             @object = OOAdvantech.PersistenceLayer.ObjectStorage.GetObjectFromUri(itemsInfo.ItemsInfoObjectUri),
                                             ItemsPreparationInfo = itemsInfo
                                         }).ToList();

            var excludedItemsPreparationInfo = (from itemsInfoEntry in itemsPreparationInfos
                                                where itemsInfoEntry.@object == menuItem && itemsInfoEntry.ItemsPreparationInfo.Exclude
                                                select itemsInfoEntry.ItemsPreparationInfo).FirstOrDefault();
            if (excludedItemsPreparationInfo != null)
            {
                PreparationStation.RemovePreparationInfo(excludedItemsPreparationInfo);
                ItemsPreparationInfos.Remove(excludedItemsPreparationInfo);
            }


            if (!StationPrepareItem(menuItem))
            {
                string uri = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(menuItem).GetPersistentObjectUri(menuItem);

                var itemsPreparationInfo = this.PreparationStation.NewPreparationInfo(uri);
                this.ItemsPreparationInfos.Add(itemsPreparationInfo);
                //_Members.Add(new ItemsPreparationInfoPresentation(this, itemsPreparationInfo));
                RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Members)));

                foreach (var itemsPreparationInfoPresentation in ItemsToChoose.OfType<ItemsPreparationInfoPresentation>())
                    itemsPreparationInfoPresentation.Refresh();
            }

            if (PreparationStationItems != null)
                PreparationStationItems.Refresh();
            RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Members)));


            //foreach (var member in _Members.OfType<ItemsPreparationInfoPresentation>())
            //    member.Refresh();
        }

        public void ExcludeItems(MenuModel.IItemsCategory itemsCategory)
        {


            if (StationPrepareItems(itemsCategory))
            {


                var itemsPreparationInfos = (from itemsInfo in ItemsPreparationInfos
                                             select new
                                             {
                                                 @object = OOAdvantech.PersistenceLayer.ObjectStorage.GetObjectFromUri(itemsInfo.ItemsInfoObjectUri),
                                                 ItemsPreparationInfo = itemsInfo
                                             }).ToList();

                var includedItemsPreparationInfo = (from itemsInfoEntry in itemsPreparationInfos
                                                    where itemsInfoEntry.@object == itemsCategory && !itemsInfoEntry.ItemsPreparationInfo.Exclude
                                                    select itemsInfoEntry.ItemsPreparationInfo).FirstOrDefault();

                if (includedItemsPreparationInfo != null)
                {
                    this.PreparationStation.RemovePreparationInfo(includedItemsPreparationInfo);
                    ItemsPreparationInfos.Remove(includedItemsPreparationInfo);
                }
                else
                {

                    string uri = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(itemsCategory).GetPersistentObjectUri(itemsCategory);
                    var itemsPreparationInfo = this.PreparationStation.NewPreparationInfo(uri, true);

                    ItemsPreparationInfos.Add(itemsPreparationInfo);
                    var sdd = itemsPreparationInfo.Exclude;
                }

                foreach (var itemsPreparationInfoPresentation in ItemsToChoose.OfType<ItemsPreparationInfoPresentation>())
                    itemsPreparationInfoPresentation.Refresh();

            }
            else
            {
                List<IItemsPreparationInfo> uselessDescendantItemsPreparationInfos = GetUselessDescendantItemsPreparationInfos(itemsCategory);
                if (uselessDescendantItemsPreparationInfos.Count > 0)
                {
                    // the item preparation infos which refer to items or category which contained in included category and are useless must be removed
                    PreparationStation.RemovePreparationInfos(uselessDescendantItemsPreparationInfos);
                    ItemsPreparationInfos = PreparationStation.ItemsPreparationInfos.ToList();
                }
                foreach (var itemsPreparationInfoPresentation in ItemsToChoose.OfType<ItemsPreparationInfoPresentation>())
                    itemsPreparationInfoPresentation.Refresh();

                
            }

            if (PreparationStationItems != null)
                PreparationStationItems.Refresh();
            RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Members)));
            //foreach (var member in _Members.OfType<ItemsPreparationInfoPresentation>())
            //    member.Refresh();
        }
        public void ExcludeItem(MenuModel.IMenuItem menuItem)
        {

            if (StationPrepareItem(menuItem))
            {


                var itemsPreparationInfos = (from itemsInfo in ItemsPreparationInfos
                                             select new
                                             {
                                                 @object = OOAdvantech.PersistenceLayer.ObjectStorage.GetObjectFromUri(itemsInfo.ItemsInfoObjectUri),
                                                 ItemsPreparationInfo = itemsInfo
                                             }).ToList();

                var includedItemsPreparationInfo = (from itemsInfoEntry in itemsPreparationInfos
                                                    where itemsInfoEntry.@object == menuItem && !itemsInfoEntry.ItemsPreparationInfo.Exclude
                                                    select itemsInfoEntry.ItemsPreparationInfo).FirstOrDefault();

                if (includedItemsPreparationInfo != null)
                {
                    this.PreparationStation.RemovePreparationInfo(includedItemsPreparationInfo);
                    ItemsPreparationInfos.Remove(includedItemsPreparationInfo);
                }
                else
                {

                    string uri = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(menuItem).GetPersistentObjectUri(menuItem);
                    var itemsPreparationInfo = this.PreparationStation.NewPreparationInfo(uri, true);
                    this.ItemsPreparationInfos.Add(itemsPreparationInfo);
                }
                //this.ItemsPreparationInfos.Add(itemsPreparationInfo);
                //_Members.Add(new ItemsPreparationInfoPresentation(this, itemsPreparationInfo));
                //RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Members)));

                //foreach (var itemsPreparationInfoPresentation in Contents.OfType<ItemsPreparationInfoPresentation>())
                //    itemsPreparationInfoPresentation.Refresh();

                if (PreparationStationItems != null)
                    PreparationStationItems.Refresh();
                RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Members)));
                //foreach (var member in _Members.OfType<ItemsPreparationInfoPresentation>())
                //    member.Refresh();
            }
        }

        public bool StationPrepareItems(MenuModel.IItemsCategory itemsCategory)
        {


            var itemsPreparationInfos = (from itemsInfo in ItemsPreparationInfos
                                         select new
                                         {
                                             ItemsInfoObjectUri = itemsInfo.ItemsInfoObjectUri,
                                             @object = OOAdvantech.PersistenceLayer.ObjectStorage.GetObjectFromUri(itemsInfo.ItemsInfoObjectUri),
                                             ItemsPreparationInfo = itemsInfo
                                         }).ToList();

            foreach (var itemsPreparationInfoEntry in itemsPreparationInfos)
            {
                if (itemsPreparationInfoEntry.@object is MenuModel.IItemsCategory && (itemsPreparationInfoEntry.@object as MenuModel.IItemsCategory) == itemsCategory)
                {
                    if (!itemsPreparationInfoEntry.ItemsPreparationInfo.Exclude)
                        return true;
                    else
                        return false;

                }
            }



            foreach (var itemsPreparationInfo in ItemsPreparationInfos)
            {
                MenuModel.IItemsCategory itemsCategoryOrParent = itemsCategory;
                var @object = OOAdvantech.PersistenceLayer.ObjectStorage.GetObjectFromUri(itemsPreparationInfo.ItemsInfoObjectUri);
                if (@object is MenuModel.IItemsCategory)
                {
                    var itemsPreparationInfoCategory = (@object as MenuModel.IItemsCategory);
                    while (itemsCategoryOrParent != null && itemsCategoryOrParent != itemsPreparationInfoCategory)
                        itemsCategoryOrParent = itemsCategoryOrParent.Class as MenuModel.IItemsCategory;

                    if (itemsCategoryOrParent == itemsPreparationInfoCategory)
                        return true;

                }
            }
            return false;

        }

        public bool StationPrepareItem(MenuModel.IMenuItem menuItem)
        {

            var itemsPreparationInfos = (from itemsInfo in ItemsPreparationInfos
                                         select new
                                         {
                                             @object = OOAdvantech.PersistenceLayer.ObjectStorage.GetObjectFromUri(itemsInfo.ItemsInfoObjectUri),
                                             ItemsPreparationInfo = itemsInfo
                                         }).ToList();

            foreach (var itemsPreparationInfoEntry in itemsPreparationInfos)
            {
                if (itemsPreparationInfoEntry.@object is MenuModel.IMenuItem && (itemsPreparationInfoEntry.@object as MenuModel.IMenuItem) == menuItem)
                {
                    if (!itemsPreparationInfoEntry.ItemsPreparationInfo.Exclude)
                        return true;
                    else
                        return false;

                }
            }

            foreach (var itemsPreparationInfoEntry in itemsPreparationInfos)
            {
                if (itemsPreparationInfoEntry.@object is MenuModel.IItemsCategory)
                {
                    MenuModel.IItemsCategory itemsCategory = null;
                    var itemsPreparationInfoCategory = (itemsPreparationInfoEntry.@object as MenuModel.IItemsCategory);
                    if (menuItem is MenuModel.IClassified)
                    {
                        itemsCategory = (menuItem as MenuModel.IClassified).Class as MenuModel.ItemsCategory;

                        if (StationPrepareItems(itemsCategory))
                            return true;
                        else
                            return false;

                        //while (itemsCategory != null && itemsCategory != itemsPreparationInfoCategory)
                        //    itemsCategory = itemsCategory.Class as MenuModel.IItemsCategory;

                        //if (itemsCategory == itemsPreparationInfoCategory)
                        //    return true;
                    }
                }
            }
            return false;

        }

        public readonly IPreparationStation PreparationStation;
        PreparationSationsTreeNode PreparationSations;
        public PreparationStationPresentation(PreparationSationsTreeNode parent, IPreparationStation preparationStation) : base(parent)
        {
            PreparationSations = parent;
            PreparationStation = preparationStation;
            ItemsPreparationInfos = preparationStation.ItemsPreparationInfos.ToList();

            //foreach (var itemsPreparationInfo in ItemsPreparationInfos)
            //{
            //    if (!itemsPreparationInfo.Exclude)
            //        _Members.Add(new ItemsPreparationInfoPresentation(this, itemsPreparationInfo));
            //}


            RenameCommand = new RelayCommand((object sender) =>
            {
                EditMode();
            });
            DeleteCommand = new RelayCommand((object sender) =>
            {
                Delete();
            });

            EditCommand = new WPFUIElementObjectBind.RelayCommand((object sender) =>
            {
                System.Windows.Window win = System.Windows.Window.GetWindow(EditCommand.UserInterfaceObjectConnection.ContainerControl as System.Windows.DependencyObject);
                EditMenuItem(win);
            });
        }


        List<IItemsPreparationInfo> ItemsPreparationInfos;


        MenuModel.IMenu Menu;
        public PreparationStationPresentation(IPreparationStation preparationStation, MenuModel.IMenu menu) : base(null)
        {
            PreparationStation = preparationStation;
            Menu = menu;
            ItemsPreparationInfos = preparationStation.ItemsPreparationInfos.ToList();
            CheckBoxVisibility = Visibility.Collapsed;
        }



        public System.Windows.Visibility CheckBoxVisibility
        {
            get; set;
        }


        private void EditMenuItem(System.Windows.Window owner)
        {
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                var SelectPreparationStationItemsWindow = new Views.SelectPreparationStationItemsWindow();

                SelectPreparationStationItemsWindow.Owner = owner;

                SelectPreparationStationItemsWindow.GetObjectContext().RollbackOnExitWithoutAnswer = false;
                SelectPreparationStationItemsWindow.GetObjectContext().RollbackOnNegativeAnswer = false;

                SelectPreparationStationItemsWindow.GetObjectContext().SetContextInstance(this);

                SelectPreparationStationItemsWindow.ShowDialog();
                stateTransition.Consistent = true;
            }

            RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Name)));
        }

        List<FBResourceTreeNode> _ItemsToChoose;
        public List<FBResourceTreeNode> ItemsToChoose
        {
            get
            {
                if (_ItemsToChoose == null)
                {
                    var rootCategory = new ItemsPreparationInfoPresentation(this, new FlavourBusinessManager.ServicesContextResources.ItemsPreparationInfo((BookViewModel.RestaurantMenus.Members[0] as MenuItemsEditor.ViewModel.MenuViewModel).Menu.RootCategory), true);
                    rootCategory.CheckBoxVisibility = Visibility.Collapsed;
                    _ItemsToChoose = new List<FBResourceTreeNode>() { rootCategory };
                }
                return _ItemsToChoose;
            }
        }
        private void Delete()
        {
            PreparationSations.RemovePreparationStation(this);
        }

        public void EditMode()
        {
            if (_Edit == true)
            {
                _Edit = !_Edit;
                RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Edit)));
            }
            _Edit = true;
            RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Edit)));
        }



        public RelayCommand RenameCommand { get; protected set; }
        public RelayCommand DeleteCommand { get; protected set; }
        public RelayCommand EditCommand { get; protected set; }



        public override string Name
        {
            get
            {
                return PreparationStation.Description;
            }
            set
            {
                PreparationStation.Description = value;
            }
        }

        public string PreparationStationIdentity
        {
            get
            {
                return PreparationStation.PreparationStationIdentity;
            }
        }


        public override bool HasContextMenu
        {
            get
            {
                return true;
            }
        }

        public override bool IsEditable
        {
            get
            {
                return true;
            }
        }

        List<MenuComamnd> _ContextMenuItems;

        public override List<MenuComamnd> ContextMenuItems
        {
            get
            {
                if (_ContextMenuItems == null)
                {

                    _ContextMenuItems = new List<MenuComamnd>();

                    var imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Empty.png"));
                    var emptyImage = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };

                    MenuComamnd menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Rename16.png"));
                    menuItem.Header = MenuItemsEditor.Properties.Resources.TreeNodeRenameMenuItemHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = RenameCommand;
                    _ContextMenuItems.Add(menuItem);



                    _ContextMenuItems.Add(null);

                    menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/delete.png"));
                    menuItem.Header = Properties.Resources.RemoveCallerIDServer;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = DeleteCommand;

                    _ContextMenuItems.Add(menuItem);

                    menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Edit16.png"));
                    menuItem.Header = MenuItemsEditor.Properties.Resources.EditObject;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = EditCommand;

                    _ContextMenuItems.Add(menuItem);



                }
                //if (_ContextMenuItems == null)
                //{
                //    _ContextMenuItems = new List<MenuComamnd>();
                //}
                return _ContextMenuItems;
            }
        }


        public override List<MenuComamnd> SelectedItemContextMenuItems
        {
            get
            {
                if (IsSelected)
                    return ContextMenuItems;
                else
                    foreach (var treeNode in Members)
                    {
                        var contextMenuItems = treeNode.SelectedItemContextMenuItems;
                        if (contextMenuItems != null)
                            return contextMenuItems;
                    }

                return null;
            }
        }


        public override ImageSource TreeImage
        {
            get
            {
                return new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/chef16.png"));
            }
        }

        public override void SelectionChange()
        {

        }

        ItemsPreparationInfoPresentation PreparationStationItems;

        //List<FBResourceTreeNode> _Members;// = new List<FBResourceTreeNode>();
        public override List<FBResourceTreeNode> Members
        {
            get
            {

                if (PreparationStationItems == null)
                {
                    PreparationStationItems = new ItemsPreparationInfoPresentation(this, new FlavourBusinessManager.ServicesContextResources.ItemsPreparationInfo((BookViewModel.RestaurantMenus.Members[0] as MenuItemsEditor.ViewModel.MenuViewModel).Menu.RootCategory), false);
                    PreparationStationItems.CheckBoxVisibility = Visibility.Collapsed;

                }

                return PreparationStationItems.Members;
            }
        }

        DateTime DragEnterStartTime;
        public void DragEnter(object sender, DragEventArgs e)
        {
            DragEnterStartTime = DateTime.Now;

            DragItemsCategory dragItemsCategory = e.Data.GetData(typeof(DragItemsCategory)) as DragItemsCategory;
            if (dragItemsCategory != null)
            {
                e.Effects = DragDropEffects.Copy;
                DragEnterStartTime = DateTime.Now;
            }
            else
                e.Effects = DragDropEffects.None;


        }

        public void DragLeave(object sender, DragEventArgs e)
        {

            if (SelectedOnDragOver)
            {
                IsSelected = false;
                RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(IsSelected)));

            }
            e.Effects = DragDropEffects.None;
        }

        bool SelectedOnDragOver = false;
        public void DragOver(object sender, DragEventArgs e)
        {

            DragItemsCategory dragItemsCategory = e.Data.GetData(typeof(DragItemsCategory)) as DragItemsCategory;
            if (dragItemsCategory != null)
            {
                if (!IsSelected)
                    SelectedOnDragOver = true;
                IsSelected = true;
                RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(IsSelected)));
                if ((DateTime.Now - DragEnterStartTime).TotalSeconds > 2)
                {
                    IsNodeExpanded = true;
                    RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(IsNodeExpanded)));
                }
            }
            else
                e.Effects = DragDropEffects.None;

            System.Diagnostics.Debug.WriteLine("DragOver InfrastructureTreeNode");
        }

        public void Drop(object sender, DragEventArgs e)
        {
            DragItemsCategory dragItemsCategory = e.Data.GetData(typeof(DragItemsCategory)) as DragItemsCategory;
            if (dragItemsCategory != null)
            {

                IncludeItems(dragItemsCategory.ItemsCategory);
                IsNodeExpanded = true;
                RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(IsNodeExpanded)));

                //string uri = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(dragItemsCategory.ItemsCategory).GetPersistentObjectUri(dragItemsCategory.ItemsCategory);
                //var itemsPreparationInfo = this.PreparationStation.NewPreparationInfo(uri);
                //_Members.Add(new ItemsPreparationInfoPresentation(this, itemsPreparationInfo));
                //RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(Members)));
                //IsNodeExpanded = true;
                //RunPropertyChanged(this, new PropertyChangedEventArgs(nameof(IsNodeExpanded)));
            }
            //DragItemsCategory

        }

        //public List<FBResourceTreeNode> PreparationItemsInfoSelections
        //{
        //    get
        //    {
        //        return _Members.ToList();
        //    }
        //}

    }
}