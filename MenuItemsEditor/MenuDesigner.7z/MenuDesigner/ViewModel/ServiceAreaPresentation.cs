﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using FlavourBusinessFacade.ServicesContextResources;
using OOAdvantech.Transactions;
using WPFUIElementObjectBind;

namespace MenuDesigner.ViewModel
{
    /// <MetaDataID>{aeb89bcc-cdf1-4695-a5b1-f5f9c8bf2302}</MetaDataID>
    public class ServiceAreaPresentation : FBResourceTreeNode, INotifyPropertyChanged, IDragDropTarget
    {



        Dictionary<IServicePoint, ServicePointPresentation> ServicePoints = new Dictionary<IServicePoint, ServicePointPresentation>();

        FBResourceTreeNode ServiceContext;
        public readonly IServiceArea ServiceArea;
        public ServiceAreaPresentation(IServiceArea serviceArea, FBResourceTreeNode parent) : base(parent)
        {
            ServiceArea = serviceArea;
            ServiceContext = parent;

            RenameCommand = new RelayCommand((object sender) =>
            {
                EditMode();
            });
            DeleteCommand = new RelayCommand((object sender) =>
            {
                Delete();
            });

            AddServicePointCommand = new RelayCommand((object sender) =>
            {
                AddServicePoint();
            });

            Task.Run(() =>
            {
                foreach (var servicePoint in ServiceArea.ServicePoints)
                    ServicePoints.Add(servicePoint, new ServicePointPresentation(servicePoint, this));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Members)));
            });
            _Name = Properties.Resources.LoadingPrompt;
            Task.Run(() =>
            {
                _Name = serviceArea.Description;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Name)));
            });
        }

        internal void RemoveServicePoint(ServicePointPresentation servicePointPresentation)
        {
            Task.Run(() =>
            {
                ServiceArea.RemoveServicePoint(servicePointPresentation.ServicePoint);
                ServicePoints.Remove(servicePointPresentation.ServicePoint);
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Members)));
            });
        }

        private void AddServicePoint()
        {
            Task.Run(() =>
            {
                var servicePoint = ServiceArea.NewServicePoint();
                servicePoint.Description = Properties.Resources.DefaultServicePointDescription;

                ServicePoints.Add(servicePoint, new ServicePointPresentation(servicePoint, this));

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Members)));
            });
        }

        private void Delete()
        {
            (ServiceContext as FlavoursServicesContextPresentation).RemoveServiceArea(this);
        }

        public void EditMode()
        {
            if (_Edit == true)
            {
                _Edit = !_Edit;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Edit)));
            }
            _Edit = true;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Edit)));
        }


        public RelayCommand RenameCommand { get; protected set; }

        public RelayCommand AddServicePointCommand { get; protected set; }



        public RelayCommand DeleteCommand { get; protected set; }

        /// <exclude>Excluded</exclude>
        List<MenuComamnd> _ContextMenuItems;
        public override List<MenuComamnd> ContextMenuItems
        {
            get
            {

                if (_ContextMenuItems == null)
                {

                    _ContextMenuItems = new List<MenuComamnd>();

                    var imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Empty.png"));
                    var emptyImage = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };

                    MenuComamnd menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/Rename16.png"));
                    menuItem.Header = MenuItemsEditor.Properties.Resources.TreeNodeRenameMenuItemHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = RenameCommand;
                    _ContextMenuItems.Add(menuItem);


                    _ContextMenuItems.Add(null);

                    menuItem = new MenuComamnd(); ;
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/ServicePoint.png"));
                    menuItem.Header = Properties.Resources.AddServicePointHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = AddServicePointCommand;

                    _ContextMenuItems.Add(menuItem);

                    menuItem = new MenuComamnd();
                    imageSource = new BitmapImage(new Uri(@"pack://application:,,,/MenuItemsEditor;Component/Image/delete.png"));
                    menuItem.Header = Properties.Resources.RemoveServicesContextHeader;
                    menuItem.Icon = new System.Windows.Controls.Image() { Source = imageSource, Width = 16, Height = 16 };
                    menuItem.Command = DeleteCommand;

                    _ContextMenuItems.Add(menuItem);



                }
                //if (_ContextMenuItems == null)
                //{
                //    _ContextMenuItems = new List<MenuComamnd>();
                //}
                return _ContextMenuItems;
            }
        }





        public override bool IsEditable
        {
            get
            {
                return true;
            }
        }




        public override List<FBResourceTreeNode> Members
        {
            get
            {
                var members = ServicePoints.Values.OfType<FBResourceTreeNode>().ToList();
                return members;
            }
        }

        string _Name;
        public override string Name
        {
            get
            {
                return _Name;
            }

            set
            {

                _Name = value;
                this.ServiceArea.Description = value;

            }
        }

    
        public virtual bool HasContextMenu
        {
            get
            {
                return true;
            }
        }
        public override List<MenuComamnd> SelectedItemContextMenuItems
        {
            get
            {
                if (IsSelected)
                    return ContextMenuItems;
                else
                    foreach (var treeNode in Members)
                    {
                        var contextMenuItems = treeNode.SelectedItemContextMenuItems;
                        if (contextMenuItems != null)
                            return contextMenuItems;
                    }

                return null;
            }
        }

        public override ImageSource TreeImage
        {
            get
            {
                return new System.Windows.Media.Imaging.BitmapImage(new Uri(@"pack://application:,,,/MenuDesigner;Component/Resources/Images/Metro/ServiceArea.png"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void DragEnter(object sender, DragEventArgs e)
        {

            //ViewModel.GraphicMenuTreeNode graphicMenuTreeNode = e.Data.GetData(typeof(ViewModel.GraphicMenuTreeNode)) as ViewModel.GraphicMenuTreeNode;
            //if (graphicMenuTreeNode == null)
                e.Effects = DragDropEffects.None;

        }

        public void DragLeave(object sender, DragEventArgs e)
        {
            //ViewModel.GraphicMenuTreeNode graphicMenuTreeNode = e.Data.GetData(typeof(ViewModel.GraphicMenuTreeNode)) as ViewModel.GraphicMenuTreeNode;
            //if (graphicMenuTreeNode == null)
                e.Effects = DragDropEffects.None;

        }

        public void DragOver(object sender, DragEventArgs e)
        {
            //ViewModel.GraphicMenuTreeNode graphicMenuTreeNode = e.Data.GetData(typeof(ViewModel.GraphicMenuTreeNode)) as ViewModel.GraphicMenuTreeNode;
            //if (graphicMenuTreeNode == null)
                e.Effects = DragDropEffects.None;

        }

        public void Drop(object sender, DragEventArgs e)
        {
            //ViewModel.GraphicMenuTreeNode graphicMenuTreeNode = e.Data.GetData(typeof(ViewModel.GraphicMenuTreeNode)) as ViewModel.GraphicMenuTreeNode;
            //if (graphicMenuTreeNode == null)
            //    e.Effects = DragDropEffects.None;
            //else
            //{
            //    var servicePointRunTime = ServicesContext.GetRunTime();
            //}

        }

        public override void SelectionChange()
        {
        }
    }
}
