﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using MenuDesigner.ViewModel;
using Microsoft.Win32;
using Newtonsoft.Json;
using OOAdvantech.Transactions;
using System.Net.Http;
using FlavourBusinessToolKit;
using System.IO;

namespace MenuDesigner
{

    //imenupro.com / SVGMenuPro11  - menuborder

    /// <summary>
    /// Interaction logic for PageDesigner.xaml
    /// </summary>
    /// <MetaDataID>{5f832311-fd18-4366-8fe6-14b23c5315d9}</MetaDataID>
    public partial class MenuDesignerControl : UserControl
    {
        /// <MetaDataID>{5e8ee0a0-256b-4e16-bebe-82291497bd58}</MetaDataID>
        public static RoutedCommand NewPage = new RoutedCommand();
        /// <MetaDataID>{e7e251e9-7b34-442b-8682-684825bb8efa}</MetaDataID>
        public static RoutedCommand DeletePage = new RoutedCommand();
        /// <MetaDataID>{ec3092b4-6630-479c-9516-df1418d2f5be}</MetaDataID>
        public static RoutedCommand MovePageRight = new RoutedCommand();
        /// <MetaDataID>{f48091e6-4f82-4100-98aa-733eadf41180}</MetaDataID>
        public static RoutedCommand MovePageLeft = new RoutedCommand();

        /// <MetaDataID>{e75bd865-01cb-4add-a453-0d6fba1ecf79}</MetaDataID>
        public MenuDesignerControl()
        {
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(MenuDesignerControl.NewPage, NewPage_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(MenuDesignerControl.DeletePage, DeletePage_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(MenuDesignerControl.MovePageRight, MovePageRight_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(MenuDesignerControl.MovePageLeft, MovePageLeft_Executed));


            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.New, New_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Open, Open_Executed));
            this.CommandBindings.Add(new CommandBinding(ApplicationCommands.Save, Save_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Print, Print_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Cut, Cut_Executed, Cut_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Copy, Copy_Executed, Copy_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Paste, Paste_Executed, Paste_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(ApplicationCommands.Delete, Delete_Executed, Delete_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.Group, Group_Executed, Group_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.Ungroup, Ungroup_Executed, Ungroup_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.BringForward, BringForward_Executed, Order_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.BringToFront, BringToFront_Executed, Order_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.SendBackward, SendBackward_Executed, Order_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.SendToBack, SendToBack_Executed, Order_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignTop, AlignTop_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignVerticalCenters, AlignVerticalCenters_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignBottom, AlignBottom_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignLeft, AlignLeft_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignHorizontalCenters, AlignHorizontalCenters_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.AlignRight, AlignRight_Executed, Align_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.DistributeHorizontal, DistributeHorizontal_Executed, Distribute_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.DistributeVertical, DistributeVertical_Executed, Distribute_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.SelectAll, SelectAll_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.TitleHeadingFonts, TitleHeadingFonts_Executed, StyleSheetFontsChange_Enabled));

            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.DownloadStyleSheet, DownloadStyleSheet_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.SignInSignUp, SignInSignUp_Executed));



            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.NormalHeadingFonts, NormalHeadingFonts_Executed, StyleSheetFontsChange_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.SubHeadingFonts, SubHeadingFonts_Executed, StyleSheetFontsChange_Enabled));

            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.FoodItemNameFonts, FoodItemNameFonts_Executed, StyleSheetFontsChange_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.FoodItemDescriptionFonts, FoodItemDescriptionFonts_Executed, StyleSheetFontsChange_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.FoodItemExtrasFonts, FoodItemExtrasFonts_Executed, StyleSheetFontsChange_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.FoodItemPriceFonts, FoodItemPriceFonts_Executed, StyleSheetFontsChange_Enabled));

            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.StyleSelection, StyleSelection_Executed));

            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.LayoutOptions, LayoutOptions_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.BorderSelection, BorderSelection_Executed));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.BackgroundSelection, BackgroundSelection_Executed));


            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.HeadingTypesAccents, HeadingTypesAccents_Executed));



            //      public static RoutedCommand MoveToNextPage = new RoutedCommand();
            //public static RoutedCommand MoveToPreviousPage = new RoutedCommand();

            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.MoveToNextPage, MoveToNextPage_Executed, MoveToNextPage_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.MoveToPreviousPage, MoveToPreviousPage_Executed, MoveToPreviousPage_Enabled));

            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ShrinkLineSpace, ShrinkLineSpace_Executed, ShrinkLineSpace_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ExpandLineSpace, ExpandLineSpace_Executed, ExpandLineSpace_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ResetLineSpace, ResetLineSpace_Executed, ResetLineSpace_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ShrinkPageFontsSizes, ShrinkPageFontsSizes_Executed, ShrinkPageFontsSizes_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ExpandPageFontsSizes, ExpandPageFontsSizes_Executed, ExpandPageFontsSizes_Enabled));
            this.CommandBindings.Add(new WPFUIElementObjectBind.CommandBinding(DesignerCanvas.ResetPageFontsSizes, RestPageFontsSizes_Executed, RestPageFontsSizes_Enabled));


            InitializeComponent();

            //DragActionInialization();
            ZoomViewBox.SizeChanged += ZoomViewBox_SizeChanged;
            ZoomViewBox.DataContextChanged += ZoomViewBox_DataContextChanged;

            // DataContext = BookViewModel;
            BookScrollViewer.SizeChanged += BookScrollViewer_SizeChanged;

        }

        //int i = 0;
        //private void DesignerCanvasDragLeave(object sender, DragEventArgs e)
        //{
        //    return;
        //    var viemo = (sender as FrameworkElement).GetDataContextObject();
        //    var bookPageViewModel = (sender as FrameworkElement).GetDataContextObject<BookPageViewModel>();
        //    if (bookPageViewModel == null)
        //    {
        //        var canvasFrameViewModel = (sender as FrameworkElement).GetDataContextObject<CanvasFrameViewModel>();
        //        if (canvasFrameViewModel != null)
        //            bookPageViewModel = canvasFrameViewModel.BookPageViewModel;
        //    }

        //    Point screenPoint = (sender as FrameworkElement).PointToScreen(e.GetPosition(sender as IFrameworkInputElement));

        //    DesignerCanvas designerCanvas = sender as DesignerCanvas;
        //    if (designerCanvas == null)
        //        designerCanvas = WPFUIElementObjectBind.ObjectContext.FindParent<DesignerCanvas>(sender as DependencyObject);
        //    if (designerCanvas != null)
        //    {
        //        bookPageViewModel.DragDropArea.Opacity = 0;


        //    }

        //    System.Diagnostics.Trace.WriteLine(i.ToString() + "DragLeave");
        //    i++;
        //}

        //private void DesignerCanvasDragOver(object sender, DragEventArgs e)
        //{
        //    return;
        //    ViewModel.DragCanvasItem canvasItem = e.Data.GetData(typeof(ViewModel.DragCanvasItem)) as ViewModel.DragCanvasItem;
        //    if (canvasItem != null)
        //    {
        //        var viemo = (sender as FrameworkElement).GetDataContextObject();
        //        var bookPageViewModel = (sender as FrameworkElement).GetDataContextObject<BookPageViewModel>();
        //        if (bookPageViewModel == null)
        //        {
        //            var canvasFrameViewModel = (sender as FrameworkElement).GetDataContextObject<CanvasFrameViewModel>();
        //            if (canvasFrameViewModel != null)
        //                bookPageViewModel = canvasFrameViewModel.BookPageViewModel;
        //        }

        //        Point screenPoint = (sender as FrameworkElement).PointToScreen(e.GetPosition(sender as IFrameworkInputElement));

        //        DesignerCanvas designerCanvas = sender as DesignerCanvas;
        //        if (designerCanvas == null)
        //            designerCanvas = WPFUIElementObjectBind.ObjectContext.FindParent<DesignerCanvas>(sender as DependencyObject);
        //        if (designerCanvas != null)
        //        {
        //            //Views.MovingFrame dragFrame = null;
        //            //foreach (Views.MovingFrame frame in  WPFUIElementObjectBind.ObjectContext.FindChilds<Views.MovingFrame>(designerCanvas))
        //            //{
        //            //    if (frame.GetDataContextObject<ViewModel.CanvasFrameViewModel>() == bookPageViewModel.DragDropArea)
        //            //    {
        //            //        dragFrame = frame;
        //            //        break;
        //            //    }
        //            //}
        //            //if (dragFrame != null)
        //            //{
        //            //    dragFrame.FrameGrid.Opacity = 1;

        //            //}
        //            var canvasPoint = designerCanvas.PointFromScreen(screenPoint);


        //            bookPageViewModel.DragDropArea.Opacity = 1;

        //            if (bookPageViewModel.DragDropArea.MenuItem == null || bookPageViewModel.DragDropArea.MenuItem.MenuCanvasItem != canvasItem.MenuCanvasItem)
        //                bookPageViewModel.DragDropArea.MenuItem = new MenuCanvasItemViewModel(canvasItem.MenuCanvasItem);

        //            bookPageViewModel.DragDropArea.Top = canvasPoint.Y;

        //            //if (bookPageViewModel != null)
        //            //    System.Diagnostics.Trace.WriteLine(string.Format("GetPosition(null): X = {0}, Y = {1}", canvasPoint.X, canvasPoint.Y));
        //        }
        //    }

        //}





        private void BookViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(BookViewModel.ZoomPercentage))
            {
                BookViewModel BookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
                if (BookViewModel != null)
                {
                    if (Zoom.HasValue && Zoom.Value != BookViewModel.ZoomPercentage)
                    {
                        Zoom = BookViewModel.ZoomPercentage;
                        ZoomViewBox.Height = (Zoom.Value / 100) * (ZoomViewBox.Child as FrameworkElement).ActualHeight;
                    }
                }
            }
        }

        double? Zoom;

        private void ZoomViewBox_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            BookViewModel BookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            if (BookViewModel != null)
            {
                BookViewModel.PropertyChanged += BookViewModel_PropertyChanged;
                if ((ZoomViewBox.Child as FrameworkElement).ActualHeight > 0)
                {
                    Zoom = (ZoomViewBox.ActualHeight / (ZoomViewBox.Child as FrameworkElement).ActualHeight) * 100;
                    BookViewModel.ZoomPercentage = Zoom.Value;
                }
            }
        }

        private void ZoomViewBox_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            BookViewModel BookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            if (BookViewModel != null)
            {
                if ((ZoomViewBox.Child as FrameworkElement).ActualHeight > 0)
                {
                    Zoom = (ZoomViewBox.ActualHeight / (ZoomViewBox.Child as FrameworkElement).ActualHeight) * 100;
                    BookViewModel.ZoomPercentage = Zoom.Value;
                }
            }
        }
        //HeadingTypesAccents

        private void HeadingTypesAccents_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MenuPresentationModel.MenuStyles.StyleSheet styleSheet = ZoomViewBox.GetDataContextObject<ViewModel.BookViewModel>().MenuStylesheet;

            HeadingTypesAccentsViewModel headingTypesAccentsViewModel = new ViewModel.HeadingTypesAccentsViewModel((styleSheet.Styles["title-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle), (styleSheet.Styles["heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle), (styleSheet.Styles["small-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle));
            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            Views.SelectHeadingTypesAccents headingTypesAccents = new Views.SelectHeadingTypesAccents();
            headingTypesAccents.Owner = win;
            headingTypesAccents.GetObjectContext().SetContextInstance(headingTypesAccentsViewModel);
            headingTypesAccents.ShowDialog();

        }
        private void LayoutOptions_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            var tmp1 = bookViewModel.Pages[0].MenuPage.MenuCanvasItems.ToArray();
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                ViewModel.LayoutOptionsPresentation layoutOptionsPresentation = new LayoutOptionsPresentation(bookViewModel,
                                                                                                            bookViewModel.RealObject.Style.Styles["layout"] as MenuPresentationModel.MenuStyles.LayoutStyle,
                                                                                                            bookViewModel.RealObject.Style.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle,
                                                                                                            bookViewModel.RealObject.Style.Styles["menu-item"] as MenuPresentationModel.MenuStyles.MenuItemStyle,
                                                                                                            bookViewModel.RealObject.Style.Styles["price-options"] as MenuPresentationModel.MenuStyles.PriceStyle);
                System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
                Point position = PointToScreen(new Point(-50, -50));
                //  position = win.PointFromScreen(position);

                Views.LayoutOptionsForm layoutOptions = new Views.LayoutOptionsForm();
                layoutOptions.Owner = win;
                layoutOptions.Top = position.Y;
                layoutOptions.Left = position.X;
                layoutOptions.GetObjectContext().SetContextInstance(layoutOptionsPresentation);
                if (layoutOptions.ShowDialog().Value)
                    stateTransition.Consistent = true;

                var tmp = bookViewModel.Pages[0].MenuPage.MenuCanvasItems.ToArray();
            }
            var tmp2 = bookViewModel.Pages[0].MenuPage.MenuCanvasItems.ToArray();
        }

        private void BorderSelection_Executed(object sender, ExecutedRoutedEventArgs e)
        {

            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
                ViewModel.BorderSelectionViewModel borderSelectionViewModel = new BorderSelectionViewModel(bookViewModel.RealObject.Style.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle);
                System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
                Views.BorderSelectorWindow borderSelection = new Views.BorderSelectorWindow();
                borderSelection.Owner = win;
                borderSelection.GetObjectContext().SetContextInstance(borderSelectionViewModel);

                if (borderSelection.ShowDialog().Value)
                    stateTransition.Consistent = true;

            }


        }
        private void BackgroundSelection_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
                ViewModel.BackgroundSelectionViewModel borderSelectionViewModel = new BackgroundSelectionViewModel(bookViewModel.RealObject.Style.Styles["page"] as MenuPresentationModel.MenuStyles.PageStyle);
                System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
                Views.BackgroundSelectorWindow borderSelection = new Views.BackgroundSelectorWindow();
                borderSelection.Owner = win;
                borderSelection.GetObjectContext().SetContextInstance(borderSelectionViewModel);

                if (borderSelection.ShowDialog().Value)
                    stateTransition.Consistent = true;
            }

        }

        internal void MoveToPreviousPage_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            bookViewModel.MoveToPreviousPage();
        }
        internal void MoveToPreviousPage_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            e.CanExecute = bookViewModel != null;
        }

        internal void MoveToNextPage_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            bookViewModel.MoveToNextPage();
        }
        internal void MoveToNextPage_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            e.CanExecute = bookViewModel != null;
        }

        #region ShrinkLineSpace Command
        internal void ShrinkLineSpace_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            bookViewModel.ShrinkLineSpace();
        }
        internal void ShrinkLineSpace_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            e.CanExecute = bookViewModel != null;
        }
        #endregion

        #region ExpandLineSpace Command
        internal void ExpandLineSpace_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            bookViewModel.ExpandLineSpace();
        }
        internal void ExpandLineSpace_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            e.CanExecute = bookViewModel != null;
        }
        #endregion

        #region ResetLineSpace Command
        internal void ResetLineSpace_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            bookViewModel.ResetLineSpace();
        }
        internal void ResetLineSpace_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            e.CanExecute = bookViewModel != null;
        }
        #endregion

        #region ShrinkPageFontsSizes Command
        internal void ShrinkPageFontsSizes_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            bookViewModel.ShrinkPageFontsSizes();

        }
        internal void ShrinkPageFontsSizes_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            e.CanExecute = bookViewModel != null;
        }
        #endregion

        #region ExpandPageFontsSizes Command
        internal void ExpandPageFontsSizes_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            bookViewModel.ExpandPageFontsSizes();


        }
        internal void ExpandPageFontsSizes_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            e.CanExecute = bookViewModel != null;
        }
        #endregion

        #region RestPageFontsSizes Command
        internal void RestPageFontsSizes_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            bookViewModel.ResetPageFontsSizes();

            //foreach (var rectangle in FindVisualChildren<WPFUIElementObjectBind.OutlineTextBlock>(this))
            //{
            //    MenuCanvasItemViewModel itemViewModel = rectangle.GetDataContextObject<MenuDesigner.ViewModel.MenuCanvasItemViewModel>();
            //    if (itemViewModel.Font.Value.FontSpacing > 0)
            //    {
            //        double measuredWidth = itemViewModel.Font.Value.MeasureText(rectangle.Text).Width;
            //        double wpfWidth = rectangle.ActualWidth;
            //    }
            //    else
            //    {
            //        double measuredWidth = itemViewModel.Font.Value.MeasureText(rectangle.Text).Width;
            //        double wpfWidth = rectangle.ActualWidth;
            //        var formattedText = new FormattedText(rectangle.Text, System.Threading.Thread.CurrentThread.CurrentUICulture,
            //     FlowDirection.LeftToRight,
            //         new Typeface(rectangle.FontFamily, rectangle.FontStyle, rectangle.FontWeight, rectangle.FontStretch),
            //                   rectangle.FontSize, Brushes.Black);
            //        var gWidth = formattedText.BuildGeometry(new Point(0, 0)).Bounds.Width;

            //    }
            //}

        }

        public IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);

                    if (child != null && child is T)
                        yield return (T)child;

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                        yield return childOfChild;
                }
            }
        }
        internal void RestPageFontsSizes_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            BookViewModel bookViewModel = ZoomViewBox.GetDataContextObject<BookViewModel>();
            e.CanExecute = bookViewModel != null;
        }
        #endregion

        /// <MetaDataID>{a579ef07-ddc1-424c-ad48-9e62220b4e81}</MetaDataID>
        private void BookScrollViewer_SizeChanged(object sender, SizeChangedEventArgs e)
        {

            ZoomViewBox.Height = BookScrollViewer.ActualHeight - (SystemParameters.HorizontalScrollBarHeight + 10);
            UpdateLayout();
        }

        /// <MetaDataID>{b4450ed8-601c-4c81-84f3-0ffea1e84595}</MetaDataID>
        BookViewModel BookViewModel = null;
        /// <MetaDataID>{78193068-e27e-4f60-930c-795a37b3bf47}</MetaDataID>
        DesignerCanvas _SelectionDesignerCanvas;
        /// <MetaDataID>{2ce99db2-5587-4400-a659-6b632cd52167}</MetaDataID>
        public DesignerCanvas SelectionDesignerCanvas
        {
            get
            {
                return DesignerCanvas.SelectedDesignerCanvas;
            }
            set
            {
                _SelectionDesignerCanvas = value;
            }
        }

        /// <MetaDataID>{b2cbdc93-da5c-485e-aba5-ba44b68768f6}</MetaDataID>
        private void NewPage_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookPageViewModel page = null;
            if (SelectionDesignerCanvas != null)
                page = SelectionDesignerCanvas.GetDataContextObject<BookPageViewModel>();
            ZoomViewBox.GetDataContextObject<BookViewModel>().AddPageAfter(page);
            ZoomViewBox.Height = BookScrollViewer.ActualHeight - (SystemParameters.HorizontalScrollBarHeight + 10);
            UpdateLayout();
            System.Diagnostics.Debug.WriteLine(string.Format("Height:{0},Width{1}", ZoomViewBox.ActualHeight, ZoomViewBox.ActualWidth));
        }
        /// <MetaDataID>{794af5f8-f785-483b-89eb-c3433b9c7db0}</MetaDataID>
        private void Grid_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine(string.Format("Height:{0},Width{1}", ZoomViewBox.ActualHeight, ZoomViewBox.ActualWidth));
            if (ZoomViewBox.ActualHeight + (e.Delta / 2) > 0)
                ZoomViewBox.Height = ZoomViewBox.ActualHeight + (e.Delta / 2);

        }
        /// <MetaDataID>{277d135e-459d-4d52-bc0c-a3876f0bb456}</MetaDataID>
        private void DeletePage_Executed(object sender, ExecutedRoutedEventArgs e)
        {


            //if (SelectionDesignerCanvas != null)
            //    SelectionDesignerCanvas.BringForward_Executed(sender, e);
        }
        /// <MetaDataID>{750916bc-fe1c-4bfa-85b8-d2142563ecb4}</MetaDataID>
        private void MovePageLeft_Executed(object sender, ExecutedRoutedEventArgs e)
        {

            if (SelectionDesignerCanvas != null)
                ZoomViewBox.GetDataContextObject<BookViewModel>().MoveSelectedPageLeft(SelectionDesignerCanvas.GetDataContextObject<BookPageViewModel>());

            //if (SelectionDesignerCanvas != null)
            //    SelectionDesignerCanvas.BringForward_Executed(sender, e);
        }
        /// <MetaDataID>{bc95b07e-6c66-43b5-94ef-0010719b4e2d}</MetaDataID>
        private void MovePageRight_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            //if (SelectionDesignerCanvas != null)
            //    SelectionDesignerCanvas.BringForward_Executed(sender, e);
        }



        /// <MetaDataID>{7d495909-a27d-48f3-b667-9f63e14ef707}</MetaDataID>
        private void BringForward_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.BringForward_Executed(sender, e);
        }

        /// <MetaDataID>{3fb7df22-afed-48d2-bd6f-869af27ef9af}</MetaDataID>
        private void BringToFront_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.BringToFront_Executed(sender, e);
        }
        /// <MetaDataID>{6a5065b3-6d21-4c12-9d66-b61622021011}</MetaDataID>
        private void SendBackward_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.SendBackward_Executed(sender, e);
        }
        /// <MetaDataID>{10eda9bd-13d1-42f6-838e-11df682d4bf3}</MetaDataID>
        private void SendToBack_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.SendToBack_Executed(sender, e);
        }
        /// <MetaDataID>{15a2e8f5-fddc-48d1-b93e-f655dbeb1e1b}</MetaDataID>
        private void AlignTop_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.AlignTop_Executed(sender, e);
        }
        /// <MetaDataID>{4277e047-aa43-4554-bc61-96a88ca1405d}</MetaDataID>
        private void AlignVerticalCenters_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.AlignVerticalCenters_Executed(sender, e);
        }
        /// <MetaDataID>{c2b3c2c9-a31b-475e-bdec-28c24bbb75fa}</MetaDataID>
        private void AlignBottom_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.AlignBottom_Executed(sender, e);
        }
        /// <MetaDataID>{9c887b01-d4b6-4e7a-a303-a43755e156e4}</MetaDataID>
        private void AlignLeft_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.AlignLeft_Executed(sender, e);
        }
        /// <MetaDataID>{b1d39d90-1fbf-4371-89c0-026339fa531e}</MetaDataID>
        private void AlignHorizontalCenters_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.AlignHorizontalCenters_Executed(sender, e);
        }
        /// <MetaDataID>{e5d80cfe-7d7d-43e2-b583-35f7090ed4d4}</MetaDataID>
        private void AlignRight_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.AlignRight_Executed(sender, e);
        }
        /// <MetaDataID>{b95e27cb-847c-4730-b1cf-2e331358b9c8}</MetaDataID>
        private void DistributeHorizontal_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.DistributeHorizontal_Executed(sender, e);
        }
        /// <MetaDataID>{92d9c375-3059-4aab-8e28-3aecd9c83636}</MetaDataID>
        private void DistributeVertical_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.DistributeVertical_Executed(sender, e);
        }
        /// <MetaDataID>{b1c6926b-ce8d-414e-b8d0-c160eb638d79}</MetaDataID>
        private void SelectAll_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.SelectAll_Executed(sender, e);
        }
        private void StyleSheetFontsChange_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            var book = ZoomViewBox.GetDataContextObject<BookViewModel>();
            if (book != null && book.RestaurantMenu != null)
                e.CanExecute = true;


        }
        internal void FoodItemNameFonts_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                StyleableWindow.FontDialog fontDialog = new StyleableWindow.FontDialog();
                var book = ZoomViewBox.GetDataContextObject<BookViewModel>();
                var menuItemStyle = (book.EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle);
                StyleFontUpdater styleFontUpdater = new StyleFontUpdater(menuItemStyle, new StyleableWindow.FontPresantation() { Font = menuItemStyle.Font }, "Font");

                fontDialog.GetObjectContext().SetContextInstance(styleFontUpdater.FontPresantation);
                // fontDialog.Font = (book.EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle).Font;
                fontDialog.Owner = win;
                if (fontDialog.ShowDialog().Value)
                    stateTransition.Consistent = true;
            }
        }

        internal void FoodItemDescriptionFonts_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                StyleableWindow.FontDialog fontDialog = new StyleableWindow.FontDialog();
                var book = ZoomViewBox.GetDataContextObject<BookViewModel>();
                var menuItemStyle = (book.EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle);
                StyleFontUpdater styleFontUpdater = new StyleFontUpdater(menuItemStyle, new StyleableWindow.FontPresantation() { Font = menuItemStyle.DescriptionFont }, "DescriptionFont");

                fontDialog.GetObjectContext().SetContextInstance(styleFontUpdater.FontPresantation);
                // fontDialog.Font = (book.EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle).Font;
                fontDialog.Owner = win;
                if (fontDialog.ShowDialog().Value)
                    stateTransition.Consistent = true;
            }
        }

        internal void FoodItemExtrasFonts_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                StyleableWindow.FontDialog fontDialog = new StyleableWindow.FontDialog();
                var book = ZoomViewBox.GetDataContextObject<BookViewModel>();
                var menuItemStyle = (book.EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle);
                StyleFontUpdater styleFontUpdater = new StyleFontUpdater(menuItemStyle, new StyleableWindow.FontPresantation() { Font = menuItemStyle.ExtrasFont }, "ExtrasFont");

                fontDialog.GetObjectContext().SetContextInstance(styleFontUpdater.FontPresantation);
                // fontDialog.Font = (book.EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle).Font;
                fontDialog.Owner = win;
                if (fontDialog.ShowDialog().Value)
                    stateTransition.Consistent = true;
            }
        }
        internal void FoodItemPriceFonts_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                StyleableWindow.FontDialog fontDialog = new StyleableWindow.FontDialog();
                var book = ZoomViewBox.GetDataContextObject<BookViewModel>();
                var menuItemStyle = (book.EditStyleSheet.Styles["price-options"] as MenuPresentationModel.MenuStyles.IPriceStyle);
                StyleFontUpdater styleFontUpdater = new StyleFontUpdater(menuItemStyle, new StyleableWindow.FontPresantation() { Font = menuItemStyle.Font }, "Font");

                fontDialog.GetObjectContext().SetContextInstance(styleFontUpdater.FontPresantation);
                // fontDialog.Font = (book.EditStyleSheet.Styles["menu-item"] as MenuPresentationModel.MenuStyles.IMenuItemStyle).Font;
                fontDialog.Owner = win;
                if (fontDialog.ShowDialog().Value)
                    stateTransition.Consistent = true;
            }
        }


        internal void DownloadStyleSheet_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            //HeadingStyleAccentViewModel
            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);

            DownloadStylesWindow DfontDialog = new DownloadStylesWindow();
            DfontDialog.Owner = win;
            DfontDialog.ShowDialog();
        }
        internal void SignInSignUp_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            //System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            //Views.SignInWindow signInWindow = new Views.SignInWindow();
            //signInWindow.Owner = win;

            //using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Suppress))
            //{
            //    signInWindow.ShowDialog(); 
            //    stateTransition.Consistent = true;
            //}


        }
        internal void NormalHeadingFonts_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                StyleableWindow.FontDialog fontDialog = new StyleableWindow.FontDialog();
                var book = ZoomViewBox.GetDataContextObject<BookViewModel>();
                var headingStyle = (book.EditStyleSheet.Styles["heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle);
                StyleFontUpdater styleFontUpdater = new StyleFontUpdater(headingStyle, new StyleableWindow.FontPresantation() { Font = headingStyle.Font }, "Font");
                fontDialog.GetObjectContext().SetContextInstance(styleFontUpdater.FontPresantation);
                fontDialog.Owner = win;
                if (fontDialog.ShowDialog().Value)
                    stateTransition.Consistent = true;
            }
        }

        internal void SubHeadingFonts_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                StyleableWindow.FontDialog fontDialog = new StyleableWindow.FontDialog();
                var book = ZoomViewBox.GetDataContextObject<BookViewModel>();
                var headingStyle = (book.EditStyleSheet.Styles["small-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle);
                StyleFontUpdater styleFontUpdater = new StyleFontUpdater(headingStyle, new StyleableWindow.FontPresantation() { Font = headingStyle.Font }, "Font");
                fontDialog.GetObjectContext().SetContextInstance(styleFontUpdater.FontPresantation);
                fontDialog.Owner = win;
                if (fontDialog.ShowDialog().Value)
                    stateTransition.Consistent = true;
            }
        }

        internal void TitleHeadingFonts_Executed(object sender, ExecutedRoutedEventArgs e)
        {

            System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.RequiredNested))
            {
                StyleableWindow.FontDialog fontDialog = new StyleableWindow.FontDialog();
                var book = ZoomViewBox.GetDataContextObject<BookViewModel>();
                var headingStyle = (book.EditStyleSheet.Styles["title-heading"] as MenuPresentationModel.MenuStyles.IHeadingStyle);
                StyleFontUpdater styleFontUpdater = new StyleFontUpdater(headingStyle, new StyleableWindow.FontPresantation() { Font = headingStyle.Font }, "Font");

                fontDialog.GetObjectContext().SetContextInstance(styleFontUpdater.FontPresantation);
                fontDialog.Owner = win;
                if (fontDialog.ShowDialog().Value)
                    stateTransition.Consistent = true;
            }


            ////HeadingStyleAccentViewModel
            //System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);

            //FontDialog fontDialog = new FontDialog();
            //fontDialog.Owner = win;
            //fontDialog.ShowDialog();




            //DownloadStylesWindow DfontDialog = new DownloadStylesWindow();
            //DfontDialog.Owner = win;
            //DfontDialog.ShowDialog();


            //XDocument doc = XDocument.Load(@"C:\ProgramData\Microneme\DontWaitWater\AccentImages\Divider_Ornamental_6.svg");
            //Views.HeadingAccentForm dialog = new Views.HeadingAccentForm();
            //dialog.Owner = win;
            //dialog.GetObjectContext().SetContextInstance(new HeadingStyleAccentViewModel());
            //dialog.ShowDialog();
            //if (SelectionDesignerCanvas != null)
            //    SelectionDesignerCanvas.TitleHeadingFonts_Executed(sender, e);

            //FontTestWindow fontTestWindow = new FontTestWindow();

            //fontTestWindow.ShowDialog();


        }


        internal void StyleSelection_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            BookViewModel menu = ZoomViewBox.GetDataContextObject<BookViewModel>();
            if (menu != null)
            {


                System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);
                MenuStyleWindow menuStyleWindow = new MenuStyleWindow();
                menuStyleWindow.Owner = win;

                menuStyleWindow.GetObjectContext().SetContextInstance(menu);

                menuStyleWindow.ShowDialog();
            }

            // SelectionService.TitleHeadingFonts(sender, e);
        }
        /// <MetaDataID>{adb2384a-3054-4f23-a248-63ab567f9f55}</MetaDataID>
        private void Ungroup_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Ungroup_Executed(sender, e);
        }
        /// <MetaDataID>{9581e6d3-b956-4e86-b0f9-eabb7c68fe39}</MetaDataID>
        private void Copy_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Copy_Executed(sender, e);
        }
        /// <MetaDataID>{3888e81f-281f-408f-849a-eecafec3cc5c}</MetaDataID>
        private void Paste_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Paste_Executed(sender, e);
        }
        /// <MetaDataID>{be11c576-d389-4473-bc74-6e51d6ba8597}</MetaDataID>
        private void Delete_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Delete_Executed(sender, e);
        }
        /// <MetaDataID>{f2597fe8-e550-4322-90c7-2db764a94637}</MetaDataID>
        private void Group_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Group_Executed(sender, e);
        }

        /// <MetaDataID>{1b5d5f8f-6649-490c-bd2b-025199a018a5}</MetaDataID>
        private void Copy_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Copy_Enabled(sender, e);
        }
        /// <MetaDataID>{1538066b-bcbb-40ba-bebc-451cdf272696}</MetaDataID>
        private void Align_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Align_Enabled(sender, e);
        }
        /// <MetaDataID>{feb874f2-09e3-4537-8aca-7aa68d85dd9b}</MetaDataID>
        private void Distribute_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Distribute_Enabled(sender, e);
        }


        /// <MetaDataID>{5905d702-2a41-45bb-8eff-a734ac267ebb}</MetaDataID>
        private void Cut_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {

            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Cut_Enabled(sender, e);
        }

        /// <MetaDataID>{d3c85c3d-c33d-4d3d-b666-f8f61cc5f575}</MetaDataID>
        private void Paste_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Paste_Enabled(sender, e);
        }
        /// <MetaDataID>{2a0044b7-3195-4198-be66-4fc9c127094e}</MetaDataID>
        private void Delete_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Delete_Enabled(sender, e);
        }
        /// <MetaDataID>{d14790ac-8ade-43f0-8087-1d3f7d813f1e}</MetaDataID>
        private void Group_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Group_Enabled(sender, e);
        }
        /// <MetaDataID>{cd07989f-d56f-4601-8159-7bb690f7f9e6}</MetaDataID>
        private void Ungroup_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Ungroup_Enabled(sender, e);
        }

        /// <MetaDataID>{a2e8787c-23d8-4ded-92ae-9551ad676ec1}</MetaDataID>
        private void Order_Enabled(object sender, CanExecuteRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Order_Enabled(sender, e);
        }

        /// <MetaDataID>{c2f5e32c-a436-4782-bbd1-3aea5c0df414}</MetaDataID>
        private void Cut_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.Cut_Executed(sender, e);
        }
        /// <MetaDataID>{be2c9838-0e35-407a-917f-399777aa06b1}</MetaDataID>
        private void Print_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (SelectionDesignerCanvas != null)
                SelectionDesignerCanvas.BringForward_Executed(sender, e);


            using (SystemStateTransition stateTransition = new SystemStateTransition(TransactionOption.Suppress))
            {
                System.Windows.Window win = System.Windows.Window.GetWindow(sender as System.Windows.DependencyObject);



                var window = new MenuItemsEditor.Views.MenuItemsWindow(BookViewModel.RestaurantMenus);
                window.Owner = win;
                window.ShowDialog();


                stateTransition.Consistent = true;
            }


        }
        /// <MetaDataID>{0324c446-1e46-4062-9a4c-d17f58d889aa}</MetaDataID>
        private void Save_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {

                //this.BookViewModel.RealObject.PublishMenu("", "", "", null, "dfdf");
                //if(true)
                //    return;
                var objectContextConnection = this.GetObjectContextConnection();
                objectContextConnection.Save();


                //var jsonRestaurantMenu = new MenuPresentationModel.JsonMenuPresentation.RestaurantMenu(ZoomViewBox.GetDataContextObject<BookViewModel>().RestaurantMenu);
                //string json = JsonConvert.SerializeObject(jsonRestaurantMenu, Formatting.None, new JsonSerializerSettings { PreserveReferencesHandling = PreserveReferencesHandling.All });

                FlavourBusinessFacade.IResourceManager resourceManager = FlavourBusinessManager.Organization.CurrentOrganization as FlavourBusinessFacade.IResourceManager;
                if(RestaurandMenuDoc!=null)
                    resourceManager.PublishMenu(RestaurandMenuDoc.StorageRef);

                //var jsonStorageRef=  resourceManager.GetJsonGraphicMenu(RestaurandMenuDoc.StorageRef);
                // FlavourBusinessFacade.IUploadService uploadService = FlavourBusinessManager.Organization.CurrentOrganization as FlavourBusinessFacade.IUploadService;
                //var uploadSlot= uploadService.GetUploadSlotFor(jsonStorageRef);
                // MemoryStream jsonRestaurantMenuStream = new MemoryStream();

                // byte[] jsonBuffer = System.Text.Encoding.UTF8.GetBytes(json);
                // jsonRestaurantMenuStream.Write(jsonBuffer, 0, jsonBuffer.Length);
                // jsonRestaurantMenuStream.Position = 0;

                // RestApiBlobFileManager.Upload(jsonRestaurantMenuStream, uploadSlot, "application/json");
                // resourceManager.PublishMenu(jsonStorageRef);






                //var jsonRestaurantMenu = new MenuPresentationModel.JsonMenuPresentation.RestaurantMenu(ZoomViewBox.GetDataContextObject<BookViewModel>().RestaurantMenu);

                //string json = JsonConvert.SerializeObject(jsonRestaurantMenu, Formatting.None, new JsonSerializerSettings { PreserveReferencesHandling = PreserveReferencesHandling.All });



                ////SaveFile(RestaurandMenuDoc, RestaurandMenuFileName);

                //System.IO.FileInfo finfo = new System.IO.FileInfo(RestaurandMenuDoc.FileName);
                //string menuName = finfo.Name.Substring(0, finfo.Name.Length - finfo.Extension.Length);

                ////FlavourBusinessToolKit.FileManager.CurrentFileManager.Upload("1231212", "Menus/" + menuName, RestaurandMenuFileName);

                //FlavourBusinessToolKit.FlavourBusinessManager flavourBusinessManager = new FlavourBusinessToolKit.FlavourBusinessManager();
                //flavourBusinessManager.PublishMenu("1231212", "Menus/" + RestaurandMenuDoc.StorageRef.Name, RestaurandMenuDoc.StorageRef);

                //OOAdvantech.MetaDataRepository.Storage storage = OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject(BookViewModel.RestaurantMenu).StorageMetaData as OOAdvantech.MetaDataRepository.Storage;
                //foreach (var linkedStorage in storage.LinkedStorages)
                //{

                //    if (linkedStorage.StorageType == "OOAdvantech.MetaDataLoadingSystem.MetaDataStorageProvider")
                //    {

                //    }
                //}
            }
            catch (Exception error)
            {

                //throw;
            }
        }

        /// <MetaDataID>{e66a2568-7819-416f-bf73-0110b349bee9}</MetaDataID>
        void SaveFile(XElement xElement, string fileName)
        {

            //if (!string.IsNullOrWhiteSpace(fileName) && System.IO.File.Exists(fileName))
            //{
            //    xElement.Save(fileName);
            //    return;
            //}
            //else
            //{
            //    SaveFileDialog saveFile = new SaveFileDialog();
            //    saveFile.Filter = "Files (*.xml)|*.xml|All Files (*.*)|*.*";
            //    if (saveFile.ShowDialog() == true)
            //    {
            //        try
            //        {
            //            xElement.Save(saveFile.FileName);
            //            RestaurandMenuFileName = saveFile.FileName;
            //        }
            //        catch (Exception ex)
            //        {
            //            MessageBox.Show(ex.StackTrace, ex.Message, MessageBoxButton.OK, MessageBoxImage.Error);
            //        }
            //    }
            //}
        }
        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
        }



        //XDocument RestaurandMenuDoc;
        RawStorageData RestaurandMenuDoc;
        //string RestaurandMenuFileName;

        /// <MetaDataID>{56872a7b-ec87-4e99-947e-d12bf3ab5505}</MetaDataID>
        private void New_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            RestaurandMenuDoc = new RawStorageData(new XDocument(), null, null, null);
            BookViewModel = BookViewModel.NewMenu(RestaurandMenuDoc);
            this.GetObjectContext().SetContextInstance(BookViewModel);
            // RestaurandMenuFileName = null;
        }
        /// <MetaDataID>{70e23090-561a-4632-baa1-a7164bce624c}</MetaDataID>
        private async void Open_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            RawStorageData menu = null;
            Window win = Window.GetWindow(sender as DependencyObject);
            //  position = win.PointFromScreen(position);

            Views.GraphicMenusForm graphicMenusForm = new Views.GraphicMenusForm();
            var menuDesignerViewModel = this.GetDataContextObject<ViewModel.FlavourBusinessManagerViewModel>();
            graphicMenusForm.Owner = win;

            graphicMenusForm.GetObjectContext().SetContextInstance(menuDesignerViewModel.GraphicMenus);

            if (graphicMenusForm.ShowDialog().Value)
            {
                var graphicMenu = menuDesignerViewModel.GraphicMenus.SelectedMenu;

                string appDataPath = System.Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\Microneme";
                if (!System.IO.Directory.Exists(appDataPath))
                    System.IO.Directory.CreateDirectory(appDataPath);
                appDataPath += "\\DontWaitWater";
                if (!System.IO.Directory.Exists(appDataPath))
                    System.IO.Directory.CreateDirectory(appDataPath);
                string temporaryStorageLocation = appDataPath + string.Format("\\{0}RestaurantMenuData.xml", graphicMenu.StorageRef.StorageIdentity.Replace("-", ""));
                HttpClient httpClient = new HttpClient();
                var transaction = OOAdvantech.Transactions.Transaction.Current;

                var dataStream = await httpClient.GetStreamAsync(graphicMenu.StorageRef.StorageUrl);
                using (SystemStateTransition stateTransition = new SystemStateTransition(transaction))
                {
                    RawStorageData storageData = new RawStorageData(XDocument.Load(dataStream), temporaryStorageLocation, graphicMenu.StorageRef, FlavourBusinessManager.Organization.CurrentOrganization as FlavourBusinessFacade.IUploadService);
                    menu = storageData;

                    RestaurandMenuDoc = menu;

                    BookViewModel = BookViewModel.OpenMenu(RestaurandMenuDoc);

                    this.GetDataContextObject<FlavourBusinessManagerViewModel>().Menu = BookViewModel;

                    stateTransition.Consistent = true;
                }

                OOAdvantech.Linq.Storage storage = new OOAdvantech.Linq.Storage(OOAdvantech.PersistenceLayer.ObjectStorage.GetStorageOfObject((BookViewModel.RestaurantMenus.Members[0] as MenuItemsEditor.ViewModel.MenuViewModel).Menu));

                var items = (from foodItem in storage.GetObjectCollection<MenuModel.MenuItem>()
                             select foodItem).ToArray();

                var sitems = (from foodItem in storage.GetObjectCollection<MenuModel.MenuItem>()
                              select new { foodItem = foodItem.Refresh(foodItem.OptionsMenuItemSpecifics) }).ToArray();

                //BookViewModel = BookViewModel.OpenMenu(RestaurandMenuDoc);
                //this.GetDataContextObject<MenuDesignerViewModel>().Menu = BookViewModel;
            }









        }

        /// <MetaDataID>{c95c54cd-c1ca-400c-9bac-5e30e84b13c1}</MetaDataID>
        private RawStorageData LoadSerializedDataFromFile()
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "Designer Files (*.xml)|*.xml|All Files (*.*)|*.*";

            if (openFile.ShowDialog() == true)
            {
                try
                {
                    XDocument doc = XDocument.Load(openFile.FileName);
                    doc.Root.SetAttributeValue("FileName", openFile.FileName);
                    RawStorageData storageData = new RawStorageData(doc, openFile.FileName, null, null);

                    return storageData;
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.StackTrace, e.Message, MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            return null;
        }



        private void Grid_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void Grid_DragEnter(object sender, DragEventArgs e)
        {
            DesignerCanvas designerCanvas = WPFUIElementObjectBind.ObjectContext.FindChilds<DesignerCanvas>(sender as DependencyObject).FirstOrDefault();
            if (designerCanvas != null)
                designerCanvas.DragEnter(e);
        }

        private void Grid_DragLeave(object sender, DragEventArgs e)
        {
            DesignerCanvas designerCanvas = WPFUIElementObjectBind.ObjectContext.FindChilds<DesignerCanvas>(sender as DependencyObject).FirstOrDefault();
            if (designerCanvas != null)
                designerCanvas.DragLeave(e);
        }

        private void Grid_DragOver(object sender, DragEventArgs e)
        {
            DesignerCanvas designerCanvas = WPFUIElementObjectBind.ObjectContext.FindChilds<DesignerCanvas>(sender as DependencyObject).FirstOrDefault();
            if (designerCanvas != null)
                designerCanvas.DragOver(e);
        }

        private void Grid_Drop(object sender, DragEventArgs e)
        {
            DesignerCanvas designerCanvas = WPFUIElementObjectBind.ObjectContext.FindChilds<DesignerCanvas>(sender as DependencyObject).FirstOrDefault();
            if (designerCanvas != null)
                designerCanvas.Drop(e);
        }
    }

    /// <MetaDataID>{7bedc77d-eb1e-437d-97ab-8b884161c28d}</MetaDataID>
    public static class ViewBoxExtensions
    {
        public static double GetScaleFactor(this Viewbox viewbox)
        {
            if (viewbox.Child == null ||
                (viewbox.Child is FrameworkElement) == false)
            {
                return double.NaN;
            }
            FrameworkElement child = viewbox.Child as FrameworkElement;
            return viewbox.ActualWidth / child.ActualWidth;
        }
    }

    /// <MetaDataID>{61eaf0d0-63a0-4e79-bda1-6241aa198246}</MetaDataID>
    public class StyleFontUpdater
    {
        public readonly MenuPresentationModel.MenuStyles.IStyleRule Style;
        public readonly StyleableWindow.FontPresantation FontPresantation;
        public readonly string FontProperty;
        public StyleFontUpdater(MenuPresentationModel.MenuStyles.IStyleRule style, StyleableWindow.FontPresantation fontPresantation, string fontProperty)
        {
            FontProperty = fontProperty;
            FontPresantation = fontPresantation;
            Style = style;
            fontPresantation.PropertyChanged += FontPropertyChanged;
        }

        private void FontPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (Style is MenuPresentationModel.MenuStyles.IMenuItemStyle)
            {
                if (FontProperty == "DescriptionFont")
                    (Style as MenuPresentationModel.MenuStyles.IMenuItemStyle).DescriptionFont = FontPresantation.Font;
                else if (FontProperty == "ExtrasFont")
                    (Style as MenuPresentationModel.MenuStyles.IMenuItemStyle).ExtrasFont = FontPresantation.Font;
                else
                    (Style as MenuPresentationModel.MenuStyles.IMenuItemStyle).Font = FontPresantation.Font;
            }

            if (Style is MenuPresentationModel.MenuStyles.IHeadingStyle)
                (Style as MenuPresentationModel.MenuStyles.IHeadingStyle).Font = FontPresantation.Font;
            if (Style is MenuPresentationModel.MenuStyles.IPriceStyle)
                (Style as MenuPresentationModel.MenuStyles.IPriceStyle).Font = FontPresantation.Font;


        }
    }


}
