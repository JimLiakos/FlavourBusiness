﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MenuItemsEditor.Views
{
    /// <summary>
    /// Interaction logic for ContextPriceTextBox.xaml
    /// </summary>
    /// <MetaDataID>{6e36fead-7cd5-4c40-bb9e-27e4488b1891}</MetaDataID>
    public partial class ContextPriceTextBox : ContentControl
    {
        public ContextPriceTextBox()
        {
            InitializeComponent();
        }

        private void Grid_MouseEnter(object sender, MouseEventArgs e)
        {
            if(OverridePrice!=-1)
                RemovePriceBtn.Visibility = Visibility.Visible;
        }

        private void Grid_MouseLeave(object sender, MouseEventArgs e)
        {
            RemovePriceBtn.Visibility = Visibility.Collapsed;
        }


        public decimal OverridePrice
        {
            get
            {
                object value = GetValue(OverridePriceProperty);
                if (value is decimal)
                    return (decimal)value;
                else
                    return default(decimal);
            }
            set
            {
                SetValue(OverridePriceProperty, value);
            }
        }
        /// <MetaDataID>{547e83a9-7d89-4737-8cb1-f343771e7a7c}</MetaDataID>
        public static readonly DependencyProperty OverridePriceProperty =
                    DependencyProperty.Register(
                    "OverridePrice",
                    typeof(decimal),
                    typeof(ContextPriceTextBox),
                    new PropertyMetadata(default(decimal), new PropertyChangedCallback(OverridePricePropertyChangedCallback)));


        /// <MetaDataID>{2c072aec-8ab0-450f-9b74-0a689a8e847e}</MetaDataID>
        public static void OverridePricePropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

            //if (d is EditableTextBlock)
            //    (d as EditableTextBlock).TextPropertyChanged();
        }

        /// <MetaDataID>{4ef71894-a041-4596-bffe-be2b80e2b7a5}</MetaDataID>
        private void OverridePricePropertyChanged()
        {

            //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FormattedText)));
        }




        public string Price
        {
            get { return (string)GetValue(PriceProperty); }
            set { SetValue(PriceProperty, value); }
        }
        /// <MetaDataID>{547e83a9-7d89-4737-8cb1-f343771e7a7c}</MetaDataID>
        public static readonly DependencyProperty PriceProperty =
                    DependencyProperty.Register(
                    "Price",
                    typeof(string),
                    typeof(ContextPriceTextBox),
                    new PropertyMetadata("", new PropertyChangedCallback(PricePropertyChangedCallback)));


        /// <MetaDataID>{2c072aec-8ab0-450f-9b74-0a689a8e847e}</MetaDataID>
        public static void PricePropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

            //if (d is EditableTextBlock)
            //    (d as EditableTextBlock).TextPropertyChanged();
        }

        /// <MetaDataID>{4ef71894-a041-4596-bffe-be2b80e2b7a5}</MetaDataID>
        private void PricePropertyChanged()
        {

            //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FormattedText)));
        }
    }
}
