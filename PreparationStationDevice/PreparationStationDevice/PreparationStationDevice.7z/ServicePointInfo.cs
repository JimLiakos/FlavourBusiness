﻿using System;
using System.Collections.Generic;
using System.Text;
using FlavourBusinessManager.RoomService;

namespace PreparationStationDevice
{
    public class PreparationItemsPerServicePoint
    {
        public string ServicesPointIdentity { get; set; }
        public string ServicesContextIdentity { get; set; }
        public string Description { get; set; }

       public List<ItemPreparation> PreparationItems { get; set; }

    }
}
